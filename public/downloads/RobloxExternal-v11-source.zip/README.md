# C++ Player Overlay

Standalone x64 Windows overlay built with Dear ImGui v1.92.5 and DirectX 11.
It reads live character parts and the view matrix from the regular Roblox desktop
client using Windows ReadProcessMemory. No game scripts, Studio connection or
HTTP relay are used. The world overlay has no simulated targets; the labeled
in-menu preview uses a local dummy, independently of the game connection.

## v11 change

External speed and jump editing has been removed after the reported Roblox
Error Code 268 disconnect. The Misc page now displays read-only character
statistics. The reader no longer opens a writable process handle or contains
movement apply/restore operations. This removes those external memory writes;
it does not diagnose the disconnect or guarantee that Error Code 268 cannot
occur. No injection, access bypass or anti-cheat workaround was added.

## Retained features

- Resizable white menu with optional charcoal theme, menu-accent picker,
  animated entry/page changes, icon hover labels and reduced-motion controls.
- Aim controls are grouped into Targeting, Response, Activation and Trigger.
  Advanced mouse-response settings are collapsed by default.
- Hold-to-enable trigger input starts disabled. It requires a live confirmed
  enemy, a valid projected point near screen center, a hidden menu, and the
  foreground unminimized game. Unknown teams are excluded; manual relation
  assignments are available on the ESP page. Delay, cooldown and per-hold burst
  limits are configurable. Focus/menu/manual-click interruptions require
  releasing activation before rearming. Input-click counts are not confirmed
  game shots. There is no line-of-sight or weapon-hit verification.
- Partial input pairs retain pending mouse-release recovery, block subsequent
  clicks until recovery succeeds, and attempt cleanup on normal shutdown.
  Persistent Windows input failures remain reported, not treated as success.
- ESP Minimal/Competitive/Electric configurations and Circuit body effects:
  dashed outlines, travelling highlights, and pulses from observed health changes.
- A clipped dummy preview shows current settings or compares them with Minimal.
  It works without opening Roblox. Crosshair editing has its own shape preview.
- Cross/Dot/Circle crosshairs with size, gap, thickness, outline and RGBA color.
- Search routes to relevant pages/tabs. Completed setting edits have undo/redo
  with up to 31 previous snapshots. Navigation is outside that history.
- Profiles are saved next to the executable under `profiles`. Import/export uses
  versioned INI files, validates numeric data and file size, and never imports
  player addresses or team overrides. Loading/undo/redo always
  disables aim and trigger. Saving replaces a complete profile atomically;
  transient file contention receives bounded retries and persistent errors
  remain visible. Profile parsing uses the Windows INI APIs.
- Session stats show this application's runtime, average/rolling FPS, peak frame
  interval, frame-time history and CPU share. These are overlay statistics, not
  Roblox's FPS. Compatibility reports unavailable/partial/standard client data.
- Screenshot mode hides the menu on entry and suppresses labels; it also disables
  aim and trigger. Insert can reopen the menu to turn screenshot mode off.
- Connection loading stages correspond to graphics, window discovery and valid
  character data. No invented installation percentage is displayed.

Universal game compatibility is not promised. Custom teams/rigs, unavailable
client geometry, different camera/input behavior and client-version changes can
limit functionality. Bloxstrike uses the same generic reader; there is no custom
weapon integration, process injection, driver or access bypass in this build.

## Build and run

Open `RobloxExternal(For test and Fun).slnx` in Visual Studio with Desktop
development with C++ installed. Select **Release / x64**, then Build Solution.
Run:
`RobloxExternal(For test and Fun)/x64/Release/RobloxExternal(For test and Fun).exe`.

Join your test game in the Roblox desktop player using windowed or borderless
mode. The overlay follows the client area and draws boxes around the projected
corners of other players' body parts. Your own character is excluded. There is
no wall-occlusion check, so readable character positions can produce boxes
through walls. Characters not present in client memory cannot be displayed.

- **Insert:** show/hide the ImGui menu. Hiding it lets mouse clicks pass through.
- **End:** quit.
- The **Aim** page contains mouse aim assist with hold-key activation, screen-space
  radius, head/torso/root targeting, smooth response, adjustable mouse gain,
  target retention and optional single-player selection. It starts disabled.
  Enable it, close the menu with Insert and hold the selected key (right mouse
  by default). Smoothing at zero applies the full mouse-gain-scaled correction
  without time filtering or the step limit. Positive smoothing uses an adjustable
  step limit. Mouse gain remains a sensitivity calibration in both modes.
  The game camera must respond to mouse movement. Sensitivity,
  camera mode and weapon behavior differ across games; universal compatibility
  is not promised. It never fires a weapon and has no line-of-sight test.
- The **ESP** page contains boxes, names, distance, R6/R15 skeleton connections,
  tracers and body outlines, with full/corner box styles and label sizing.
  Show teammates filters all teammate visuals immediately, including effects.
  Labels distinguish TEAM, ENEMY and unknown (?). Automatic relation uses
  validated Roblox Team instances; custom or unassigned teams remain unknown.
  Use Team Assignment to mark a selected player as a teammate/enemy if needed.
  Overrides follow User ID across respawns. Aim has a separate Ignore teammates
  option that uses the same relation. Range defaults to zero (unlimited).
- The **Effects** page controls animated rainbow colors, soft glow and black
  lava with glowing cracks, travelling electric sparks, animated scan bands,
  opacity and animation speed. Electric, Spectral and Monochrome presets, pulsing
  outlines and travelling edge highlights are also available.
  Effects can cover other players, one selected
  player, or your own avatar in third-person view.
- The **Misc** page reads current speed, jump-power and jump-mode values.
  It has no editing fields, Apply/Restore commands or process-memory writes.
- The **Avatar** page reads your username/User ID and selects your own character
  for body effects.
- The **Settings** page controls attachment and reset.
- The **Console** page shows timestamped application messages with severity
  filters, auto-scroll, copy-log and copy-diagnostics commands. Clear view only
  clears the 256-entry in-app buffer; it does not erase the file history.
  The console-logging switch hides or shows the application-owned console.
  An inherited terminal is never hidden or freed by this app.

## Application log

Normal launch opens an application-owned console and reports initialization
results and connection changes. "Overlay loaded successfully" follows the first
successful, non-occluded frame presentation, not an injected module or working gameplay
changes. This is not Roblox's internal developer console.

Each launch replaces `logs/latest.log` next to the executable. If the log file
cannot be opened or written, the Console page retains messages and reports the
failure. `--no-console` starts without allocating a console window; the in-app
log and file log remain available. Showing the console later replays the retained
entries. No administrator privilege is requested for the logger.
Use the Console page's switch to hide the app-owned console without exiting.
Closing its native X button terminates the application and can bypass normal
shutdown logging; this is not a separate console-viewer process.

Neither supplied injection attachment is integrated or executed.
This version adds no remote executable allocation, thread-pool injection,
renderer hooks or internal print calls.

Silent aim, fly, noclip, avatar replacement, Headless and
Korblox appearance changes are **not implemented**. These require actual game
integration, whose source is not available. The runtime structure declarations
supplied later do not provide weapon, movement or avatar scripts. The UI states
this instead of exposing nonfunctional action buttons. The body overlay does
not change your Roblox account avatar or grant items.
- The menu reports reader status, character count and projected box count.
- The overlay hides when Roblox is minimized or a different app is foreground.

The menu captures mouse input across the overlay while open; press Insert to
return control to the game. Global hotkeys must be available. Close an older
overlay instance before running a new build.

## Reader and offsets

`offsets.hpp` contains the required subset of the offsets supplied by the user,
for client **version-cec3ad5889b447cf**, dumped 2026-10-06. The reader checks the
installed client's version folder before using them. A client update requires
matching offsets; mismatches and memory access failures appear in the menu.

`player_reader.cpp` owns the read-only process handle, bounded instance traversal,
name decoding, character cache and world-to-screen projection. It refreshes
the character list every 100 ms, retaining unchanged character metadata instead
of rebuilding it. Joins, respawns and newly replicated body parts are picked up
by this refresh. Only standard R6/R15 body parts contribute to bounds; weapons
and equipment do not. Body geometry is read each render frame and the
camera matrix is sampled immediately afterward. Screen coordinates are never
reused from a previous frame. Near-plane intersections keep partially visible
bodies from disappearing. Changing characters during respawn drops cached boxes
immediately. As an external overlay, it still has a separate frame schedule from
the game; motion alignment needs a live camera check.
Humanoid health is checked each frame and again before projection. Dead,
missing or unreadable Humanoids produce no ESP, body effects or aim targets.
Positive health resumes display automatically; replacement characters are
picked up by the regular 100 ms character-cache refresh. The Settings page
shows counts for dead/loading/unreadable/off-screen characters. Valid distant
boxes are given a minimum pixel size. Client streaming still limits available
geometry: the overlay cannot show accurate positions for objects Roblox has
not replicated. The frame limiter is adjustable from 30 to 240 FPS, with a
default target of 120 FPS, to avoid unnecessary CPU/GPU work.

`main.cpp` owns the window and DirectX resources. The DirectComposition path was
removed after a live black-screen report. The build uses the earlier windowed
DirectX swap chain and black color-key transparency. Exactly black background
pixels disappear; near-black body fills remain visible. Glow is shaded into the
overlay instead of using per-pixel desktop alpha. Use windowed or borderless
Roblox, and End closes the overlay if the display misbehaves.
`overlay_ui.cpp` owns the ImGui pages and draws the visuals using Segoe UI when
installed. The lava effect covers projected body-part cuboids; it does not replace
the avatar's material or reproduce a mesh-accurate in-game shader. Crack positions
are anchored to the projected body faces rather than the screen.
`aim_assist.cpp` owns target selection and frame-time-based mouse response. It
emits relative Windows mouse input only while the hold key is pressed, the menu
is hidden and the Roblox target window is foreground. Automated checks never
emit mouse input. Aim assist needs interactive verification in the test game.
The reader uses PROCESS_VM_READ and limited process-query access only. It never
requests a writable process handle or writes game memory. No drivers are
installed. Automated verification never changes the live game.

## Verification

- `--self-test`: run the math and filesystem-only
  application-log/profile/history tests and pure trigger/metric tests without
  opening a window, reading a game, sending input
  or allocating a console. Logger tests verify formatting, the bounded buffer,
  clear-view preservation, latest-log truncation and failed-file-open reporting.
- `--diagnose`: read one live snapshot and write status, character count, box
  count and first box coordinates to standard output. Exit 0 means live local
  character data was available; exit 3 means the reader could not connect.
  Redirect stdout to a file when invoking this Windows-subsystem application.
  Add `--local` to include the local avatar's projected geometry and stat status.
  Add `--details` to inspect readable health, body metadata and standard team data.
- `--smoke-test`: check projection, camera translation, near-plane clipping and
  convex-hull math, then render five hidden frames using a test-only character.
  Check transparent, translucent and visible pixels through DirectX readback and
  save `work/preview-esp.png`. Add `--aim`, `--effects`, `--misc`, `--avatar` or
  `--settings` or `--console` to verify those pages and save previews. Target selection and aim
  response math are checked without emitting input. Add `--animation-test` to
  compare character pixels at frames 5 and 35 and verify that effects animate.
  `--team-hidden` and `--team-shown` verify the teammate checkbox using rendered
  pixels with a manually assigned teammate fixture. No mouse input is emitted.
  `--hover-preview` injects only an ImGui test mouse position to verify the ESP
  hover label in the hidden application; it does not move the Windows cursor.
  Exit 0
  means success; 1 is initialization/render failure, 2 is missing drawing pixels,
  and 4 is a self-test failure. The fixture is never used in normal mode.

Additional hidden checks use `--trigger`, `--response`, `--profiles`, `--session`,
`--interface`, `--dark`, `--compare`, `--compact`, `--crosshair-dot`, and
`--crosshair-circle`. `--ui-animation-test` compares menu pixels across frames.
`--reduced-motion --animation-test` verifies unchanged decorative effect pixels.
`--search-test` sends mouse/text events only into the hidden ImGui instance and
checks that text input remains active while search results appear. No Windows
mouse or keyboard input is emitted by these tests.

The v11 Release/x64 build, self-tests and hidden render checks passed. No live
game writes or mouse input occurred during this verification. Console-window
interaction and in-game behavior were not tested interactively.

Dear ImGui is vendored under `third_party/imgui` with its upstream MIT license.
Upstream: https://github.com/ocornut/imgui/tree/v1.92.5

The white menu uses Lucide Static 0.468.0, embedded as a font resource so the
executable needs no loose font files. Hovering a navigation icon reveals its name
with a short fade/slide and soft shadow. This is not native desktop backdrop blur;
the proven color-key renderer is retained. Health bars, a crosshair, pause-visuals
in-menu and an adjustable FPS cap are available. Lucide's license is both vendored
at `third_party/lucide/LICENSE` and embedded as resource 102.
