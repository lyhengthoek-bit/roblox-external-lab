#pragma once
#include "player_reader.hpp"

struct AimSettings {
    bool enabled = false;
    bool showRadius = true;
    bool keepTarget = true;
    bool selectedOnly = false;
    bool ignoreTeammates = true;
    int activation = 0;
    int bone = 0;
    float radius = 180;
    float smoothTime = 0.08f;
    float gain = 0.3f;
    float maxStep = 120;
};

const PlayerBox* SelectAimTarget(const std::vector<PlayerBox>& players, const AimSettings& settings,
    float width, float height, float maxDistance, uintptr_t selectedId, uintptr_t lockedId, const TeamOverrides& overrides = {});
ScreenPoint AimStep(ScreenPoint error, float dt, const AimSettings& settings);
bool TestAimAssist();

class AimAssist {
public:
    void Update(const AimSettings& settings, const std::vector<PlayerBox>& players,
        HWND target, bool menuOpen, float width, float height, float dt, float maxDistance, uintptr_t selectedId,
        const TeamOverrides& overrides = {});
    const std::string& Status() const { return status_; }
    uintptr_t TargetId() const { return lockedId_; }
    ScreenPoint TargetPoint() const { return targetPoint_; }
private:
    uintptr_t lockedId_ = 0;
    ScreenPoint residual_{}, targetPoint_{};
    std::string status_ = "Disabled";
};
