#include "trigger_assist.hpp"
#include <algorithm>
#include <cmath>
#include <limits>

namespace {
bool ValidSettings(const TriggerSettings& settings) {
    return settings.activation >= 0 && settings.activation <= 2 && settings.bone >= 0 && settings.bone <= 2 &&
        settings.burstLimit >= 1 && settings.burstLimit <= 10 &&
        std::isfinite(settings.tolerance) && settings.tolerance > 0 && settings.tolerance <= 100 &&
        std::isfinite(settings.delay) && settings.delay >= 0 && settings.delay <= 10 &&
        std::isfinite(settings.cooldown) && settings.cooldown >= 0 && settings.cooldown <= 10;
}

const PlayerBox* SelectTriggerTarget(const TriggerSettings& settings, const std::vector<PlayerBox>& players,
    float width, float height, float maxDistance, uintptr_t selectedId, const TeamOverrides& overrides) {
    const PlayerBox* closest = nullptr;
    float best = settings.tolerance * settings.tolerance;
    for (const auto& player : players) {
        if (!player.id || player.isLocal || RelationFor(player, overrides) != TeamRelation::Enemy ||
            !std::isfinite(player.health) || player.health <= 0 || !std::isfinite(player.distance) ||
            player.distance < 0 || (maxDistance > 0 && player.distance > maxDistance) ||
            !player.aimValid[settings.bone] || (settings.selectedOnly && player.id != selectedId)) continue;
        const auto point = player.aimPoints[settings.bone];
        if (!std::isfinite(point.x) || !std::isfinite(point.y) || point.x < 0 || point.y < 0 ||
            point.x >= width || point.y >= height) continue;
        const float x = point.x - width * 0.5f, y = point.y - height * 0.5f;
        const float distance = x * x + y * y;
        if (std::isfinite(distance) && distance <= best) { best = distance; closest = &player; }
    }
    return closest;
}

bool Focused(HWND target) {
    return IsWindow(target) && IsWindowVisible(target) && !IsIconic(target) && GetForegroundWindow() == target;
}

int ActivationKey(int activation) {
    const int keys[] = {VK_XBUTTON2, VK_LMENU, VK_LCONTROL};
    return keys[std::clamp(activation, 0, 2)];
}

UINT EmitWindowsInput(UINT count, INPUT* inputs, int inputSize, void*) {
    return SendInput(count, inputs, inputSize);
}
}

void TriggerAssist::ClearTarget() {
    stableId_ = 0;
    stableFor_ = 0;
    armed_ = false;
}

void TriggerAssist::Reset() {
    ClearTarget();
    waitForRelease_ = releasePending_;
    shotsThisHold_ = 0;
    cooldownLeft_ = 0;
    shotCount_ = 0;
    status_ = releasePending_ ? "Mouse release pending" : "Disabled";
}

bool TriggerAssist::Evaluate(const TriggerSettings& settings, const std::vector<PlayerBox>& players,
    const Gate& gate, float width, float height, float dt, float maxDistance,
    uintptr_t selectedId, const TeamOverrides& overrides) {
    const bool validTiming = std::isfinite(dt) && dt > 0;
    const float elapsed = validTiming ? std::min(dt, 0.1f) : 0;
    cooldownLeft_ = std::max(0.0f, cooldownLeft_ - elapsed);
    if (releasePending_) {
        ClearTarget();
        waitForRelease_ = true;
        status_ = "Mouse release pending";
        return false;
    }
    if (!gate.activationHeld) {
        waitForRelease_ = false;
        shotsThisHold_ = 0;
        ClearTarget();
    }
    auto blocked = [&](const char* message, bool requireRelease) {
        ClearTarget();
        if (requireRelease && gate.activationHeld) waitForRelease_ = true;
        status_ = message;
        return false;
    };
    if (!settings.enabled) return blocked("Disabled", true);
    if (gate.menuOpen) return blocked("Paused while menu is open", true);
    if (!gate.focused) return blocked("Waiting for game focus", true);
    if (!ValidSettings(settings) || !std::isfinite(width) || !std::isfinite(height) || width <= 0 || height <= 0 ||
        !std::isfinite(maxDistance) || maxDistance < 0) return blocked("Invalid trigger settings", true);
    if (gate.physicalLeftHeld) return blocked("Physical left mouse button held", true);
    if (!gate.activationHeld) return blocked("Ready - hold activation", false);
    if (waitForRelease_) return blocked("Release activation to arm", false);
    if (!validTiming) return blocked("Waiting for valid frame timing", true);
    if (shotsThisHold_ >= settings.burstLimit) return blocked("Burst limit reached - release activation", false);

    armed_ = true;
    const auto* player = SelectTriggerTarget(settings, players, width, height, maxDistance, selectedId, overrides);
    if (!player) {
        stableId_ = 0;
        stableFor_ = 0;
        status_ = "No confirmed enemy in tolerance";
        return false;
    }
    // Stability starts only after the same projected target has been observed on consecutive frames.
    if (stableId_ != player->id) { stableId_ = player->id; stableFor_ = 0; }
    else stableFor_ = std::min(10.0f, stableFor_ + elapsed);
    if (stableFor_ + 0.000001f < settings.delay) {
        status_ = "Target delay: " + player->name;
        return false;
    }
    if (cooldownLeft_ > 0.000001f) { status_ = "Cooldown"; return false; }
    status_ = "Ready to emit input";
    return true;
}

void TriggerAssist::Emitted(const TriggerSettings& settings) {
    ++shotsThisHold_;
    ++shotCount_;
    cooldownLeft_ = settings.cooldown;
    stableFor_ = 0;
    armed_ = shotsThisHold_ < settings.burstLimit;
    status_ = "Input pair emitted - shot unconfirmed";
}

void TriggerAssist::InputFailed(const char* message) {
    ClearTarget();
    waitForRelease_ = true;
    status_ = message;
}

bool TriggerAssist::ReleasePendingInputWith(InputEmitter emit, void* context) {
    if (!releasePending_) return true;
    INPUT release{};
    release.type = INPUT_MOUSE;
    release.mi.dwFlags = MOUSEEVENTF_LEFTUP;
    if (emit(1, &release, sizeof(INPUT), context) != 1) {
        InputFailed("Mouse release pending - input is blocked");
        return false;
    }
    releasePending_ = false;
    InputFailed("Input released - release activation");
    return true;
}

bool TriggerAssist::ReleasePendingInput() {
    return ReleasePendingInputWith(EmitWindowsInput, nullptr);
}

bool TriggerAssist::EmitPair(const TriggerSettings& settings, InputEmitter emit, void* context) {
    if (releasePending_) return false;
    INPUT inputs[2]{};
    inputs[0].type = inputs[1].type = INPUT_MOUSE;
    inputs[0].mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
    inputs[1].mi.dwFlags = MOUSEEVENTF_LEFTUP;
    const UINT inserted = emit(2, inputs, sizeof(INPUT), context);
    if (inserted != 2) {
        releasePending_ = inserted != 0;
        InputFailed("Mouse input was not accepted - release activation");
        if (releasePending_) ReleasePendingInputWith(emit, context);
        return false;
    }
    Emitted(settings);
    return true;
}

void TriggerAssist::Update(const TriggerSettings& settings, const std::vector<PlayerBox>& players,
    HWND target, bool menuOpen, float width, float height, float dt, float maxDistance,
    uintptr_t selectedId, const TeamOverrides& overrides) {
    // Releasing our own unmatched LEFTDOWN takes priority over all normal focus and activation gates.
    if (!ReleasePendingInput()) return;
    const int key = ActivationKey(settings.activation);
    const Gate gate{(GetAsyncKeyState(key) & 0x8000) != 0,
        (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0, Focused(target), menuOpen};
    if (!Evaluate(settings, players, gate, width, height, dt, maxDistance, selectedId, overrides)) return;
    if (!Focused(target) || !(GetAsyncKeyState(key) & 0x8000) || (GetAsyncKeyState(VK_LBUTTON) & 0x8000)) {
        InputFailed("Input cancelled - release activation");
        return;
    }
    EmitPair(settings, EmitWindowsInput, nullptr);
}

bool TestTriggerAssist() {
    TriggerAssist trigger;
    TriggerSettings settings;
    PlayerBox enemy;
    enemy.id = 1; enemy.userId = 11; enemy.name = "Fixture"; enemy.health = 100; enemy.distance = 10;
    enemy.relation = TeamRelation::Enemy; enemy.aimPoints[0] = {500, 350}; enemy.aimValid[0] = true;
    std::vector<PlayerBox> players{enemy};
    TriggerAssist::Gate gate{true, false, true, false};
    auto step = [&](float dt = 0.05f, float range = 0, uintptr_t selected = 0, const TeamOverrides& overrides = {}) {
        return trigger.Evaluate(settings, players, gate, 1000, 700, dt, range, selected, overrides);
    };
    auto release = [&] { gate.activationHeld = false; step(); gate.activationHeld = true; };

    if (step() || trigger.Armed() || trigger.ShotCount()) return false;
    settings.enabled = true;
    if (step() || trigger.Armed()) return false;
    release();
    if (step() || !trigger.Armed() || step() || step() || !step()) return false;
    trigger.Emitted(settings);
    if (trigger.ShotCount() != 1 || trigger.Armed() || step()) return false;
    settings.burstLimit = 3;
    if (step() || step() || step() || !step()) return false;
    trigger.Emitted(settings);
    if (trigger.ShotCount() != 2) return false;
    release();
    if (step() || step() || step()) return false;
    // Releasing activation does not cancel the previous input cooldown.
    if (!step()) return false;
    trigger.Emitted(settings);

    trigger.Reset(); settings.delay = 0; settings.cooldown = 0;
    if (!step()) return false;
    trigger.Emitted(settings);
    players[0].id = 2;
    if (!step()) return false;
    trigger.Emitted(settings);
    players[0].id = 3;
    if (!step()) return false;
    trigger.Emitted(settings);
    players[0].id = 4;
    if (step() || trigger.ShotCount() != 3) return false;
    release();
    if (!step()) return false;

    trigger.Reset(); settings.delay = 0.1f;
    if (step() || step()) return false;
    players[0].id = 5;
    if (step() || step() || !step()) return false;
    players[0].aimPoints[0].x = 510;
    if (step()) return false;
    players[0].aimPoints[0].x = 500;
    if (step() || step() || !step()) return false;

    settings.delay = 0;
    const PlayerBox validEnemy = players[0];
    auto invalidPlayer = [&](const PlayerBox& invalid) {
        players[0] = invalid;
        trigger.Reset();
        return !step();
    };
    auto invalid = validEnemy;
    invalid.health = 0; if (!invalidPlayer(invalid)) return false;
    invalid.health = -1; if (!invalidPlayer(invalid)) return false;
    invalid.health = std::numeric_limits<float>::quiet_NaN(); if (!invalidPlayer(invalid)) return false;
    invalid.health = std::numeric_limits<float>::infinity(); if (!invalidPlayer(invalid)) return false;
    invalid = validEnemy; invalid.id = 0; if (!invalidPlayer(invalid)) return false;
    invalid = validEnemy; invalid.isLocal = true; if (!invalidPlayer(invalid)) return false;
    invalid = validEnemy; invalid.relation = TeamRelation::Ally; if (!invalidPlayer(invalid)) return false;
    invalid.relation = TeamRelation::Unknown; if (!invalidPlayer(invalid)) return false;
    players[0] = invalid;
    trigger.Reset();
    if (!step(0.05f, 0, 0, {{invalid.userId, TeamRelation::Enemy}})) return false;
    if (step(0.05f, 0, 0, {{invalid.userId, TeamRelation::Ally}})) return false;
    invalid = validEnemy; invalid.aimValid[0] = false; if (!invalidPlayer(invalid)) return false;
    invalid = validEnemy; invalid.aimPoints[0].x = std::numeric_limits<float>::infinity();
    if (!invalidPlayer(invalid)) return false;
    invalid.aimPoints[0] = {-1, 350}; if (!invalidPlayer(invalid)) return false;
    invalid.aimPoints[0] = {1000, 350}; if (!invalidPlayer(invalid)) return false;
    invalid = validEnemy; invalid.distance = std::numeric_limits<float>::quiet_NaN();
    if (!invalidPlayer(invalid)) return false;
    invalid.distance = -1; if (!invalidPlayer(invalid)) return false;
    players[0] = validEnemy; trigger.Reset();
    if (step(0.05f, 5)) return false;
    if (step(0.05f, std::numeric_limits<float>::quiet_NaN())) return false;
    release();
    settings.selectedOnly = true;
    if (step(0.05f, 0, 123) || !step(0.05f, 0, validEnemy.id)) return false;
    settings.selectedOnly = false;

    auto testGate = [&](bool TriggerAssist::Gate::* field, bool blockedValue) {
        trigger.Reset();
        gate.*field = blockedValue;
        if (step() || trigger.Armed()) return false;
        gate.*field = !blockedValue;
        if (step() || trigger.Armed()) return false;
        release();
        return step();
    };
    if (!testGate(&TriggerAssist::Gate::menuOpen, true) ||
        !testGate(&TriggerAssist::Gate::focused, false) ||
        !testGate(&TriggerAssist::Gate::physicalLeftHeld, true)) return false;
    trigger.InputFailed("Simulated partial insertion");
    if (step() || trigger.Armed()) return false;
    release(); if (!step()) return false;
    trigger.Reset();
    if (step(0) || step(-1) || step(std::numeric_limits<float>::quiet_NaN())) return false;
    release();
    settings.tolerance = std::numeric_limits<float>::quiet_NaN();
    if (step()) return false;
    settings.tolerance = 6; settings.activation = 3;
    if (step()) return false;
    settings.activation = 0; settings.bone = 3;
    if (step()) return false;
    settings.bone = 0; settings.burstLimit = 0;
    if (step()) return false;
    settings.burstLimit = 1;
    settings.delay = -1; if (step()) return false;
    settings.delay = 0; settings.cooldown = std::numeric_limits<float>::infinity();
    if (step()) return false;
    settings.cooldown = 0;
    trigger.Reset();
    if (trigger.ShotCount() || trigger.Armed() || trigger.Status() != "Disabled") return false;

    struct SimulatedInput {
        std::vector<UINT> responses;
        size_t calls = 0;
        bool invalid = false;
    } simulation{{1, 0, 0, 1}};
    const auto emit = [](UINT count, INPUT* inputs, int inputSize, void* context) -> UINT {
        auto& simulated = *static_cast<SimulatedInput*>(context);
        const bool pair = count == 2 && inputs[0].type == INPUT_MOUSE && inputs[1].type == INPUT_MOUSE &&
            inputs[0].mi.dwFlags == MOUSEEVENTF_LEFTDOWN && inputs[1].mi.dwFlags == MOUSEEVENTF_LEFTUP;
        const bool release = count == 1 && inputs[0].type == INPUT_MOUSE && inputs[0].mi.dwFlags == MOUSEEVENTF_LEFTUP;
        if (inputSize != sizeof(INPUT) || (!pair && !release) || simulated.calls >= simulated.responses.size()) {
            simulated.invalid = true;
            return 0;
        }
        return simulated.responses[simulated.calls++];
    };
    if (!step()) return false;
    if (trigger.EmitPair(settings, emit, &simulation) || !trigger.releasePending_ || simulation.calls != 2 ||
        trigger.Armed() || trigger.ShotCount()) return false;
    if (step() || trigger.EmitPair(settings, emit, &simulation) || simulation.calls != 2) return false;
    trigger.Reset();
    if (!trigger.releasePending_ || step() || trigger.Status() != "Mouse release pending") return false;
    if (trigger.ReleasePendingInputWith(emit, &simulation) || !trigger.releasePending_ || simulation.calls != 3)
        return false;
    if (!trigger.ReleasePendingInputWith(emit, &simulation) || trigger.releasePending_ || simulation.calls != 4 ||
        simulation.invalid || step()) return false;
    if (!trigger.ReleasePendingInputWith(emit, &simulation) || simulation.calls != 4) return false;
    release();
    if (!step()) return false;
    simulation = {{2}};
    if (!trigger.EmitPair(settings, emit, &simulation) || trigger.ShotCount() != 1 || simulation.calls != 1 ||
        simulation.invalid || trigger.releasePending_) return false;
    trigger.Reset();
    simulation = {{0}};
    if (trigger.EmitPair(settings, emit, &simulation) || trigger.releasePending_ || simulation.calls != 1 ||
        simulation.invalid || trigger.ShotCount()) return false;
    return true;
}
