#include <windows.h>
#include <d3d11.h>
#include <wincodec.h>
#include <wrl/client.h>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <string>
#include <filesystem>
#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"
#include "player_reader.hpp"
#include "overlay_ui.hpp"
#include "settings_store.hpp"
#include "runtime_metrics.hpp"

using Microsoft::WRL::ComPtr;
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND, UINT, WPARAM, LPARAM);

namespace {
ComPtr<ID3D11Device> device;
ComPtr<ID3D11DeviceContext> context;
ComPtr<IDXGISwapChain> swapChain;
ComPtr<ID3D11RenderTargetView> renderTarget;
UINT resizeWidth = 0, resizeHeight = 0;
bool menuOpen = true;
bool running = true;

bool CreateRenderTarget() {
    ComPtr<ID3D11Texture2D> backBuffer;
    return SUCCEEDED(swapChain->GetBuffer(0, IID_PPV_ARGS(&backBuffer))) &&
        SUCCEEDED(device->CreateRenderTargetView(backBuffer.Get(), nullptr, &renderTarget));
}

bool CreateGraphics(HWND window) {
    DXGI_SWAP_CHAIN_DESC desc{};
    desc.BufferCount = 2;
    desc.BufferDesc.Format = DXGI_FORMAT_B8G8R8A8_UNORM;
    desc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    desc.OutputWindow = window;
    desc.SampleDesc.Count = 1;
    desc.Windowed = TRUE;
    desc.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
    const D3D_FEATURE_LEVEL levels[] = {D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0};
    D3D_FEATURE_LEVEL selected{};
    HRESULT result = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE,
        nullptr, D3D11_CREATE_DEVICE_BGRA_SUPPORT, levels, 2, D3D11_SDK_VERSION, &desc, &swapChain, &device, &selected, &context);
    if (FAILED(result)) {
        result = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_WARP,
            nullptr, D3D11_CREATE_DEVICE_BGRA_SUPPORT, levels, 2, D3D11_SDK_VERSION, &desc, &swapChain, &device, &selected, &context);
    }
    ComPtr<IDXGIDevice1> latencyDevice;
    if (SUCCEEDED(result) && SUCCEEDED(device.As(&latencyDevice))) latencyDevice->SetMaximumFrameLatency(1);
    return SUCCEEDED(result) && CreateRenderTarget();
}

void SetMenuMode(HWND window) {
    LONG_PTR style = GetWindowLongPtrW(window, GWL_EXSTYLE);
    if (menuOpen) style &= ~(WS_EX_TRANSPARENT | WS_EX_NOACTIVATE);
    else style |= WS_EX_TRANSPARENT | WS_EX_NOACTIVATE;
    SetWindowLongPtrW(window, GWL_EXSTYLE, style);
    SetWindowPos(window, nullptr, 0, 0, 0, 0,
        SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED);
    if (menuOpen) SetForegroundWindow(window);
}

LRESULT CALLBACK WindowProc(HWND window, UINT message, WPARAM wParam, LPARAM lParam) {
    if (ImGui::GetCurrentContext() && menuOpen &&
        ImGui_ImplWin32_WndProcHandler(window, message, wParam, lParam)) return 1;
    switch (message) {
    case WM_SIZE:
        if (wParam != SIZE_MINIMIZED) {
            resizeWidth = LOWORD(lParam);
            resizeHeight = HIWORD(lParam);
        }
        return 0;
    case WM_HOTKEY:
        if (wParam == 1) { menuOpen = !menuOpen; SetMenuMode(window); }
        if (wParam == 2) running = false;
        return 0;
    case WM_SYSCOMMAND:
        if ((wParam & 0xfff0) == SC_KEYMENU) return 0;
        break;
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(window, message, wParam, lParam);
}

BOOL CALLBACK FindRobloxWindow(HWND window, LPARAM param) {
    if (!IsWindowVisible(window) || GetWindow(window, GW_OWNER)) return TRUE;
    DWORD processId = 0;
    GetWindowThreadProcessId(window, &processId);
    HANDLE process = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, processId);
    if (!process) return TRUE;
    wchar_t path[32768];
    DWORD length = static_cast<DWORD>(std::size(path));
    bool match = false;
    if (QueryFullProcessImageNameW(process, 0, path, &length)) {
        const wchar_t* name = wcsrchr(path, L'\\');
        match = _wcsicmp(name ? name + 1 : path, L"RobloxPlayerBeta.exe") == 0;
    }
    CloseHandle(process);
    if (!match) return TRUE;
    RECT rect{};
    GetClientRect(window, &rect);
    if (rect.right < 200 || rect.bottom < 200) return TRUE;
    *reinterpret_cast<HWND*>(param) = window;
    return FALSE;
}

RECT ClientScreenRect(HWND window) {
    RECT rect{};
    GetClientRect(window, &rect);
    POINT origin{rect.left, rect.top};
    ClientToScreen(window, &origin);
    OffsetRect(&rect, origin.x, origin.y);
    return rect;
}

std::filesystem::path ExecutableDirectory() {
    wchar_t path[32768]{};
    const DWORD length = GetModuleFileNameW(nullptr, path, static_cast<DWORD>(std::size(path)));
    return length && length < std::size(path) ? std::filesystem::path(path).parent_path() : std::filesystem::path(L".");
}

// Read back a rendered frame to verify that the menu and draw-list produced pixels.
bool VerifyFrame(const wchar_t* previewPath, uint64_t* fingerprint = nullptr, bool expectDrawing = true,
    bool verifyBody = true, bool menuFingerprint = false) {
    ComPtr<ID3D11Texture2D> backBuffer, staging;
    if (FAILED(swapChain->GetBuffer(0, IID_PPV_ARGS(&backBuffer)))) return false;
    D3D11_TEXTURE2D_DESC desc{};
    backBuffer->GetDesc(&desc);
    desc.Usage = D3D11_USAGE_STAGING;
    desc.BindFlags = 0;
    desc.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
    desc.MiscFlags = 0;
    if (FAILED(device->CreateTexture2D(&desc, nullptr, &staging))) return false;
    context->CopyResource(staging.Get(), backBuffer.Get());
    D3D11_MAPPED_SUBRESOURCE mapped{};
    if (FAILED(context->Map(staging.Get(), 0, D3D11_MAP_READ, 0, &mapped))) return false;
    size_t colored = 0, drawing = 0, transparent = 0, translucent = 0;
    uint64_t bodyHash = 1469598103934665603ull;
    std::vector<unsigned char> pixels(static_cast<size_t>(desc.Width) * desc.Height * 4);
    for (UINT y = 0; y < desc.Height; ++y) {
        const auto* row = static_cast<const unsigned char*>(mapped.pData) + y * mapped.RowPitch;
        memcpy(pixels.data() + static_cast<size_t>(y) * desc.Width * 4, row, static_cast<size_t>(desc.Width) * 4);
        for (UINT x = 0; x < desc.Width; ++x) {
            const auto* pixel = row + x * 4;
            if (pixel[0] || pixel[1] || pixel[2]) ++colored;
            if (x > 1120 && pixel[3] > 10) ++drawing;
            if (pixel[3] == 0) ++transparent;
            if (x > 1120 && pixel[3] > 0 && pixel[3] < 250) ++translucent;
            if (menuFingerprint ? x < 1070 && y < 760 : x > 1120) for (size_t channel = 0; channel < 4; ++channel)
                bodyHash = (bodyHash ^ pixel[channel]) * 1099511628211ull;
        }
    }
    context->Unmap(staging.Get(), 0);
    if (fingerprint) *fingerprint = bodyHash;
    if (previewPath) {
        CoInitializeEx(nullptr, COINIT_MULTITHREADED);
        ComPtr<IWICImagingFactory> factory;
        ComPtr<IWICStream> stream;
        ComPtr<IWICBitmapEncoder> encoder;
        ComPtr<IWICBitmapFrameEncode> frame;
        std::filesystem::create_directories(L"work");
        const bool initialized = SUCCEEDED(CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&factory))) &&
            SUCCEEDED(factory->CreateStream(&stream)) && SUCCEEDED(stream->InitializeFromFilename(previewPath, GENERIC_WRITE)) &&
            SUCCEEDED(factory->CreateEncoder(GUID_ContainerFormatPng, nullptr, &encoder)) &&
            SUCCEEDED(encoder->Initialize(stream.Get(), WICBitmapEncoderNoCache)) &&
            SUCCEEDED(encoder->CreateNewFrame(&frame, nullptr)) && SUCCEEDED(frame->Initialize(nullptr)) &&
            SUCCEEDED(frame->SetSize(desc.Width, desc.Height));
        WICPixelFormatGUID format = GUID_WICPixelFormat32bppBGRA;
        // Store straight alpha in the preview PNG; the swap chain holds premultiplied alpha.
        for (size_t i = 0; i < pixels.size(); i += 4) if (pixels[i + 3]) {
            for (size_t channel = 0; channel < 3; ++channel)
                pixels[i + channel] = static_cast<unsigned char>(std::min(255u, pixels[i + channel] * 255u / pixels[i + 3]));
        }
        const bool saved = initialized && SUCCEEDED(frame->SetPixelFormat(&format)) &&
            SUCCEEDED(frame->WritePixels(desc.Height, desc.Width * 4, static_cast<UINT>(pixels.size()), pixels.data())) &&
            SUCCEEDED(frame->Commit()) && SUCCEEDED(encoder->Commit());
        frame.Reset(); encoder.Reset(); stream.Reset(); factory.Reset();
        CoUninitialize();
        if (!saved) return false;
    }
    return colored > 2000 && transparent > 1000 &&
        (!verifyBody || (expectDrawing ? drawing > 1000 && translucent > 100 : drawing == 0));
}
}

int WINAPI wWinMain(HINSTANCE instance, HINSTANCE, PWSTR commandLine, int) {
    const bool smokeTest = wcsstr(commandLine, L"--smoke-test") != nullptr;
    const bool selfTest = wcsstr(commandLine, L"--self-test") != nullptr;
    const bool compactTest = smokeTest && wcsstr(commandLine, L"--compact") != nullptr;
    const bool searchTest = smokeTest && wcsstr(commandLine, L"--search-test") != nullptr;
    const bool uiAnimationTest = smokeTest && wcsstr(commandLine, L"--ui-animation-test") != nullptr;
    const bool animationTest = smokeTest && (wcsstr(commandLine, L"--animation-test") != nullptr || uiAnimationTest);
    const bool teamHiddenTest = smokeTest && wcsstr(commandLine, L"--team-hidden") != nullptr;
    const bool teamShownTest = smokeTest && wcsstr(commandLine, L"--team-shown") != nullptr;
    ImGui_ImplWin32_EnableDpiAwareness();
    if (wcsstr(commandLine, L"--diagnose")) {
        HWND target = nullptr;
        EnumWindows(FindRobloxWindow, reinterpret_cast<LPARAM>(&target));
        const RECT rect = target ? ClientScreenRect(target) : RECT{0, 0, 1000, 700};
        PlayerReader reader;
        reader.Update(target, static_cast<float>(rect.right - rect.left), static_cast<float>(rect.bottom - rect.top),
            wcsstr(commandLine, L"--local") != nullptr);
        std::string report = reader.Status() + "\r\nPlayers: " + std::to_string(reader.PlayerCount()) +
            "\r\nProjected boxes: " + std::to_string(reader.Boxes().size()) + "\r\n";
        report += "Player identities: " + std::to_string(reader.Players().size()) + "\r\n";
        report += "Character stats readable: " + std::to_string(reader.LocalStats().valid) + "\r\n";
        size_t localBoxes = 0;
        for (const auto& player : reader.Boxes()) if (player.isLocal) ++localBoxes;
        report += "Local-avatar boxes: " + std::to_string(localBoxes) + "\r\n";
        const auto& detection = reader.Diagnostics();
        report += "Alive: " + std::to_string(detection.alive) + " Dead: " + std::to_string(detection.dead) +
            " Loading: " + std::to_string(detection.incomplete) + " Unknown-health: " + std::to_string(detection.unreadableHealth) +
            " Missing-geometry: " + std::to_string(detection.missingGeometry) + " Off-screen: " + std::to_string(detection.offscreen) + "\r\n";
        if (wcsstr(commandLine, L"--details")) report += reader.DescribeCharacters();
        if (!reader.Boxes().empty()) {
            const auto& box = reader.Boxes().front();
            report += "First box: " + std::to_string(box.topLeft.x) + ", " + std::to_string(box.topLeft.y) +
                " -> " + std::to_string(box.bottomRight.x) + ", " + std::to_string(box.bottomRight.y) + "\r\n";
        }
        DWORD written = 0;
        WriteFile(GetStdHandle(STD_OUTPUT_HANDLE), report.data(), static_cast<DWORD>(report.size()), &written, nullptr);
        return reader.Connected() ? 0 : 3;
    }
    AppLog log;
    const auto logPath = smokeTest || selfTest ? std::filesystem::path(L"work/session-test.log") :
        ExecutableDirectory() / L"logs" / L"latest.log";
    log.Initialize(logPath, !smokeTest && !selfTest && !wcsstr(commandLine, L"--no-console"));
    log.Write(LogLevel::Info, "Starting Roblox External v11 (standalone overlay; movement edits removed)");
    log.Write(LogLevel::Info, "No injected module loaded");
    if (!log.FileReady()) log.Write(LogLevel::Warning, "File logging unavailable; session messages remain in the app");
    auto check = [&](const char* name, bool passed) {
        if (!passed) {
            std::string message = std::string("Self-test failed: ") + name;
            if (std::string(name) == "profile store") message += " | " + SettingsStoreTestError();
            log.Write(LogLevel::Error, message);
        }
        return passed;
    };
    if (!check("projection", TestProjection()) || !check("aim math", TestAimAssist()) ||
        !check("trigger state", TestTriggerAssist()) ||
        !check("metrics", TestRuntimeMetrics()) || ((smokeTest || selfTest) &&
        (!check("app log", TestAppLog(L"work/log-tests")) || !check("profile store", TestSettingsStore(L"work/profile-tests"))))) {
        return 4;
    }
    log.Write(LogLevel::Info, "Self-tests passed");
    if (selfTest) return 0;
    WNDCLASSEXW cls{sizeof(WNDCLASSEXW)};
    cls.lpfnWndProc = WindowProc;
    cls.hInstance = instance;
    cls.hCursor = LoadCursor(nullptr, IDC_ARROW);
    cls.lpszClassName = L"RobloxExternalPlayerOverlay";
    if (!RegisterClassExW(&cls)) {
        log.Write(LogLevel::Error, "Could not register overlay window class");
        return 1;
    }
    const int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    const int screenHeight = GetSystemMetrics(SM_CYSCREEN);
    HWND window = CreateWindowExW(WS_EX_TOPMOST | WS_EX_LAYERED | WS_EX_TOOLWINDOW,
        cls.lpszClassName, L"External Overlay", WS_POPUP, 0, 0,
        smokeTest ? (compactTest ? 960 : 1440) : screenWidth, smokeTest ? (compactTest ? 680 : 900) : screenHeight,
        nullptr, nullptr, instance, nullptr);
    if (!window || !CreateGraphics(window)) {
        log.Write(LogLevel::Error, "Could not initialize overlay window or graphics");
        if (!smokeTest) MessageBoxW(nullptr, L"Could not initialize the overlay graphics.", L"External Overlay", MB_ICONERROR);
        if (window) DestroyWindow(window);
        UnregisterClassW(cls.lpszClassName, instance);
        return 1;
    }
    SetLayeredWindowAttributes(window, RGB(0, 0, 0), 255, LWA_COLORKEY);
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGui::GetIO().IniFilename = nullptr;
    SetupOverlayStyle();
    if (!ImGui_ImplWin32_Init(window) || !ImGui_ImplDX11_Init(device.Get(), context.Get())) {
        log.Write(LogLevel::Error, "Could not initialize the GUI renderer");
        ImGui::DestroyContext();
        DestroyWindow(window);
        UnregisterClassW(cls.lpszClassName, instance);
        return 1;
    }
    int exitCode = 0;
    if (!smokeTest) {
        ShowWindow(window, SW_SHOW);
        if (!RegisterHotKey(window, 1, MOD_NOREPEAT, VK_INSERT) ||
            !RegisterHotKey(window, 2, MOD_NOREPEAT, VK_END)) {
            log.Write(LogLevel::Error, "Insert or End hotkey is already registered by another app");
            MessageBoxW(window, L"Insert or End is already registered by another app. Close it and restart.", L"External Overlay", MB_ICONERROR);
            running = false;
            exitCode = 1;
        }
    }
    if (running) log.Write(LogLevel::Info, "Window and graphics initialized");
    OverlaySettings settings;
    PlayerReader reader;
    AimAssist aim;
    TriggerAssist trigger;
    RuntimeMetrics metrics;
    SettingsHistory history;
    auto renderFixture = MakeRenderFixture();
    for (auto& player : renderFixture) {
        auto move = [](ScreenPoint& point) { point.x += 360; point.y += 80; };
        move(player.topLeft); move(player.bottomRight);
        for (auto& point : player.aimPoints) move(point);
        for (auto& face : player.faces) for (auto& point : face.points) move(point);
        for (auto& polygon : player.silhouettes) for (auto& point : polygon) move(point);
        for (auto& bone : player.bones) { move(bone.start); move(bone.end); }
    }
    if (compactTest) renderFixture.clear();
    const wchar_t* previewPath = nullptr;
    if (smokeTest) {
        settings.lava = settings.rainbow = settings.bodyOutline = settings.scan = true;
        settings.pulseOutline = settings.edgeFlow = true;
        settings.dashedOutline = settings.travellingHighlight = true;
        if (wcsstr(commandLine, L"--profiles")) { settings.page = 7; previewPath = L"work/preview-profiles.png"; }
        else if (wcsstr(commandLine, L"--trigger")) { settings.page = 0; settings.aimTab = 3; previewPath = L"work/preview-trigger.png"; }
        else if (wcsstr(commandLine, L"--response")) { settings.page = 0; settings.aimTab = 1; previewPath = L"work/preview-response.png"; }
        else if (wcsstr(commandLine, L"--session")) { settings.page = 5; settings.settingsTab = 2; previewPath = L"work/preview-session.png"; }
        else if (wcsstr(commandLine, L"--interface")) { settings.page = 5; settings.settingsTab = 1; previewPath = L"work/preview-interface.png"; }
        else if (wcsstr(commandLine, L"--console")) { settings.page = 6; previewPath = L"work/preview-console.png"; }
        else if (wcsstr(commandLine, L"--effects")) { settings.page = 2; previewPath = L"work/preview-effects.png"; }
        else if (wcsstr(commandLine, L"--settings")) { settings.page = 5; previewPath = L"work/preview-settings.png"; }
        else if (wcsstr(commandLine, L"--misc")) { settings.page = 3; previewPath = L"work/preview-misc.png"; }
        else if (wcsstr(commandLine, L"--avatar")) { settings.page = 4; previewPath = L"work/preview-avatar.png"; }
        else if (wcsstr(commandLine, L"--aim")) { settings.page = 0; previewPath = L"work/preview-aim.png"; }
        else { settings.page = 1; previewPath = L"work/preview-esp.png"; }
        if (wcsstr(commandLine, L"--dark")) { settings.theme = 1; previewPath = L"work/preview-dark.png"; }
        if (wcsstr(commandLine, L"--compare")) { settings.comparePreview = true; previewPath = L"work/preview-compare.png"; }
        if (compactTest) previewPath = L"work/preview-compact.png";
        if (searchTest) previewPath = L"work/preview-search.png";
        if (wcsstr(commandLine, L"--crosshair-dot")) { settings.page = 5; settings.crosshairStyle = 1; previewPath = L"work/preview-crosshair-dot.png"; }
        if (wcsstr(commandLine, L"--crosshair-circle")) { settings.page = 5; settings.crosshairStyle = 2; previewPath = L"work/preview-crosshair-circle.png"; }
        if (wcsstr(commandLine, L"--reduced-motion")) settings.reducedMotion = true;
        if (teamHiddenTest || teamShownTest) {
            renderFixture[0].userId = 123;
            settings.teamOverrides[123] = TeamRelation::Ally;
            settings.showTeammates = teamShownTest;
            previewPath = L"work/preview-team-filter.png";
        }
    }
    history.Reset(settings);
    HWND target = nullptr;
    ULONGLONG nextSearch = 0;
    int frameCount = 0;
    uint64_t firstAnimationHash = 0;
    bool previousWindowFound = false;
    bool overlayReadyLogged = false;
    std::string previousStatus;
    bool previousScreenshot = false;
    ULONGLONG previousFrameAt = GetTickCount64();
    if (!smokeTest) log.Write(LogLevel::Info, "Waiting for Roblox window");
    while (running) {
        const ULONGLONG frameStarted = GetTickCount64();
        metrics.Update(smokeTest ? 1.0f / 60 : std::max(0.001f, static_cast<float>(frameStarted - previousFrameAt) / 1000));
        previousFrameAt = frameStarted;
        MSG message{};
        while (PeekMessageW(&message, nullptr, 0, 0, PM_REMOVE)) {
            TranslateMessage(&message);
            DispatchMessageW(&message);
            if (message.message == WM_QUIT) running = false;
        }
        if (!running) break;
        if (!smokeTest && GetTickCount64() >= nextSearch) {
            target = nullptr;
            EnumWindows(FindRobloxWindow, reinterpret_cast<LPARAM>(&target));
            nextSearch = GetTickCount64() + 1000;
            if ((target != nullptr) != previousWindowFound) {
                previousWindowFound = target != nullptr;
                log.Write(previousWindowFound ? LogLevel::Info : LogLevel::Warning,
                    previousWindowFound ? "Roblox window found" : "Roblox window closed or unavailable");
            }
        }
        if (!smokeTest) {
            const HWND foreground = GetForegroundWindow();
            const bool attached = settings.followRoblox && IsWindow(target);
            if (attached && (IsIconic(target) || (foreground != target && foreground != window))) {
                aim.Update(settings.aim, {}, target, menuOpen, 0, 0, 0, settings.maxDistance, settings.selectedPlayer);
                trigger.Update(settings.trigger, {}, target, menuOpen, 0, 0, 0, settings.maxDistance, settings.selectedPlayer);
                ShowWindow(window, SW_HIDE);
                Sleep(30);
                continue;
            }
            RECT rect = attached ? ClientScreenRect(target) : RECT{0, 0, screenWidth, screenHeight};
            RECT current{};
            GetWindowRect(window, &current);
            if (!EqualRect(&rect, &current)) {
                SetWindowPos(window, HWND_TOPMOST, rect.left, rect.top,
                    rect.right - rect.left, rect.bottom - rect.top, SWP_NOACTIVATE | SWP_SHOWWINDOW);
            } else if (!IsWindowVisible(window)) {
                ShowWindow(window, SW_SHOWNA);
            }
        }
        if (resizeWidth && resizeHeight) {
            context->OMSetRenderTargets(0, nullptr, nullptr);
            renderTarget.Reset();
            if (FAILED(swapChain->ResizeBuffers(0, resizeWidth, resizeHeight, DXGI_FORMAT_UNKNOWN, 0)) || !CreateRenderTarget()) {
                log.Write(LogLevel::Error, "Could not resize overlay graphics");
                exitCode = 1;
                break;
            }
            resizeWidth = resizeHeight = 0;
        }
        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        if (smokeTest) ImGui::GetIO().DeltaTime = 1.0f / 60;
        if (smokeTest && wcsstr(commandLine, L"--hover-preview")) ImGui::GetIO().AddMousePosEvent(70, 242);
        if (searchTest && frameCount == 1) {
            ImGui::GetIO().AddMousePosEvent(120, 97);
            ImGui::GetIO().AddMouseButtonEvent(0, true);
        }
        if (searchTest && frameCount == 2) {
            ImGui::GetIO().AddMouseButtonEvent(0, false);
            ImGui::GetIO().AddInputCharactersUTF8("jump");
        }
        ImGui::NewFrame();
        const ImVec2 viewport = ImGui::GetIO().DisplaySize;
        if (!smokeTest) {
            reader.Update(target, viewport.x, viewport.y, settings.effectScope != 0);
            if (reader.Status() != previousStatus) {
                previousStatus = reader.Status();
                log.Write(reader.Connected() ? LogLevel::Info : LogLevel::Warning, previousStatus);
            }
            aim.Update(settings.aim, reader.Boxes(), target, menuOpen, viewport.x, viewport.y,
                ImGui::GetIO().DeltaTime, settings.maxDistance, settings.selectedPlayer, settings.teamOverrides);
            trigger.Update(settings.trigger, reader.Boxes(), target, menuOpen, viewport.x, viewport.y,
                ImGui::GetIO().DeltaTime, settings.maxDistance, settings.selectedPlayer, settings.teamOverrides);
        }
        if (!menuOpen || !settings.pauseVisualsInMenu) {
            DrawPlayers(settings, viewport, smokeTest ? renderFixture : reader.Boxes());
            DrawAim(settings, viewport, aim);
        }
        DrawSessionStats(settings, metrics);
        if (trigger.Armed() && !menuOpen) {
            const char* label = "TRIGGER ARMED";
            const ImVec2 bounds = ImGui::CalcTextSize(label);
            ImGui::GetForegroundDrawList()->AddText(ImVec2((viewport.x - bounds.x) / 2, 18), IM_COL32(255, 135, 100, 255), label);
        }
        if (menuOpen) DrawMenu(settings, target != nullptr, reader, aim, trigger, metrics, history, log, running);
        if (settings.screenshotMode != previousScreenshot) {
            previousScreenshot = settings.screenshotMode;
            if (previousScreenshot) {
                settings.aim.enabled = settings.trigger.enabled = false;
                log.Write(LogLevel::Info, "Screenshot mode entered; aim and trigger disabled");
                if (!smokeTest) { menuOpen = false; SetMenuMode(window); }
            }
        }
        ImGui::Render();
        const float clear[4] = {0, 0, 0, 0};
        ID3D11RenderTargetView* targetView = renderTarget.Get();
        context->OMSetRenderTargets(1, &targetView, nullptr);
        context->ClearRenderTargetView(targetView, clear);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
        if (smokeTest) {
            ++frameCount;
            if (frameCount == 5) {
                exitCode = VerifyFrame(previewPath, &firstAnimationHash, !teamHiddenTest, !compactTest, uiAnimationTest) ? 0 : 2;
                if (searchTest && !ImGui::GetIO().WantTextInput) exitCode = 2;
                if (!animationTest || exitCode) break;
            }
            if (animationTest && frameCount == 35) {
                uint64_t secondHash = 0;
                exitCode = VerifyFrame(L"work/preview-animation.png", &secondHash, !teamHiddenTest, !compactTest, uiAnimationTest) &&
                    (settings.reducedMotion ? secondHash == firstAnimationHash : secondHash != firstAnimationHash) ? 0 : 2;
                break;
            }
        }
        const HRESULT result = swapChain->Present(0, 0);
        if (FAILED(result)) {
            log.Write(LogLevel::Error, "Overlay presentation failed");
            exitCode = 1;
            break;
        }
        if (!overlayReadyLogged && result != DXGI_STATUS_OCCLUDED) {
            log.Write(LogLevel::Info, "Overlay loaded successfully");
            overlayReadyLogged = true;
        }
        if (result == DXGI_STATUS_OCCLUDED) Sleep(30);
        else if (!smokeTest) {
            const ULONGLONG elapsed = GetTickCount64() - frameStarted;
            const DWORD frameBudget = 1000 / static_cast<DWORD>(std::clamp(settings.maxFps, 30, 240));
            if (elapsed < frameBudget) Sleep(static_cast<DWORD>(frameBudget - elapsed));
        }
    }
    if (!trigger.ReleasePendingInput()) {
        log.Write(LogLevel::Error, "Pending synthetic mouse-button release was not accepted");
        exitCode = 1;
    }
    UnregisterHotKey(window, 1);
    UnregisterHotKey(window, 2);
    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();
    renderTarget.Reset();
    swapChain.Reset();
    context.Reset();
    device.Reset();
    DestroyWindow(window);
    UnregisterClassW(cls.lpszClassName, instance);
    log.Write(exitCode ? LogLevel::Error : LogLevel::Info, smokeTest ?
        (exitCode ? "Render test failed" : "Render test passed") : (exitCode ? "Overlay stopped after an error" : "Overlay stopped"));
    return exitCode;
}
