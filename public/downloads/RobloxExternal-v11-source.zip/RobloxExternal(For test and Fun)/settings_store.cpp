#include "settings_store.hpp"
#include <commdlg.h>
#include <algorithm>
#include <array>
#include <atomic>
#include <charconv>
#include <cmath>
#include <fstream>
#include <limits>
#include <system_error>

namespace {
constexpr uintmax_t MaxProfileBytes = 64 * 1024;
constexpr size_t HistoryCapacity = 32;
std::string lastTestError;
enum class FieldKind { Boolean, Integer, Number };
struct Field {
    const wchar_t* key;
    FieldKind kind;
    double minimum, maximum;
    double (*read)(const OverlaySettings&);
    void (*write)(OverlaySettings&, double);
    bool history = true;
};

#define BOOL_FIELD(name, member) {L##name, FieldKind::Boolean, 0, 1, \
    [](const OverlaySettings& s) -> double { return s.member ? 1 : 0; }, \
    [](OverlaySettings& s, double v) { s.member = v != 0; }}
#define INT_FIELD(name, member, lo, hi) {L##name, FieldKind::Integer, lo, hi, \
    [](const OverlaySettings& s) -> double { return s.member; }, \
    [](OverlaySettings& s, double v) { s.member = static_cast<int>(v); }}
#define FLOAT_FIELD(name, member, lo, hi) {L##name, FieldKind::Number, lo, hi, \
    [](const OverlaySettings& s) -> double { return s.member; }, \
    [](OverlaySettings& s, double v) { s.member = static_cast<float>(v); }}

// Only this explicit whitelist crosses profile/history boundaries. Runtime IDs,
// relations, navigation, and screenshot mode remain local.
const Field Fields[] = {
    BOOL_FIELD("Enabled", enabled),
    BOOL_FIELD("FollowWindow", followRoblox),
    BOOL_FIELD("Boxes", boxes),
    BOOL_FIELD("Names", names),
    BOOL_FIELD("ShowTeammates", showTeammates),
    BOOL_FIELD("TeamLabels", teamLabels),
    BOOL_FIELD("TeamColors", teamColors),
    BOOL_FIELD("Distances", distances),
    BOOL_FIELD("HealthBars", healthBars),
    BOOL_FIELD("Crosshair", crosshair),
    BOOL_FIELD("PauseVisualsInMenu", pauseVisualsInMenu),
    BOOL_FIELD("Tracers", tracers),
    BOOL_FIELD("Skeleton", skeleton),
    BOOL_FIELD("Glow", glow),
    BOOL_FIELD("Rainbow", rainbow),
    BOOL_FIELD("Lava", lava),
    BOOL_FIELD("BodyOutline", bodyOutline),
    BOOL_FIELD("Electric", electric),
    BOOL_FIELD("Scan", scan),
    BOOL_FIELD("PulseOutline", pulseOutline),
    BOOL_FIELD("EdgeFlow", edgeFlow),
    BOOL_FIELD("DashedOutline", dashedOutline),
    BOOL_FIELD("TravellingHighlight", travellingHighlight),
    BOOL_FIELD("HealthPulse", healthPulse),
    BOOL_FIELD("ReducedMotion", reducedMotion),
    {L"PreviewEnabled", FieldKind::Boolean, 0, 1,
        [](const OverlaySettings& s) -> double { return s.previewEnabled; },
        [](OverlaySettings& s, double v) { s.previewEnabled = v != 0; }, false},
    {L"ComparePreview", FieldKind::Boolean, 0, 1,
        [](const OverlaySettings& s) -> double { return s.comparePreview; },
        [](OverlaySettings& s, double v) { s.comparePreview = v != 0; }, false},
    BOOL_FIELD("SessionStats", sessionStats),
    INT_FIELD("Theme", theme, 0, 1),
    FLOAT_FIELD("UiAccentRed", uiAccent[0], 0, 1),
    FLOAT_FIELD("UiAccentGreen", uiAccent[1], 0, 1),
    FLOAT_FIELD("UiAccentBlue", uiAccent[2], 0, 1),
    FLOAT_FIELD("GuiMotion", guiMotion, 0, 2),
    INT_FIELD("EffectPreset", effectPreset, 0, 4),
    INT_FIELD("EffectScope", effectScope, 0, 2),
    BOOL_FIELD("AimEnabled", aim.enabled),
    BOOL_FIELD("AimShowRadius", aim.showRadius),
    BOOL_FIELD("AimKeepTarget", aim.keepTarget),
    BOOL_FIELD("AimSelectedOnly", aim.selectedOnly),
    BOOL_FIELD("AimIgnoreTeammates", aim.ignoreTeammates),
    INT_FIELD("AimActivation", aim.activation, 0, 2),
    INT_FIELD("AimBone", aim.bone, 0, 2),
    FLOAT_FIELD("AimRadius", aim.radius, 20, 450),
    FLOAT_FIELD("AimSmoothing", aim.smoothTime, 0, .6),
    FLOAT_FIELD("AimGain", aim.gain, .05, 1.5),
    FLOAT_FIELD("AimStepLimit", aim.maxStep, 5, 250),
    BOOL_FIELD("TriggerEnabled", trigger.enabled),
    BOOL_FIELD("TriggerSelectedOnly", trigger.selectedOnly),
    INT_FIELD("TriggerActivation", trigger.activation, 0, 2),
    INT_FIELD("TriggerBone", trigger.bone, 0, 2),
    INT_FIELD("TriggerBurstLimit", trigger.burstLimit, 1, 3),
    FLOAT_FIELD("TriggerTolerance", trigger.tolerance, 1, 30),
    FLOAT_FIELD("TriggerDelay", trigger.delay, 0, 1),
    FLOAT_FIELD("TriggerCooldown", trigger.cooldown, .05, 2),
    INT_FIELD("BoxStyle", boxStyle, 0, 1),
    FLOAT_FIELD("Thickness", thickness, 1, 3),
    FLOAT_FIELD("GlowStrength", glowStrength, 0, 1),
    FLOAT_FIELD("RainbowSpeed", rainbowSpeed, .03, .6),
    FLOAT_FIELD("LavaOpacity", lavaOpacity, .1, 1),
    FLOAT_FIELD("LavaSpeed", lavaSpeed, 0, 3),
    FLOAT_FIELD("ScanSpeed", scanSpeed, .1, 2),
    FLOAT_FIELD("LabelSize", labelSize, 12, 20),
    FLOAT_FIELD("MaxDistance", maxDistance, 0, 10000),
    INT_FIELD("MaxFps", maxFps, 30, 240),
    INT_FIELD("CrosshairStyle", crosshairStyle, 0, 2),
    FLOAT_FIELD("CrosshairSize", crosshairSize, 1, 30),
    FLOAT_FIELD("CrosshairGap", crosshairGap, 0, 20),
    FLOAT_FIELD("CrosshairThickness", crosshairThickness, 1, 5),
    BOOL_FIELD("CrosshairOutline", crosshairOutline),
    FLOAT_FIELD("CrosshairRed", crosshairColor[0], 0, 1),
    FLOAT_FIELD("CrosshairGreen", crosshairColor[1], 0, 1),
    FLOAT_FIELD("CrosshairBlue", crosshairColor[2], 0, 1),
    FLOAT_FIELD("CrosshairAlpha", crosshairColor[3], 0, 1),
    BOOL_FIELD("LogAutoScroll", logAutoScroll),
    INT_FIELD("LogLevelFilter", logLevelFilter, 0, 2),
    FLOAT_FIELD("AccentRed", color[0], 0, 1),
    FLOAT_FIELD("AccentGreen", color[1], 0, 1),
    FLOAT_FIELD("AccentBlue", color[2], 0, 1),
    FLOAT_FIELD("AccentAlpha", color[3], 0, 1),
};
#undef BOOL_FIELD
#undef INT_FIELD
#undef FLOAT_FIELD

void Disarm(OverlaySettings& settings) {
    settings.aim.enabled = false;
    settings.trigger.enabled = false;
}

void CopyFields(const OverlaySettings& source, OverlaySettings& target, bool historyOnly) {
    for (const Field& field : Fields) {
        if (!historyOnly || field.history) field.write(target, field.read(source));
    }
}

bool SameSettings(const OverlaySettings& a, const OverlaySettings& b) {
    for (const Field& field : Fields) {
        if (field.history && field.read(a) != field.read(b)) return false;
    }
    return true;
}

OverlaySettings Snapshot(const OverlaySettings& source) {
    OverlaySettings result;
    CopyFields(source, result, true);
    return result;
}

std::string Narrow(const std::wstring& text) {
    std::string result;
    for (const wchar_t character : text) {
        if (character > 127) return {};
        result.push_back(static_cast<char>(character));
    }
    return result;
}

std::string KeyName(const wchar_t* key) { return Narrow(key); }

bool ReadValue(const std::filesystem::path& path, const wchar_t* section, const wchar_t* key,
    std::wstring& text, bool& present, std::string& error) {
    constexpr wchar_t Missing[] = L"\x1";
    std::array<wchar_t, 256> buffer{};
    const DWORD size = GetPrivateProfileStringW(section, key, Missing, buffer.data(),
        static_cast<DWORD>(buffer.size()), path.c_str());
    if (size >= buffer.size() - 1) {
        error = "Profile value is too long: " + KeyName(key);
        return false;
    }
    text.assign(buffer.data(), size);
    present = text != Missing;
    if (!present) {
        std::vector<wchar_t> keys(MaxProfileBytes + 2);
        const DWORD keySize = GetPrivateProfileStringW(section, nullptr, L"", keys.data(),
            static_cast<DWORD>(keys.size()), path.c_str());
        if (keySize >= keys.size() - 2) {
            error = "Profile key list is too long";
            return false;
        }
        for (const wchar_t* candidate = keys.data(); *candidate; candidate += wcslen(candidate) + 1) {
            if (_wcsicmp(candidate, key) == 0) { present = true; break; }
        }
    }
    return true;
}

bool ParseNumber(const std::wstring& text, const Field& field, double& value) {
    const std::string narrow = Narrow(text);
    if (narrow.empty()) return false;
    if (field.kind == FieldKind::Boolean) {
        if (narrow != "0" && narrow != "1") return false;
        value = narrow == "1" ? 1 : 0;
        return true;
    }
    if (field.kind == FieldKind::Integer) {
        long long integer = 0;
        const auto parsed = std::from_chars(narrow.data(), narrow.data() + narrow.size(), integer);
        if (parsed.ec != std::errc{} || parsed.ptr != narrow.data() + narrow.size()) return false;
        value = static_cast<double>(integer);
    } else {
        const auto parsed = std::from_chars(narrow.data(), narrow.data() + narrow.size(), value,
            std::chars_format::general);
        if (parsed.ec != std::errc{} || parsed.ptr != narrow.data() + narrow.size() || !std::isfinite(value)) return false;
    }
    value = std::clamp(value, field.minimum, field.maximum);
    return true;
}

std::wstring NumberText(double value, FieldKind kind) {
    std::array<char, 64> buffer{};
    std::to_chars_result result;
    if (kind == FieldKind::Number) {
        result = std::to_chars(buffer.data(), buffer.data() + buffer.size(), value,
            std::chars_format::general, std::numeric_limits<float>::max_digits10);
    } else {
        result = std::to_chars(buffer.data(), buffer.data() + buffer.size(), static_cast<int>(value));
    }
    if (result.ec != std::errc{}) return {};
    return std::wstring(buffer.data(), result.ptr);
}

bool WriteValue(const std::filesystem::path& path, const wchar_t* section, const wchar_t* key,
    const wchar_t* value, std::string& error) {
    if (WritePrivateProfileStringW(section, key, value, path.c_str())) return true;
    error = "Could not write profile (Windows error " + std::to_string(GetLastError()) + ")";
    return false;
}

bool AbsolutePath(const std::filesystem::path& path, std::filesystem::path& absolute, std::string& error) {
    if (path.empty()) {
        error = "No profile file selected";
        return false;
    }
    std::error_code ec;
    absolute = std::filesystem::absolute(path, ec);
    if (!ec) return true;
    error = "Invalid profile path";
    return false;
}

template <typename Replace, typename Pause>
bool ReplaceWithRetry(Replace&& replace, Pause&& pause, DWORD& error) {
    constexpr DWORD delays[] = {5, 10, 20, 40, 80, 140};
    for (size_t attempt = 0; ; ++attempt) {
        error = replace();
        if (error == ERROR_SUCCESS) return true;
        if ((error != ERROR_ACCESS_DENIED && error != ERROR_SHARING_VIOLATION && error != ERROR_LOCK_VIOLATION) ||
            attempt == std::size(delays)) return false;
        pause(delays[attempt]);
    }
}
}

bool SaveProfile(const std::filesystem::path& path, const OverlaySettings& settings, std::string& error) {
    error.clear();
    std::filesystem::path absolute;
    if (!AbsolutePath(path, absolute, error)) return false;
    OverlaySettings safe = settings;
    Disarm(safe);
    for (const Field& field : Fields) {
        if (!std::isfinite(field.read(safe))) {
            error = "Cannot save invalid setting: " + KeyName(field.key);
            return false;
        }
        field.write(safe, std::clamp(field.read(safe), field.minimum, field.maximum));
    }
    static std::atomic<unsigned int> sequence{0};
    std::filesystem::path temporary;
    HANDLE file = INVALID_HANDLE_VALUE;
    for (int attempt = 0; attempt < 16; ++attempt) {
        temporary = absolute;
        temporary += L".tmp-" + std::to_wstring(GetCurrentProcessId()) + L"-" + std::to_wstring(++sequence);
        file = CreateFileW(temporary.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, nullptr);
        if (file != INVALID_HANDLE_VALUE) break;
        if (GetLastError() != ERROR_FILE_EXISTS && GetLastError() != ERROR_ALREADY_EXISTS) break;
    }
    if (file == INVALID_HANDLE_VALUE) {
        error = "Could not create profile file (Windows error " + std::to_string(GetLastError()) + ")";
        return false;
    }
    CloseHandle(file);
    struct TempCleanup {
        std::filesystem::path path;
        ~TempCleanup() { if (!path.empty()) DeleteFileW(path.c_str()); }
    } cleanup{temporary};
    if (!WriteValue(temporary, L"Profile", L"Product", L"RobloxExternalVisualProfile", error) ||
        !WriteValue(temporary, L"Profile", L"Version", L"1", error)) return false;
    for (const Field& field : Fields) {
        const std::wstring value = NumberText(field.read(safe), field.kind);
        if (value.empty() || !WriteValue(temporary, L"Settings", field.key, value.c_str(), error)) return false;
    }
    WritePrivateProfileStringW(nullptr, nullptr, nullptr, temporary.c_str());
    WritePrivateProfileStringW(nullptr, nullptr, nullptr, absolute.c_str());
    DWORD replaceError = ERROR_SUCCESS;
    const bool replaced = ReplaceWithRetry([&]() -> DWORD {
        return MoveFileExW(temporary.c_str(), absolute.c_str(), MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH) ?
            ERROR_SUCCESS : GetLastError();
    }, [](DWORD delay) { Sleep(delay); }, replaceError);
    if (!replaced) {
        error = "Could not replace profile file (Windows error " + std::to_string(replaceError) + ")";
        return false;
    }
    cleanup.path.clear();
    return true;
}

bool LoadProfile(const std::filesystem::path& path, OverlaySettings& settings, std::string& error) {
    error.clear();
    std::filesystem::path absolute;
    if (!AbsolutePath(path, absolute, error)) return false;
    std::error_code ec;
    if (!std::filesystem::is_regular_file(absolute, ec) || ec) {
        error = "Profile file does not exist or is not a regular file";
        return false;
    }
    const uintmax_t size = std::filesystem::file_size(absolute, ec);
    if (ec || size > MaxProfileBytes) {
        error = ec ? "Cannot read profile file size" : "Profile exceeds the 64 KiB limit";
        return false;
    }
    std::wstring product, version;
    bool productPresent = false, versionPresent = false;
    if (!ReadValue(absolute, L"Profile", L"Product", product, productPresent, error) ||
        !ReadValue(absolute, L"Profile", L"Version", version, versionPresent, error)) return false;
    if (!productPresent || !versionPresent || product != L"RobloxExternalVisualProfile" || version != L"1") {
        error = "Unsupported profile product or version";
        return false;
    }
    OverlaySettings loaded;
    for (const Field& field : Fields) {
        std::wstring text;
        bool present = false;
        if (!ReadValue(absolute, L"Settings", field.key, text, present, error)) return false;
        if (!present) continue;
        double value = 0;
        if (!ParseNumber(text, field, value)) {
            error = "Invalid profile setting: " + KeyName(field.key);
            return false;
        }
        field.write(loaded, value);
    }
    Disarm(loaded);
    CopyFields(loaded, settings, false);
    return true;
}

std::filesystem::path ChooseProfilePath(HWND owner, bool save) {
    std::array<wchar_t, 32768> file{};
    if (save) wcscpy_s(file.data(), file.size(), L"Visual-profile.ini");
    OPENFILENAMEW dialog{};
    dialog.lStructSize = sizeof(dialog);
    dialog.hwndOwner = owner;
    dialog.lpstrFilter = L"Visual profiles (*.ini)\0*.ini\0\0";
    dialog.lpstrFile = file.data();
    dialog.nMaxFile = static_cast<DWORD>(file.size());
    dialog.lpstrDefExt = L"ini";
    dialog.lpstrTitle = save ? L"Export visual profile" : L"Import visual profile";
    dialog.Flags = OFN_EXPLORER | OFN_NOCHANGEDIR | OFN_PATHMUSTEXIST |
        (save ? OFN_OVERWRITEPROMPT : OFN_FILEMUSTEXIST);
    const BOOL selected = save ? GetSaveFileNameW(&dialog) : GetOpenFileNameW(&dialog);
    return selected ? std::filesystem::path(file.data()) : std::filesystem::path{};
}

void SettingsHistory::Reset(const OverlaySettings& settings) {
    snapshots_.clear();
    snapshots_.push_back(Snapshot(settings));
    position_ = 0;
}

void SettingsHistory::Capture(const OverlaySettings& settings) {
    if (snapshots_.empty()) { Reset(settings); return; }
    if (SameSettings(snapshots_[position_], settings)) return;
    snapshots_.erase(snapshots_.begin() + position_ + 1, snapshots_.end());
    snapshots_.push_back(Snapshot(settings));
    if (snapshots_.size() > HistoryCapacity) snapshots_.erase(snapshots_.begin());
    position_ = snapshots_.size() - 1;
}

bool SettingsHistory::CanUndo() const { return !snapshots_.empty() && position_ > 0; }
bool SettingsHistory::CanRedo() const { return !snapshots_.empty() && position_ + 1 < snapshots_.size(); }

bool SettingsHistory::Undo(OverlaySettings& settings) {
    if (!CanUndo()) return false;
    --position_;
    CopyFields(snapshots_[position_], settings, true);
    Disarm(settings);
    Disarm(snapshots_[position_]);
    return true;
}

bool SettingsHistory::Redo(OverlaySettings& settings) {
    if (!CanRedo()) return false;
    ++position_;
    CopyFields(snapshots_[position_], settings, true);
    Disarm(settings);
    Disarm(snapshots_[position_]);
    return true;
}

bool TestSettingsStore(const std::filesystem::path& scratch) {
    lastTestError.clear();
    const auto fail = [](const std::string& message) { lastTestError = message; return false; };
    DWORD replacementError = ERROR_SUCCESS, paused = 0;
    unsigned int attempts = 0;
    if (!ReplaceWithRetry([&]() -> DWORD {
        ++attempts;
        return attempts == 1 ? ERROR_ACCESS_DENIED : attempts == 2 ? ERROR_SHARING_VIOLATION : ERROR_SUCCESS;
    }, [&](DWORD delay) { paused += delay; }, replacementError) || attempts != 3 || paused != 15 ||
        replacementError != ERROR_SUCCESS) return fail("transient replace retry validation failed");
    paused = attempts = 0;
    if (ReplaceWithRetry([&]() -> DWORD { ++attempts; return ERROR_ACCESS_DENIED; },
        [&](DWORD delay) { paused += delay; }, replacementError) || attempts != 7 || paused != 295 ||
        replacementError != ERROR_ACCESS_DENIED) return fail("persistent replace denial was hidden or unbounded");
    paused = attempts = 0;
    if (ReplaceWithRetry([&]() -> DWORD { ++attempts; return ERROR_PATH_NOT_FOUND; },
        [&](DWORD delay) { paused += delay; }, replacementError) || attempts != 1 || paused != 0 ||
        replacementError != ERROR_PATH_NOT_FOUND) return fail("nontransient replace failure was retried");
    std::error_code ec;
    std::filesystem::create_directories(scratch, ec);
    if (ec) return fail("scratch folder creation failed: " + ec.message());
    static std::atomic<unsigned int> testSequence{0};
    const std::wstring suffix = L"-" + std::to_wstring(GetCurrentProcessId()) + L"-" +
        std::to_wstring(GetTickCount64()) + L"-" + std::to_wstring(++testSequence) + L".ini";
    const auto profile = std::filesystem::absolute(scratch / (L"settings-store-test" + suffix), ec);
    if (ec) return fail("scratch profile path invalid: " + ec.message());
    const auto oversized = std::filesystem::absolute(scratch / (L"settings-store-oversize" + suffix), ec);
    const auto missing = scratch / (L"settings-store-missing" + suffix);
    if (ec || std::filesystem::exists(profile) || std::filesystem::exists(oversized) || std::filesystem::exists(missing))
        return fail("scratch profile filename collision or invalid path");
    struct Cleanup {
        std::filesystem::path first, second;
        ~Cleanup() { std::error_code ignored; std::filesystem::remove(first, ignored); std::filesystem::remove(second, ignored); }
    } cleanup{profile, oversized};
    std::string error;
    OverlaySettings original;
    original.dashedOutline = true;
    original.healthPulse = true;
    original.aim.enabled = true;
    original.trigger.enabled = true;
    original.aim.gain = .85f;
    original.trigger.delay = .27f;
    original.color[0] = .37f;
    original.theme = 1;
    original.uiAccent[2] = .41f;
    original.crosshairGap = 9;
    original.selectedPlayer = 0x1234;
    original.page = 5;
    if (!SaveProfile(profile, original, error)) return fail("roundtrip save failed: " + error);
    OverlaySettings loaded;
    loaded.selectedPlayer = 0x5678;
    loaded.page = 2;
    if (!LoadProfile(profile, loaded, error) || loaded.aim.enabled || loaded.trigger.enabled ||
        !loaded.dashedOutline || !loaded.healthPulse || loaded.aim.gain != original.aim.gain ||
        loaded.trigger.delay != original.trigger.delay || loaded.color[0] != original.color[0] ||
        loaded.theme != original.theme || loaded.uiAccent[2] != original.uiAccent[2] ||
        loaded.crosshairGap != original.crosshairGap || loaded.selectedPlayer != 0x5678 ||
        loaded.page != 2) return fail("roundtrip load/settings/transient validation failed: " + error);
    for (int i = 0; i < 12; ++i) {
        OverlaySettings expected = original;
        for (const Field& field : Fields) field.write(expected, i % 2 ? field.minimum : field.maximum);
        Disarm(expected);
        if (!SaveProfile(profile, expected, error) || !LoadProfile(profile, loaded, error))
            return fail("repeated same-path save/load failed: " + error);
        for (const Field& field : Fields) {
            if (field.read(expected) != field.read(loaded))
                return fail("repeated same-path stale/incorrect field: " + KeyName(field.key));
        }
    }
    if (!SaveProfile(profile, original, error) || !LoadProfile(profile, loaded, error))
        return fail("restoring roundtrip values after same-path test failed: " + error);
    if (LoadProfile(missing, loaded, error) || error.empty()) return fail("missing profile was not rejected");
    if (!WriteValue(profile, L"Settings", L"UnknownOption", L"ignored", error) ||
        !WriteValue(profile, L"Settings", L"AimEnabled", L"1", error) ||
        !WriteValue(profile, L"Settings", L"TriggerEnabled", L"1", error) ||
        !LoadProfile(profile, loaded, error) || loaded.aim.enabled || loaded.trigger.enabled)
        return fail("unknown key/activation disable validation failed: " + error);
    if (!WriteValue(profile, L"Settings", L"AimRadius", L"1e30", error) ||
        !WriteValue(profile, L"Settings", L"MaxFps", L"-5000", error) ||
        !LoadProfile(profile, loaded, error) || loaded.aim.radius != 450 || loaded.maxFps != 30)
        return fail("extreme numeric clamping failed: " + error);
    const OverlaySettings unchanged = loaded;
    for (const wchar_t* bad : {L"NaN", L"inf", L"1e999", L"12junk", L"", L"\x1"}) {
        if (!WriteValue(profile, L"Settings", L"AimRadius", bad, error) ||
            LoadProfile(profile, loaded, error) || error.empty() || !SameSettings(unchanged, loaded))
            return fail("invalid floating-point value was not rejected atomically: " + error);
    }
    if (!SaveProfile(profile, original, error) ||
        !WriteValue(profile, L"Settings", L"MaxFps", L"120.5", error) ||
        LoadProfile(profile, loaded, error) ||
        !SaveProfile(profile, original, error) ||
        !WriteValue(profile, L"Settings", L"Boxes", L"true", error) ||
        LoadProfile(profile, loaded, error)) return fail("integer/boolean validation failed: " + error);
    if (!SaveProfile(profile, original, error) ||
        !WriteValue(profile, L"Profile", L"Product", L"OtherProduct", error) ||
        LoadProfile(profile, loaded, error) ||
        !SaveProfile(profile, original, error) ||
        !WriteValue(profile, L"Profile", L"Version", L"2", error) ||
        LoadProfile(profile, loaded, error)) return fail("schema rejection failed: " + error);
    {
        std::ofstream file(oversized, std::ios::binary);
        if (!file) return fail("oversized test file creation failed");
        const std::string padding(MaxProfileBytes + 1, 'x');
        file.write(padding.data(), static_cast<std::streamsize>(padding.size()));
    }
    if (LoadProfile(oversized, loaded, error) || error.empty()) return fail("oversized profile was not rejected");
    original.thickness = std::numeric_limits<float>::quiet_NaN();
    if (SaveProfile(profile, original, error) || error.empty()) return fail("nonfinite setting save was not rejected");

    OverlaySettings current;
    SettingsHistory history;
    history.Reset(current);
    current.page = 4;
    current.aimTab = 2;
    current.selectedPlayer = 77;
    current.previewEnabled = false;
    history.Capture(current);
    if (history.CanUndo() || history.CanRedo()) return fail("transient-only edits added history");
    current.thickness = 2;
    current.aim.enabled = true;
    current.trigger.enabled = true;
    history.Capture(current);
    current.thickness = 3;
    history.Capture(current);
    if (!history.Undo(current) || current.thickness != 2 || current.aim.enabled || current.trigger.enabled ||
        current.page != 4 || current.selectedPlayer != 77 || current.previewEnabled)
        return fail("history undo did not preserve transient state or disarm");
    history.Capture(current);
    if (!history.CanRedo() || !history.Redo(current) || current.thickness != 3 ||
        current.aim.enabled || current.trigger.enabled || !history.Undo(current)) return fail("history redo/capture failed");
    current.thickness = 2.5f;
    history.Capture(current);
    if (history.CanRedo()) return fail("history edit failed to discard redo branch");
    for (int i = 0; i < 60; ++i) { current.maxFps = 60 + i; history.Capture(current); }
    int undoCount = 0;
    while (history.Undo(current)) ++undoCount;
    return undoCount == static_cast<int>(HistoryCapacity - 1) || fail("history capacity validation failed");
}

const std::string& SettingsStoreTestError() { return lastTestError; }
