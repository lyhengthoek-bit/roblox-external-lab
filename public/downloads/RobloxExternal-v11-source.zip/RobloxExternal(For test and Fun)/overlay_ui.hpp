#pragma once
#include "imgui.h"
#include "player_reader.hpp"
#include "aim_assist.hpp"
#include "app_log.hpp"
#include "trigger_assist.hpp"

struct OverlaySettings {
    bool enabled = true;
    bool followRoblox = true;
    bool boxes = true;
    bool names = true;
    bool showTeammates = false;
    bool teamLabels = true;
    bool teamColors = true;
    TeamOverrides teamOverrides;
    bool distances = true;
    bool healthBars = true;
    bool crosshair = false;
    bool pauseVisualsInMenu = false;
    bool tracers = false;
    bool skeleton = false;
    bool glow = true;
    bool rainbow = false;
    bool lava = false;
    bool bodyOutline = false;
    bool electric = true;
    bool scan = false;
    bool pulseOutline = false;
    bool edgeFlow = false;
    bool dashedOutline = false;
    bool travellingHighlight = false;
    bool healthPulse = false;
    bool reducedMotion = false;
    bool previewEnabled = true;
    bool comparePreview = false;
    bool sessionStats = false;
    bool screenshotMode = false;
    float guiMotion = 1.0f;
    int theme = 0;
    float uiAccent[3] = {0.03f, 0.44f, 0.37f};
    int effectPreset = 0;
    int effectScope = 0;
    uintptr_t selectedPlayer = 0;
    AimSettings aim;
    TriggerSettings trigger;
    int aimTab = 0;
    int settingsTab = 0;
    int boxStyle = 1;
    int page = 0;
    float thickness = 1.5f;
    float glowStrength = 0.6f;
    float rainbowSpeed = 0.18f;
    float lavaOpacity = 0.82f;
    float lavaSpeed = 1.0f;
    float scanSpeed = 0.5f;
    float labelSize = 15.0f;
    float maxDistance = 0;
    int maxFps = 120;
    int crosshairStyle = 0;
    float crosshairSize = 8, crosshairGap = 4, crosshairThickness = 1.5f;
    bool crosshairOutline = true;
    float crosshairColor[4] = {0.95f, 0.98f, 1.0f, 0.9f};
    bool logAutoScroll = true;
    int logLevelFilter = 0;
    float color[4] = {0.25f, 0.95f, 0.72f, 1.0f};
};

void SetupOverlayStyle();
void DrawPlayers(const OverlaySettings& settings, ImVec2 viewport, const std::vector<PlayerBox>& players);
class RuntimeMetrics;
class SettingsHistory;
void DrawMenu(OverlaySettings& settings, bool targetFound, PlayerReader& reader, const AimAssist& aim,
    const TriggerAssist& trigger, const RuntimeMetrics& metrics, SettingsHistory& history, AppLog& log, bool& running);
std::string DiagnosticSummary(const PlayerReader& reader, bool targetFound);
void DrawLoading(const OverlaySettings& settings, const PlayerReader& reader, bool targetFound);
void DrawSessionStats(const OverlaySettings& settings, const RuntimeMetrics& metrics);
void DrawEffectPreview(const OverlaySettings& settings, ImVec2 position, ImVec2 size, bool comparison = false);
void DrawCrosshairPreview(const OverlaySettings& settings, ImVec2 center);
void DrawAim(const OverlaySettings& settings, ImVec2 viewport, const AimAssist& aim);
std::vector<PlayerBox> MakeRenderFixture();
