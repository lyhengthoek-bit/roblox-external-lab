#include "overlay_ui.hpp"
#include "settings_store.hpp"
#include "runtime_metrics.hpp"
#include <algorithm>
#include <cmath>
#include <filesystem>
#include <string>
#include <cctype>
#include <sstream>
#include <unordered_map>

namespace {
ImFont* labelFont = nullptr;
ImFont* headingFont = nullptr;
ImFont* iconFont = nullptr;
ImVec4 accent(0.03f, 0.44f, 0.37f, 1);
ImVec4 warning(0.59f, 0.35f, 0.06f, 1);
namespace Icons {
const char* Aim = "\xee\x82\xb0";
const char* ESP = "\xee\x94\xba";
const char* Effects = "\xee\x90\x96";
const char* Misc = "\xee\x8a\x99";
const char* Avatar = "\xee\x91\xac";
const char* Settings = "\xee\x85\x97";
const char* Close = "\xee\x86\xb1";
const char* Apply = "\xee\x81\xb0";
const char* Reset = "\xee\x85\x8b";
const char* Console = "\xee\x86\x84";
const char* Copy = "\xee\x82\xa2";
const char* Report = "\xee\x83\x90";
const char* Clear = "\xee\x86\x8d";
const char* Profiles = "\xee\x94\xad";
const char* Save = "\xee\x85\x90";
const char* Import = "\xee\x86\x9d";
const char* Export = "\xee\x82\xb6";
const char* Undo = "\xee\x8a\xa0";
const char* Redo = "\xee\x8a\x9f";
}
bool IconCommand(const char* icon, const char* label, bool showLabel = false) {
    ImGui::PushID(label);
    const ImVec2 position = ImGui::GetCursorScreenPos();
    const float width = showLabel ? ImGui::CalcTextSize(label).x + 44 : 30;
    const bool clicked = ImGui::Button("##Command", ImVec2(width, 30));
    auto* draw = ImGui::GetWindowDrawList();
    ImFont* font = iconFont ? iconFont : ImGui::GetFont();
    const char* glyph = iconFont ? icon : "?";
    const ImVec2 size = font->CalcTextSizeA(18, 100, 0, glyph);
    const auto color = ImGui::GetColorU32(ImGuiCol_Text);
    draw->AddText(font, 18, ImVec2(position.x + (showLabel ? 10 : (30 - size.x) / 2), position.y + (30 - size.y) / 2), color, glyph);
    if (showLabel) draw->AddText(ImVec2(position.x + 34, position.y + (30 - ImGui::GetFontSize()) / 2), color, label);
    if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", label);
    ImGui::PopID();
    return clicked;
}

ImVec2 Point(ScreenPoint p) { return {p.x, p.y}; }
ImU32 Color(ImVec4 color, float alpha = 1) {
    color.w *= alpha;
    return ImGui::ColorConvertFloat4ToU32(color);
}
float MotionTime(const OverlaySettings& settings) {
    return settings.reducedMotion ? 0.0f : static_cast<float>(ImGui::GetTime());
}
ImVec4 PlayerColor(const OverlaySettings& settings, float phase = 0) {
    if (!settings.rainbow) return {settings.color[0], settings.color[1], settings.color[2], settings.color[3]};
    ImVec4 color(0, 0, 0, settings.color[3]);
    const float hue = std::fmod(MotionTime(settings) * settings.rainbowSpeed + phase, 1.0f);
    ImGui::ColorConvertHSVtoRGB(hue, 0.8f, 1.0f, color.x, color.y, color.z);
    return color;
}
float Noise(uint32_t seed) {
    seed ^= seed >> 16; seed *= 0x7feb352d; seed ^= seed >> 15; seed *= 0x846ca68b; seed ^= seed >> 16;
    return static_cast<float>(seed & 65535) / 65535.0f;
}
ImVec2 SurfacePoint(const BodyFace& face, float u, float v) {
    const float weights[4] = {(1-u)*(1-v), u*(1-v), u*v, (1-u)*v};
    float x = 0, y = 0, depth = 0;
    for (int i = 0; i < 4; ++i) {
        const float weight = weights[i] * face.depth[i];
        x += face.points[i].x * weight;
        y += face.points[i].y * weight;
        depth += weight;
    }
    return depth > 0 ? ImVec2(x / depth, y / depth) : Point(face.points[0]);
}
void Line(ImDrawList* draw, ImVec2 a, ImVec2 b, ImVec4 color, const OverlaySettings& settings, float thickness) {
    if (settings.glow) {
        for (int layer = 4; layer > 0; --layer)
            draw->AddLine(a, b, Color(color, settings.glowStrength * 0.055f), thickness + layer * 2.3f);
    }
    draw->AddLine(a, b, Color(color), thickness);
}
void Box(ImDrawList* draw, ImVec2 top, ImVec2 bottom, ImVec4 color, const OverlaySettings& settings) {
    if (settings.boxStyle == 0) {
        if (settings.glow) for (int layer = 4; layer > 0; --layer)
            draw->AddRect(top, bottom, Color(color, settings.glowStrength * 0.055f), 0, 0, settings.thickness + layer * 2.3f);
        draw->AddRect(top, bottom, Color(color), 0, 0, settings.thickness);
        return;
    }
    const float x = std::min(25.0f, (bottom.x - top.x) * 0.25f);
    const float y = std::min(25.0f, (bottom.y - top.y) * 0.2f);
    for (int corner = 0; corner < 4; ++corner) {
        const bool right = corner & 1, lower = corner & 2;
        const ImVec2 p(right ? bottom.x : top.x, lower ? bottom.y : top.y);
        Line(draw, p, ImVec2(p.x + (right ? -x : x), p.y), color, settings, settings.thickness);
        Line(draw, p, ImVec2(p.x, p.y + (lower ? -y : y)), color, settings, settings.thickness);
    }
}
void Label(ImDrawList* draw, float center, float y, float size, ImU32 color, const char* text, ImVec2 viewport) {
    ImFont* font = labelFont ? labelFont : ImGui::GetFont();
    const ImVec2 bounds = font->CalcTextSizeA(size, viewport.x - 8, 0, text);
    const ImVec2 position(std::clamp(center - bounds.x / 2, 4.0f, std::max(4.0f, viewport.x - bounds.x - 4)),
        std::clamp(y, 2.0f, std::max(2.0f, viewport.y - bounds.y - 2)));
    for (int x : {-1, 1}) for (int dy : {-1, 1})
        draw->AddText(font, size, ImVec2(position.x + x, position.y + dy), IM_COL32(0, 0, 0, 210), text);
    draw->AddText(font, size, position, color, text);
}
void Lava(ImDrawList* draw, const PlayerBox& player, ImVec4 color, const OverlaySettings& settings) {
    for (const auto& face : player.faces) {
        ImVec2 vertices[4];
        // Face winding is clockwise in screen space; reverse for ImGui's fill API.
        for (int i = 0; i < 4; ++i) vertices[i] = Point(face.points[3 - i]);
        if (settings.lava) draw->AddConvexPolyFilled(vertices, 4, IM_COL32(8, 9, 14, static_cast<int>(settings.lavaOpacity * 255)));
        if (settings.scan) {
            const float position = std::fmod(MotionTime(settings) * settings.scanSpeed, 1.0f);
            const float first = std::max(0.0f, position - 0.025f), last = std::min(1.0f, position + 0.025f);
            const ImVec2 band[] = {SurfacePoint(face, 0, first), SurfacePoint(face, 0, last),
                SurfacePoint(face, 1, last), SurfacePoint(face, 1, first)};
            draw->AddConvexPolyFilled(band, 4, Color(color, 0.35f));
            Line(draw, SurfacePoint(face, 0, position), SurfacePoint(face, 1, position), color, settings, 1.2f);
        }
        for (int crack = 0; settings.lava && crack < 4; ++crack) {
            const uint32_t seed = face.seed + crack * 293;
            const bool horizontal = Noise(seed + 1) > 0.5f;
            const float base = 0.1f + Noise(seed + 2) * 0.8f;
            ImVec2 previous = SurfacePoint(face, horizontal ? 0 : base, horizontal ? base : 0);
            for (int step = 1; step <= 7; ++step) {
                const float along = step / 7.0f;
                const float across = std::clamp(base + (Noise(seed + step * 17) - 0.5f) * 0.3f, 0.01f, 0.99f);
                const ImVec2 next = SurfacePoint(face, horizontal ? along : across, horizontal ? across : along);
                const float pulse = settings.reducedMotion ? 1.0f : 0.7f + 0.3f * std::sin(MotionTime(settings) * settings.lavaSpeed * 2 + Noise(seed) * 6.28f);
                ImVec4 crackColor = settings.rainbow || settings.effectPreset == 1 || settings.effectPreset == 3 ?
                    color : ImVec4(0.82f, 0.75f, 1, 1);
                crackColor.w = pulse;
                if (settings.glow) draw->AddLine(previous, next, Color(crackColor, settings.glowStrength * 0.18f), 4.0f);
                draw->AddLine(previous, next, Color(crackColor), 1.0f);
                if (settings.electric) {
                    const float travel = std::fmod(MotionTime(settings) * settings.lavaSpeed * 0.6f + Noise(seed + 55), 1.0f) * 7;
                    if (travel >= step - 1 && travel < step) {
                        const float fraction = travel - (step - 1);
                        const ImVec2 spark(previous.x + (next.x - previous.x) * fraction,
                            previous.y + (next.y - previous.y) * fraction);
                        draw->AddCircleFilled(spark, 4, Color(crackColor, 0.22f), 12);
                        draw->AddCircleFilled(spark, 1.5f, IM_COL32(240, 250, 255, 255), 8);
                    }
                }
                if (step == 3 || step == 5) {
                    const float branchAlong = std::clamp(along + 0.16f, 0.0f, 1.0f);
                    const float branchAcross = std::clamp(across + (Noise(seed + step) > 0.5f ? 0.16f : -0.16f), 0.01f, 0.99f);
                    draw->AddLine(next, SurfacePoint(face, horizontal ? branchAlong : branchAcross,
                        horizontal ? branchAcross : branchAlong), Color(crackColor, 0.8f), 0.8f);
                }
                previous = next;
            }
        }
    }
}
void TravellingHighlight(ImDrawList* draw, const PlayerBox& player, ImVec4 color, const OverlaySettings& settings) {
    const float position = settings.reducedMotion ? 0.5f : std::fmod(MotionTime(settings) * settings.scanSpeed, 1.0f);
    for (const auto& face : player.faces) {
        for (int layer = 3; layer > 0; --layer) {
            const float halfWidth = 0.025f * layer;
            const float first = std::max(0.0f, position - halfWidth), last = std::min(1.0f, position + halfWidth);
            const ImVec2 band[] = {SurfacePoint(face, first, 0), SurfacePoint(face, first, 1),
                SurfacePoint(face, last, 1), SurfacePoint(face, last, 0)};
            draw->AddConvexPolyFilled(band, 4, Color(color, 0.12f));
        }
        Line(draw, SurfacePoint(face, position, 0), SurfacePoint(face, position, 1),
            ImVec4(0.91f, 0.99f, 1.0f, color.w), settings, settings.thickness);
    }
}
void DashedOutline(ImDrawList* draw, const std::vector<ImVec2>& points, ImVec4 color, const OverlaySettings& settings) {
    if (points.size() < 2) return;
    constexpr float period = 18.0f, dash = 10.0f;
    const float phase = std::fmod(MotionTime(settings) * settings.scanSpeed * 36.0f, period);
    float offset = 0;
    int segments = 0;
    for (size_t i = 0; i < points.size(); ++i) {
        const ImVec2 a = points[i], b = points[(i + 1) % points.size()];
        const float length = std::hypot(b.x - a.x, b.y - a.y);
        if (std::isfinite(length) && length > 0) {
            float start = std::floor((offset + phase) / period) * period - phase;
            for (; start < offset + length && segments < 256; start += period, ++segments) {
                const float first = std::max(start, offset), last = std::min(start + dash, offset + length);
                if (last <= first) continue;
                const float u = (first - offset) / length, v = (last - offset) / length;
                Line(draw, ImVec2(a.x + (b.x - a.x) * u, a.y + (b.y - a.y) * u),
                    ImVec2(a.x + (b.x - a.x) * v, a.y + (b.y - a.y) * v), color, settings, settings.thickness);
            }
        }
        offset += length;
        if (segments >= 256 || !std::isfinite(offset)) break;
    }
}
struct HealthChange {
    float health = 0, maximum = 0;
    double changedAt = -10, seenAt = 0;
    uint64_t userId = 0;
    bool lostHealth = false;
    uint64_t seenFrame = 0;
};
using HealthChanges = std::unordered_map<uintptr_t, HealthChange>;
HealthChanges healthChanges;
uint64_t healthFrame = 0;
void ObserveHealth(const std::vector<PlayerBox>& players) {
    const double now = ImGui::GetTime();
    ++healthFrame;
    for (const auto& player : players) {
        if (!player.id || !std::isfinite(player.health) || player.health <= 0 ||
            !std::isfinite(player.maxHealth) || player.maxHealth <= 0) continue;
        auto found = healthChanges.find(player.id);
        if (found == healthChanges.end()) {
            if (healthChanges.size() >= 512) continue;
            found = healthChanges.emplace(player.id, HealthChange{player.health, player.maxHealth, -10, now, player.userId, false}).first;
        }
        auto& previous = found->second;
        if (now - previous.seenAt > 1.0 || previous.userId != player.userId || std::abs(previous.maximum - player.maxHealth) > 0.01f)
            previous.changedAt = -10;
        else if (std::abs(previous.health - player.health) > 0.01f) {
            previous.changedAt = now;
            previous.lostHealth = player.health < previous.health;
        }
        previous.health = player.health;
        previous.maximum = player.maxHealth;
        previous.userId = player.userId;
        previous.seenAt = now;
        previous.seenFrame = healthFrame;
    }
    for (auto it = healthChanges.begin(); it != healthChanges.end();) {
        if (it->second.seenFrame != healthFrame) it = healthChanges.erase(it);
        else ++it;
    }
}
void HealthPulse(ImDrawList* draw, const PlayerBox& player, const OverlaySettings& settings, const HealthChanges* changes) {
    if (!settings.healthPulse || settings.reducedMotion || !changes) return;
    const auto found = changes->find(player.id);
    if (found == changes->end()) return;
    const float elapsed = static_cast<float>(ImGui::GetTime() - found->second.changedAt);
    if (elapsed < 0 || elapsed > 0.65f) return;
    const float alpha = (1.0f - elapsed / 0.65f) * (1.0f - elapsed / 0.65f);
    const ImVec4 color = found->second.lostHealth ? ImVec4(1, 0.25f, 0.2f, alpha) : ImVec4(0.25f, 1, 0.65f, alpha);
    for (const auto& polygon : player.silhouettes) {
        if (polygon.size() < 3) continue;
        std::vector<ImVec2> points;
        points.reserve(polygon.size());
        for (const auto point : polygon) points.push_back(Point(point));
        draw->AddConvexPolyFilled(points.data(), static_cast<int>(points.size()), Color(color, 0.16f));
        draw->AddPolyline(points.data(), static_cast<int>(points.size()), Color(color), ImDrawFlags_Closed, settings.thickness + 1.5f);
    }
}
void Section(const char* name) {
    ImGui::Spacing();
    ImGui::TextColored(ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled), "%s", name);
    ImGui::Separator();
    ImGui::Spacing();
}
}

void SetupOverlayStyle() {
    auto& io = ImGui::GetIO();
    wchar_t windows[MAX_PATH]{};
    if (GetWindowsDirectoryW(windows, MAX_PATH)) {
        auto regular = std::filesystem::path(windows) / "Fonts" / "segoeui.ttf";
        auto bold = std::filesystem::path(windows) / "Fonts" / "seguisb.ttf";
        if (std::filesystem::exists(regular)) {
            io.FontDefault = io.Fonts->AddFontFromFileTTF(regular.string().c_str(), 17.0f);
            labelFont = io.Fonts->AddFontFromFileTTF(regular.string().c_str(), 15.0f);
        }
        if (std::filesystem::exists(bold)) headingFont = io.Fonts->AddFontFromFileTTF(bold.string().c_str(), 22.0f);
    }
    HRSRC resource = FindResourceW(GetModuleHandleW(nullptr), MAKEINTRESOURCEW(101), RT_RCDATA);
    if (resource) {
        HGLOBAL loaded = LoadResource(GetModuleHandleW(nullptr), resource);
        const DWORD bytes = SizeofResource(GetModuleHandleW(nullptr), resource);
        static const ImWchar ranges[] = {0xe000, 0xefff, 0};
        ImFontConfig config;
        config.FontDataOwnedByAtlas = false;
        if (loaded && bytes) iconFont = io.Fonts->AddFontFromMemoryTTF(LockResource(loaded), bytes, 22, &config, ranges);
    }
    ImGui::StyleColorsLight();
    auto& style = ImGui::GetStyle();
    style.FontSizeBase = 17;
    style.WindowPadding = ImVec2(24, 20);
    style.FramePadding = ImVec2(10, 5);
    style.ItemSpacing = ImVec2(14, 9);
    style.WindowRounding = 6;
    style.FrameRounding = 4;
    style.PopupRounding = 4;
    style.GrabRounding = 3;
    style.TabRounding = 3;
    style.WindowBorderSize = 1;
    style.Colors[ImGuiCol_WindowBg] = ImVec4(1, 1, 1, 1);
    style.Colors[ImGuiCol_PopupBg] = ImVec4(1, 1, 1, 1);
    style.Colors[ImGuiCol_Border] = ImVec4(0.82f, 0.85f, 0.86f, 1);
    style.Colors[ImGuiCol_Separator] = ImVec4(0.88f, 0.9f, 0.91f, 1);
    style.Colors[ImGuiCol_Text] = ImVec4(0.11f, 0.15f, 0.18f, 1);
    style.Colors[ImGuiCol_TextDisabled] = ImVec4(0.42f, 0.47f, 0.5f, 1);
    style.Colors[ImGuiCol_FrameBg] = ImVec4(0.94f, 0.96f, 0.96f, 1);
    style.Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.88f, 0.92f, 0.92f, 1);
    style.Colors[ImGuiCol_FrameBgActive] = ImVec4(0.83f, 0.89f, 0.89f, 1);
    style.Colors[ImGuiCol_CheckMark] = accent;
    style.Colors[ImGuiCol_SliderGrab] = accent;
    style.Colors[ImGuiCol_SliderGrabActive] = accent;
    style.Colors[ImGuiCol_Button] = ImVec4(0.94f, 0.96f, 0.96f, 1);
    style.Colors[ImGuiCol_ButtonHovered] = ImVec4(0.85f, 0.92f, 0.9f, 1);
    style.Colors[ImGuiCol_ButtonActive] = ImVec4(0.77f, 0.87f, 0.84f, 1);
    style.Colors[ImGuiCol_Header] = ImVec4(0.87f, 0.94f, 0.91f, 1);
    style.Colors[ImGuiCol_HeaderHovered] = ImVec4(0.81f, 0.9f, 0.87f, 1);
    style.Colors[ImGuiCol_HeaderActive] = ImVec4(0.77f, 0.87f, 0.84f, 1);
    style.Colors[ImGuiCol_Tab] = ImVec4(0.09f, 0.1f, 0.12f, 1);
    style.Colors[ImGuiCol_TabSelected] = ImVec4(0.17f, 0.2f, 0.22f, 1);
    style.Colors[ImGuiCol_TabHovered] = ImVec4(0.21f, 0.24f, 0.27f, 1);
    style.Colors[ImGuiCol_TabSelectedOverline] = accent;
}

namespace {
void RenderPlayers(const OverlaySettings& settings, ImDrawList* draw, ImVec2 areaMin, ImVec2 areaMax,
    const std::vector<PlayerBox>& players, const HealthChanges* changes = nullptr) {
    if (!settings.enabled) return;
    const ImVec2 viewport = ImGui::GetIO().DisplaySize;
    draw->PushClipRect(areaMin, areaMax, true);
    for (const auto& player : players) {
        if (!std::isfinite(player.health) || player.health <= 0) continue;
        const auto relation = RelationFor(player, settings.teamOverrides);
        if ((settings.maxDistance > 0 && player.distance > settings.maxDistance) ||
            (!player.isLocal && relation == TeamRelation::Ally && !settings.showTeammates)) continue;
        const auto effectColor = PlayerColor(settings);
        auto color = effectColor;
        if (settings.teamColors && !settings.rainbow && relation == TeamRelation::Ally) color = ImVec4(0.3f, 0.85f, 0.65f, 1);
        else if (settings.teamColors && !settings.rainbow && relation == TeamRelation::Enemy) color = ImVec4(1, 0.42f, 0.35f, 1);
        const ImVec2 top = Point(player.topLeft), bottom = Point(player.bottomRight);
        const float center = (top.x + bottom.x) * 0.5f;
        const bool selected = settings.effectScope == 0 ? !player.isLocal :
            settings.effectScope == 1 ? player.id == settings.selectedPlayer : player.isLocal;
        if (player.isLocal && (bottom.x - top.x) * (bottom.y - top.y) > (areaMax.x - areaMin.x) * (areaMax.y - areaMin.y) * 0.7f) continue;
        if (selected && (settings.lava || settings.scan)) Lava(draw, player, effectColor, settings);
        if (selected && settings.travellingHighlight) TravellingHighlight(draw, player, effectColor, settings);
        if (selected) HealthPulse(draw, player, settings, changes);
        if (selected && (settings.bodyOutline || settings.edgeFlow || settings.dashedOutline)) for (const auto& polygon : player.silhouettes) {
            if (polygon.size() < 2) continue;
            std::vector<ImVec2> points;
            for (auto p : polygon) points.push_back(Point(p));
            const float pulse = settings.pulseOutline && !settings.reducedMotion ? 0.6f + 0.4f * std::sin(MotionTime(settings) * settings.lavaSpeed * 3) : 1;
            if (settings.bodyOutline) {
                if (settings.glow) draw->AddPolyline(points.data(), static_cast<int>(points.size()),
                    Color(effectColor, settings.glowStrength * 0.18f * pulse), ImDrawFlags_Closed, settings.thickness + 4);
                draw->AddPolyline(points.data(), static_cast<int>(points.size()), Color(effectColor, pulse), ImDrawFlags_Closed, settings.thickness);
            }
            if (settings.dashedOutline) DashedOutline(draw, points, effectColor, settings);
            if (settings.edgeFlow) {
                float perimeter = 0;
                for (size_t i = 0; i < points.size(); ++i) {
                    const auto a = points[i], b = points[(i + 1) % points.size()];
                    perimeter += std::hypot(b.x - a.x, b.y - a.y);
                }
                const float start = std::fmod(MotionTime(settings) * settings.scanSpeed, 1.0f) * perimeter;
                for (int wrap = 0; wrap < 2; ++wrap) {
                    const float first = start - wrap * perimeter, last = first + perimeter * 0.18f;
                    float offset = 0;
                    for (size_t i = 0; i < points.size(); ++i) {
                        const auto a = points[i], b = points[(i + 1) % points.size()];
                        const float length = std::hypot(b.x - a.x, b.y - a.y);
                        const float left = std::max(first, offset), right = std::min(last, offset + length);
                        if (length > 0 && right > left) {
                            const float u = (left - offset) / length, v = (right - offset) / length;
                            Line(draw, ImVec2(a.x + u * (b.x - a.x), a.y + u * (b.y - a.y)),
                                ImVec2(a.x + v * (b.x - a.x), a.y + v * (b.y - a.y)), ImVec4(0.92f, 0.98f, 1, 1), settings, 2);
                        }
                        offset += length;
                    }
                }
            }
        }
        if (player.isLocal) continue;
        if (settings.boxes) Box(draw, top, bottom, color, settings);
        if (settings.skeleton) for (const auto& bone : player.bones)
            Line(draw, Point(bone.start), Point(bone.end), color, settings, settings.thickness);
        if (settings.tracers) Line(draw, ImVec2((areaMin.x + areaMax.x) / 2, areaMax.y - 8),
            ImVec2(center, bottom.y), color, settings, settings.thickness);
        if (settings.names && !settings.screenshotMode) {
            const std::string tag = !settings.teamLabels ? "" : relation == TeamRelation::Ally ? "[TEAM] " :
                relation == TeamRelation::Enemy ? "[ENEMY] " : "[?] ";
            const std::string name = tag + player.name;
            Label(draw, center, top.y - settings.labelSize - 7, settings.labelSize,
                settings.teamLabels ? Color(color) : IM_COL32(245, 247, 250, 255), name.c_str(), viewport);
        }
        if (settings.distances && !settings.screenshotMode && player.distance >= 0) {
            const std::string text = std::to_string(static_cast<int>(player.distance)) + " studs";
            Label(draw, center, bottom.y + 5, settings.labelSize - 1, Color(color), text.c_str(), viewport);
        }
        if (settings.healthBars && std::isfinite(player.health) && std::isfinite(player.maxHealth) && player.maxHealth > 0) {
            const float fraction = std::clamp(player.health / player.maxHealth, 0.0f, 1.0f);
            const float x = std::max(2.0f, top.x - 7);
            draw->AddRectFilled(ImVec2(x - 1, top.y - 1), ImVec2(x + 4, bottom.y + 1), IM_COL32(22, 26, 30, 255), 1);
            const ImVec4 healthColor(1 - fraction, 0.25f + fraction * 0.65f, 0.25f, 1);
            draw->AddRectFilled(ImVec2(x, bottom.y - (bottom.y - top.y) * fraction), ImVec2(x + 3, bottom.y), Color(healthColor));
        }
    }
    draw->PopClipRect();
}
}

void DrawPlayers(const OverlaySettings& settings, ImVec2 viewport, const std::vector<PlayerBox>& players) {
    if (!settings.enabled) {
        healthChanges.clear();
        return;
    }
    ObserveHealth(players);
    RenderPlayers(settings, ImGui::GetBackgroundDrawList(), ImVec2(0, 0), viewport, players, &healthChanges);
}

namespace {
void Crosshair(const OverlaySettings& settings, ImDrawList* draw, ImVec2 center) {
    const ImU32 color = Color(ImVec4(settings.crosshairColor[0], settings.crosshairColor[1], settings.crosshairColor[2], settings.crosshairColor[3]));
    const ImU32 outline = IM_COL32(12, 18, 22, static_cast<int>(settings.crosshairColor[3] * 230));
    const float size = std::clamp(settings.crosshairSize, 1.0f, 40.0f);
    const float gap = std::clamp(settings.crosshairGap, 0.0f, 24.0f);
    const float thickness = std::clamp(settings.crosshairThickness, 0.5f, 8.0f);
    if (settings.crosshairStyle == 1) {
        const float radius = std::max(1.0f, size * 0.25f);
        if (settings.crosshairOutline) draw->AddCircleFilled(center, radius + 1.5f, outline, 24);
        draw->AddCircleFilled(center, radius, color, 24);
    } else if (settings.crosshairStyle == 2) {
        if (settings.crosshairOutline) draw->AddCircle(center, size, outline, 64, thickness + 2.0f);
        draw->AddCircle(center, size, color, 64, thickness);
    } else {
        const ImVec2 starts[] = {{center.x - gap - size, center.y}, {center.x + gap, center.y},
            {center.x, center.y - gap - size}, {center.x, center.y + gap}};
        const ImVec2 ends[] = {{center.x - gap, center.y}, {center.x + gap + size, center.y},
            {center.x, center.y - gap}, {center.x, center.y + gap + size}};
        for (int i = 0; i < 4; ++i) {
            if (settings.crosshairOutline) draw->AddLine(starts[i], ends[i], outline, thickness + 2.0f);
            draw->AddLine(starts[i], ends[i], color, thickness);
        }
    }
}
}

void DrawCrosshairPreview(const OverlaySettings& settings, ImVec2 center) {
    Crosshair(settings, ImGui::GetWindowDrawList(), center);
}

void DrawAim(const OverlaySettings& settings, ImVec2 viewport, const AimAssist& aim) {
    if (settings.crosshair) Crosshair(settings, ImGui::GetBackgroundDrawList(), ImVec2(viewport.x / 2, viewport.y / 2));
    if (!settings.aim.enabled) return;
    auto* draw = ImGui::GetBackgroundDrawList();
    if (settings.aim.showRadius) draw->AddCircle(ImVec2(viewport.x / 2, viewport.y / 2),
        settings.aim.radius, IM_COL32(210, 220, 230, 70), 96, 1);
    if (aim.TargetId()) {
        const auto p = aim.TargetPoint();
        draw->AddCircle(Point(p), 4, Color(accent), 16, 1.5f);
    }
}

void DrawLoading(const OverlaySettings& settings, const PlayerReader& reader, bool targetFound) {
    const ImVec2 top = ImGui::GetCursorScreenPos();
    const float width = std::max(100.0f, ImGui::GetContentRegionAvail().x);
    auto* draw = ImGui::GetWindowDrawList();
    const auto& status = reader.Status();
    const bool failed = status.find("failed") != std::string::npos || status.find("unreadable") != std::string::npos ||
        status.find("Invalid") != std::string::npos || status.find("does not match") != std::string::npos;
    const bool ready = targetFound && reader.Connected();
    const char* stage = failed ? "Data unavailable" : ready ? "Player data connected" :
        targetFound ? "Waiting for player data" : "Finding Roblox window";
    const ImVec4 color = failed ? ImVec4(0.73f, 0.31f, 0.13f, 1) : accent;
    const ImVec2 center(top.x + 8, top.y + 9);
    if (ready || failed || settings.reducedMotion || settings.guiMotion <= 0) {
        draw->AddCircle(center, 6, Color(color), 20, 1.5f);
        draw->AddCircleFilled(center, 2.5f, Color(color), 12);
    } else {
        const float start = static_cast<float>(ImGui::GetTime()) * 4.0f * std::clamp(settings.guiMotion, 0.1f, 2.0f);
        draw->PathArcTo(center, 6, start, start + 4.7f, 22);
        draw->PathStroke(Color(color), ImDrawFlags_None, 1.8f);
    }
    draw->AddText(ImVec2(top.x + 24, top.y), Color(color), stage);
    constexpr float gutter = 6;
    const float segment = (width - 2 * gutter) / 3;
    for (int i = 0; i < 3; ++i) {
        const bool complete = i == 0 || (i == 1 && targetFound) || (i == 2 && ready);
        const float x = top.x + i * (segment + gutter);
        draw->AddRectFilled(ImVec2(x, top.y + 28), ImVec2(x + segment, top.y + 31),
            complete ? Color(accent, 0.8f) : IM_COL32(225, 232, 232, 255), 1);
    }
    ImGui::Dummy(ImVec2(width, 42));
    if (ImGui::IsItemHovered()) ImGui::SetTooltip("Graphics ready | Window %s | Player data %s\n%s",
        targetFound ? "found" : "pending", ready ? "connected" : "pending", status.c_str());
}

namespace {
PlayerBox PreviewPlayer(ImVec2 top, ImVec2 bottom) {
    PlayerBox player = MakeRenderFixture().front();
    const float sourceWidth = player.bottomRight.x - player.topLeft.x;
    const float sourceHeight = player.bottomRight.y - player.topLeft.y;
    const float scale = std::min((bottom.x - top.x) / (sourceWidth + 20), (bottom.y - top.y) / sourceHeight);
    const ScreenPoint origin = player.topLeft;
    const ImVec2 start((top.x + bottom.x - sourceWidth * scale) * 0.5f,
        (top.y + bottom.y - sourceHeight * scale) * 0.5f);
    const auto transform = [&](ScreenPoint point) {
        return ScreenPoint{start.x + (point.x - origin.x) * scale, start.y + (point.y - origin.y) * scale};
    };
    player.topLeft = transform(player.topLeft);
    player.bottomRight = transform(player.bottomRight);
    for (auto& face : player.faces) for (auto& point : face.points) point = transform(point);
    for (auto& polygon : player.silhouettes) for (auto& point : polygon) point = transform(point);
    for (auto& bone : player.bones) { bone.start = transform(bone.start); bone.end = transform(bone.end); }
    for (auto& point : player.aimPoints) point = transform(point);
    player.relation = TeamRelation::Unknown;
    return player;
}
void PreviewView(const OverlaySettings& settings, ImDrawList* draw, ImVec2 top, ImVec2 bottom, const char* label) {
    draw->PushClipRect(top, bottom, true);
    draw->AddText(ImVec2(top.x + 10, top.y + 9), IM_COL32(65, 80, 87, 255), label);
    const ImVec2 bodyTop(top.x + 14, top.y + 38), bodyBottom(bottom.x - 14, bottom.y - 20);
    const PlayerBox dummy = PreviewPlayer(bodyTop, bodyBottom);
    for (const auto& polygon : dummy.silhouettes) {
        std::vector<ImVec2> points;
        for (const auto point : polygon) points.push_back(Point(point));
        draw->AddConvexPolyFilled(points.data(), static_cast<int>(points.size()), IM_COL32(179, 193, 199, 255));
        draw->AddPolyline(points.data(), static_cast<int>(points.size()), IM_COL32(130, 149, 157, 255), ImDrawFlags_Closed, 1);
    }
    OverlaySettings preview = settings;
    preview.effectScope = 0;
    preview.showTeammates = true;
    preview.names = false;
    preview.distances = false;
    preview.teamLabels = false;
    preview.maxDistance = 0;
    RenderPlayers(preview, draw, bodyTop, bodyBottom, {dummy});
    draw->PopClipRect();
}
}

void DrawEffectPreview(const OverlaySettings& settings, ImVec2 position, ImVec2 size, bool comparison) {
    if (size.x < 70 || size.y < 80) return;
    auto* draw = ImGui::GetWindowDrawList();
    const ImVec2 bottom(position.x + size.x, position.y + size.y);
    draw->PushClipRect(position, bottom, true);
    draw->AddRectFilled(position, bottom, IM_COL32(245, 248, 249, 255), 4);
    draw->AddRect(position, bottom, IM_COL32(222, 231, 234, 255), 4);
    if (comparison) {
        const float middle = position.x + size.x * 0.5f;
        OverlaySettings minimal = settings;
        minimal.enabled = true;
        minimal.boxes = true;
        minimal.boxStyle = 1;
        minimal.glow = minimal.rainbow = minimal.lava = minimal.electric = minimal.scan = false;
        minimal.bodyOutline = minimal.pulseOutline = minimal.edgeFlow = minimal.skeleton = false;
        minimal.dashedOutline = minimal.travellingHighlight = minimal.healthPulse = minimal.tracers = false;
        PreviewView(minimal, draw, position, ImVec2(middle, bottom.y), "Minimal");
        draw->AddLine(ImVec2(middle, position.y + 10), ImVec2(middle, bottom.y - 10), IM_COL32(223, 232, 235, 255));
        PreviewView(settings, draw, ImVec2(middle, position.y), bottom, "Current");
    } else PreviewView(settings, draw, position, bottom, "Current");
    draw->PopClipRect();
}

namespace {
void ConsolePage(OverlaySettings& settings, PlayerReader& reader, bool targetFound, AppLog& log) {
    Section("SESSION LOG");
    bool consoleVisible = log.ConsoleVisible();
    if (ImGui::Checkbox("Console logging", &consoleVisible)) {
        const bool changed = log.SetConsoleVisible(consoleVisible);
        log.Write(changed ? LogLevel::Info : LogLevel::Warning,
            changed ? (consoleVisible ? "Console logging enabled" : "Console logging disabled") : "Could not change console logging");
    }
    ImGui::SameLine();
    ImGui::Checkbox("Auto-scroll", &settings.logAutoScroll);
    ImGui::SetNextItemWidth(150);
    ImGui::Combo("Level", &settings.logLevelFilter, "All\0Warnings & errors\0Errors\0");
    if (IconCommand(Icons::Copy, "Copy log")) ImGui::SetClipboardText(log.Text().c_str());
    ImGui::SameLine();
    if (IconCommand(Icons::Report, "Copy diagnostics")) ImGui::SetClipboardText(DiagnosticSummary(reader, targetFound).c_str());
    ImGui::SameLine();
    if (IconCommand(Icons::Clear, "Clear view")) {
        log.ClearView();
        log.Write(LogLevel::Info, "Log view cleared; file history retained");
    }
    ImGui::SameLine();
    ImGui::TextDisabled(log.FileReady() ? "Local log saved" : "File logging unavailable");
    if (ImGui::IsItemHovered()) {
        const auto path = log.Path().u8string();
        ImGui::SetTooltip("%s", reinterpret_cast<const char*>(path.c_str()));
    }
    ImGui::Spacing();
    if (ImGui::BeginChild("Log", ImVec2(0, 0), ImGuiChildFlags_Borders)) {
        const bool atBottom = ImGui::GetScrollY() >= ImGui::GetScrollMaxY() - 2;
        for (const auto& entry : log.Entries()) {
            if (settings.logLevelFilter == 1 && entry.level == LogLevel::Info) continue;
            if (settings.logLevelFilter == 2 && entry.level != LogLevel::Error) continue;
            const char* level = entry.level == LogLevel::Error ? "ERROR" : entry.level == LogLevel::Warning ? "WARN" : "INFO";
            const ImVec4 color = entry.level == LogLevel::Error ? (settings.theme == 1 ? ImVec4(0.98f, 0.52f, 0.47f, 1) : ImVec4(0.72f, 0.16f, 0.16f, 1)) :
                entry.level == LogLevel::Warning ? warning : accent;
            ImGui::TextColored(color, "%s  %s", entry.timestamp.c_str(), level);
            ImGui::TextWrapped("%s", entry.message.c_str());
            ImGui::Spacing();
        }
        if (settings.logAutoScroll && atBottom) ImGui::SetScrollHereY(1);
    }
    ImGui::EndChild();
}

void PlayerSelector(OverlaySettings& settings, const PlayerReader& reader) {
    const PlayerIdentity* selected = nullptr;
    for (const auto& player : reader.Players()) if (player.id == settings.selectedPlayer) selected = &player;
    ImGui::SetNextItemWidth(-1);
    if (ImGui::BeginCombo("##SelectedPlayer", selected ? selected->name.c_str() : "Select a player")) {
        for (const auto& player : reader.Players()) {
            const std::string label = player.name + (player.isLocal ? " (you)" : "");
            if (ImGui::Selectable(label.c_str(), player.id == settings.selectedPlayer)) settings.selectedPlayer = player.id;
        }
        ImGui::EndCombo();
    }
}
void VisualPreset(OverlaySettings& settings, int preset) {
    settings.effectPreset = preset;
    settings.lava = settings.glow = settings.bodyOutline = preset != 0;
    settings.electric = preset == 1 || preset == 4;
    settings.scan = preset == 1;
    settings.rainbow = preset == 2;
    settings.pulseOutline = preset == 2;
    settings.edgeFlow = preset == 1 || preset == 2;
    settings.dashedOutline = preset == 4;
    settings.travellingHighlight = preset == 4;
    settings.healthPulse = preset == 4;
    settings.color[0] = preset == 3 ? 0.9f : 0.2f;
    settings.color[1] = preset == 3 ? 0.93f : 0.85f;
    settings.color[2] = 1;
}

std::filesystem::path ProfileDirectory() {
    wchar_t module[32768]{};
    const auto length = GetModuleFileNameW(nullptr, module, static_cast<DWORD>(std::size(module)));
    return length && length < std::size(module) ? std::filesystem::path(module).parent_path() / L"profiles" : std::filesystem::path(L"profiles");
}

void ProfilesPage(OverlaySettings& settings, SettingsHistory& history, AppLog& log) {
    static char name[49] = "My setup";
    static std::string status;
    Section("SAVED PROFILES");
    ImGui::SetNextItemWidth(220);
    ImGui::InputText("Name", name, sizeof(name));
    const auto directory = ProfileDirectory();
    auto result = [&](bool ok, const std::string& error, const char* success, bool loaded = false) {
        status = ok ? success : error;
        log.Write(ok ? LogLevel::Info : LogLevel::Error, status);
        if (ok && loaded) history.Reset(settings);
    };
    if (IconCommand(Icons::Save, "Save profile", true)) {
        const std::string input(name);
        std::string upper = input;
        std::transform(upper.begin(), upper.end(), upper.begin(), [](unsigned char c) { return static_cast<char>(std::toupper(c)); });
        const bool reserved = upper == "CON" || upper == "PRN" || upper == "AUX" || upper == "NUL" ||
            (upper.size() == 4 && (upper.substr(0, 3) == "COM" || upper.substr(0, 3) == "LPT") && upper[3] >= '1' && upper[3] <= '9');
        const bool valid = !input.empty() && input.back() != ' ' && !reserved &&
            std::any_of(input.begin(), input.end(), [](unsigned char c) { return std::isalnum(c); }) &&
            std::all_of(input.begin(), input.end(), [](unsigned char c) { return std::isalnum(c) || c == ' ' || c == '_' || c == '-'; });
        std::string error;
        std::error_code filesystemError;
        if (valid) std::filesystem::create_directories(directory, filesystemError);
        const bool saved = valid && !filesystemError && SaveProfile(directory / (input + ".ini"), settings, error);
        if (!valid) error = "Choose a non-reserved name with a letter or number";
        else if (filesystemError) error = "Could not create profiles folder";
        result(saved, error, "Profile saved");
    }
    ImGui::Spacing();
    Section("AVAILABLE");
    std::error_code error;
    std::vector<std::filesystem::path> files;
    if (std::filesystem::is_directory(directory, error)) {
        for (std::filesystem::directory_iterator it(directory, error), end; !error && it != end && files.size() < 100; it.increment(error)) {
            if (it->is_regular_file(error) && _wcsicmp(it->path().extension().c_str(), L".ini") == 0) files.push_back(it->path());
        }
    }
    std::sort(files.begin(), files.end());
    if (files.empty()) ImGui::TextDisabled("No saved profiles");
    if (ImGui::BeginChild("Profiles", ImVec2(0, 145), ImGuiChildFlags_Borders)) {
        for (const auto& file : files) {
            const auto label = file.stem().u8string();
            if (ImGui::Selectable(reinterpret_cast<const char*>(label.c_str()))) {
                std::string message;
                result(LoadProfile(file, settings, message), message, "Profile loaded; aim and trigger disabled", true);
            }
        }
    }
    ImGui::EndChild();
    Section("SHARE");
    if (IconCommand(Icons::Import, "Import profile", true)) {
        const auto file = ChooseProfilePath(GetActiveWindow(), false);
        if (!file.empty()) {
            std::string message;
            result(LoadProfile(file, settings, message), message, "Profile imported; aim and trigger disabled", true);
        }
    }
    ImGui::SameLine();
    if (IconCommand(Icons::Export, "Export profile", true)) {
        const auto file = ChooseProfilePath(GetActiveWindow(), true);
        if (!file.empty()) {
            std::string message;
            result(SaveProfile(file, settings, message), message, "Profile exported");
        }
    }
    if (!status.empty()) ImGui::TextWrapped("%s", status.c_str());
}

void Page(OverlaySettings& settings, PlayerReader& reader, const AimAssist& aim, const TriggerAssist& trigger,
    const RuntimeMetrics& metrics, SettingsHistory& history, bool targetFound, AppLog& log, int page) {
    if (page == 6) { ConsolePage(settings, reader, targetFound, log); return; }
    if (page == 7) { ProfilesPage(settings, history, log); return; }
    if (!ImGui::BeginTable("Controls", 2, ImGuiTableFlags_SizingStretchSame, ImVec2(0, 0), 0)) return;
    ImGui::TableNextColumn();
    ImGui::PushItemWidth(175);
    if (page == 0) {
        ImGui::PopItemWidth();
        ImGui::EndTable();
        const char* tabs[] = {"Targeting", "Response", "Activation", "Trigger"};
        for (int i = 0; i < 4; ++i) {
            if (i) ImGui::SameLine();
            if (ImGui::Selectable(tabs[i], settings.aimTab == i, ImGuiSelectableFlags_None,
                ImVec2(std::max(80.0f, ImGui::GetContentRegionAvail().x / (4 - i) - 7), 30))) settings.aimTab = i;
        }
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();
        ImGui::PushItemWidth(190);
        if (settings.aimTab == 0) {
            Section("TARGETING");
            ImGui::Combo("Aim point", &settings.aim.bone, "Head\0Torso\0Root\0");
            ImGui::SliderFloat("Radius", &settings.aim.radius, 20, 450, "%.0f px");
            ImGui::Checkbox("Keep target", &settings.aim.keepTarget);
            ImGui::Checkbox("Ignore teammates", &settings.aim.ignoreTeammates);
            ImGui::Checkbox("Selected player only", &settings.aim.selectedOnly);
            if (settings.aim.selectedOnly) PlayerSelector(settings, reader);
        } else if (settings.aimTab == 1) {
            Section("RESPONSE");
            ImGui::SliderFloat("Smoothing", &settings.aim.smoothTime, 0, 0.6f, "%.2f s", ImGuiSliderFlags_AlwaysClamp);
            if (ImGui::CollapsingHeader("Advanced")) {
                ImGui::SliderFloat("Mouse gain", &settings.aim.gain, 0.05f, 1.5f, "%.2f");
                ImGui::BeginDisabled(settings.aim.smoothTime <= 0);
                ImGui::SliderFloat("Step limit", &settings.aim.maxStep, 5, 250, "%.0f", ImGuiSliderFlags_AlwaysClamp);
                ImGui::EndDisabled();
            }
        } else if (settings.aimTab == 2) {
            Section("ACTIVATION");
            ImGui::Checkbox("Aim enabled", &settings.aim.enabled);
            ImGui::Combo("Hold key", &settings.aim.activation, "Right mouse\0Mouse 4\0Left Alt\0");
            ImGui::Checkbox("Show radius", &settings.aim.showRadius);
            ImGui::TextWrapped("%s", aim.Status().c_str());
        } else {
            Section("TRIGGER");
            if (ImGui::BeginTable("TriggerControls", 2, ImGuiTableFlags_SizingStretchSame)) {
            ImGui::TableNextColumn();
            ImGui::SetNextItemWidth(175);
            ImGui::Checkbox("Trigger enabled", &settings.trigger.enabled);
            ImGui::PushItemWidth(175);
            ImGui::Combo("Hold key", &settings.trigger.activation, "Mouse 5\0Left Alt\0Left Control\0");
            ImGui::Combo("Target point", &settings.trigger.bone, "Head\0Torso\0Root\0");
            ImGui::Checkbox("Selected player only", &settings.trigger.selectedOnly);
            if (settings.trigger.selectedOnly) PlayerSelector(settings, reader);
            ImGui::TextColored(trigger.Armed() ? ImVec4(0.75f, 0.2f, 0.12f, 1) : accent, "%s", trigger.Status().c_str());
            ImGui::TextDisabled("Unknown teams excluded");
            ImGui::TableNextColumn();
            ImGui::SliderFloat("Tolerance", &settings.trigger.tolerance, 1, 30, "%.0f px");
            ImGui::SliderFloat("Delay", &settings.trigger.delay, 0, 1, "%.2f s");
            ImGui::SliderFloat("Cooldown", &settings.trigger.cooldown, 0.05f, 2, "%.2f s");
            ImGui::SliderInt("Burst limit", &settings.trigger.burstLimit, 1, 3);
            ImGui::Text("Input clicks: %llu", static_cast<unsigned long long>(trigger.ShotCount()));
            ImGui::PopItemWidth();
            ImGui::EndTable();
            }
        }
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextDisabled("Visibility check unavailable");
        ImGui::TextDisabled("Silent aim unavailable");
        ImGui::PopItemWidth();
        return;
    } else if (page == 1) {
        int visualPreset = 0;
        const bool baseVisuals = settings.boxes && settings.names && settings.healthBars && !settings.skeleton && !settings.tracers;
        const bool noEffects = !settings.lava && !settings.glow && !settings.bodyOutline && !settings.electric && !settings.scan &&
            !settings.pulseOutline && !settings.edgeFlow && !settings.dashedOutline && !settings.travellingHighlight && !settings.healthPulse;
        if (baseVisuals && noEffects) visualPreset = settings.distances ? 2 : 1;
        else if (baseVisuals && settings.effectPreset == 1 && settings.lava && settings.electric) visualPreset = 3;
        if (ImGui::Combo("Visual preset", &visualPreset, "Custom\0Minimal\0Competitive\0Electric\0")) {
            if (visualPreset > 0) {
            settings.boxes = settings.names = settings.healthBars = true;
            settings.distances = visualPreset != 1;
            settings.skeleton = settings.tracers = false;
            if (visualPreset < 3) VisualPreset(settings, 0);
            else VisualPreset(settings, 1);
            }
        }
        Section("PLAYER VISUALS");
        ImGui::Checkbox("Enabled", &settings.enabled);
        ImGui::Checkbox("Show teammates", &settings.showTeammates);
        ImGui::Checkbox("Team labels", &settings.teamLabels);
        ImGui::Checkbox("Team colors", &settings.teamColors);
        ImGui::Checkbox("Boxes", &settings.boxes);
        ImGui::Checkbox("Names", &settings.names);
        ImGui::Checkbox("Distance", &settings.distances);
        ImGui::Checkbox("Health bars", &settings.healthBars);
        ImGui::Checkbox("Skeleton", &settings.skeleton);
        ImGui::Checkbox("Tracers", &settings.tracers);
        ImGui::TableNextColumn();
        Section("APPEARANCE");
        ImGui::Combo("Box style", &settings.boxStyle, "Full\0Corners\0");
        ImGui::SliderFloat("Line width", &settings.thickness, 1, 3, "%.1f px");
        ImGui::SliderFloat("Label size", &settings.labelSize, 12, 20, "%.0f px");
        ImGui::SliderFloat("Range", &settings.maxDistance, 0, 10000, settings.maxDistance <= 0 ? "Unlimited" : "%.0f studs",
            ImGuiSliderFlags_AlwaysClamp);
        ImGui::ColorEdit4("Accent", settings.color, ImGuiColorEditFlags_NoInputs);
        Section("TEAM ASSIGNMENT");
        PlayerSelector(settings, reader);
        const PlayerIdentity* identity = nullptr;
        for (const auto& player : reader.Players()) if (player.id == settings.selectedPlayer) identity = &player;
        int assignment = 0;
        if (identity) {
            const auto entry = settings.teamOverrides.find(identity->userId);
            if (entry != settings.teamOverrides.end()) assignment = entry->second == TeamRelation::Ally ? 1 : 2;
        }
        ImGui::BeginDisabled(!identity || !identity->userId || identity->isLocal);
        if (ImGui::Combo("Relation", &assignment, "Automatic\0Teammate\0Enemy\0") && identity) {
            if (assignment == 0) settings.teamOverrides.erase(identity->userId);
            else settings.teamOverrides[identity->userId] = assignment == 1 ? TeamRelation::Ally : TeamRelation::Enemy;
        }
        ImGui::EndDisabled();
    } else if (page == 2) {
        Section("BODY EFFECTS");
        ImGui::SetNextItemWidth(-1);
        ImGui::Combo("##EffectScope", &settings.effectScope, "Other players\0Selected player\0My avatar\0");
        if (settings.effectScope == 1) PlayerSelector(settings, reader);
        ImGui::Checkbox("Body outline", &settings.bodyOutline);
        ImGui::Checkbox("Dashed outline", &settings.dashedOutline);
        ImGui::Checkbox("Black lava", &settings.lava);
        ImGui::Checkbox("Electric sparks", &settings.electric);
        ImGui::Checkbox("Scan band", &settings.scan);
        ImGui::SliderFloat("Opacity", &settings.lavaOpacity, 0.1f, 1, "%.2f");
        ImGui::SliderFloat("Animation", &settings.lavaSpeed, 0, 3, "%.1f");
        ImGui::SliderFloat("Scan speed", &settings.scanSpeed, 0.1f, 2, "%.1f");
        ImGui::TableNextColumn();
        Section("LIGHT & COLOR");
        if (ImGui::Combo("Preset", &settings.effectPreset, "Custom\0Electric\0Spectral\0Monochrome\0Circuit\0"))
            VisualPreset(settings, settings.effectPreset);
        ImGui::Checkbox("Pulsing outline", &settings.pulseOutline);
        ImGui::Checkbox("Travelling edge", &settings.edgeFlow);
        ImGui::Checkbox("Travelling highlight", &settings.travellingHighlight);
        ImGui::Checkbox("Health-change pulse", &settings.healthPulse);
        ImGui::Checkbox("Rainbow", &settings.rainbow);
        ImGui::SliderFloat("Color speed", &settings.rainbowSpeed, 0.03f, 0.6f, "%.2f");
        ImGui::Checkbox("Glow", &settings.glow);
        ImGui::SliderFloat("Intensity", &settings.glowStrength, 0, 1, "%.2f");
        ImGui::ColorEdit4("Accent", settings.color, ImGuiColorEditFlags_NoInputs);
    } else if (page == 3) {
        Section("CURRENT CHARACTER");
        const auto& stats = reader.LocalStats();
        if (stats.valid) {
            ImGui::Text("Speed             %.1f", stats.speed);
            ImGui::Text("Jump power        %.1f", stats.jumpPower);
            ImGui::Text("Jump mode         %s", stats.useJumpPower ? "Power" : "Height");
        } else ImGui::TextDisabled("Waiting for character data");
        ImGui::TextDisabled("Read-only values");
        ImGui::TableNextColumn();
        Section("MOVEMENT STATUS");
        ImGui::TextWrapped("External movement edits removed");
        ImGui::TextDisabled("Speed and jump are not modified");
        ImGui::TextDisabled("Fly / Noclip unavailable");
    } else if (page == 4) {
        Section("MY AVATAR");
        for (const auto& player : reader.Players()) if (player.isLocal) {
            ImGui::TextUnformatted(player.name.c_str());
            ImGui::Text("User ID: %llu", static_cast<unsigned long long>(player.userId));
        }
        bool ownEffects = settings.effectScope == 2;
        if (ImGui::Checkbox("Effects on my avatar", &ownEffects)) settings.effectScope = ownEffects ? 2 : 0;
        ImGui::Checkbox("Black lava", &settings.lava);
        ImGui::Checkbox("Body outline", &settings.bodyOutline);
        ImGui::TableNextColumn();
        Section("APPEARANCE CHANGES");
        ImGui::TextWrapped("Avatar replacement, Headless and Korblox appearance changes require your game's avatar scripts.");
        ImGui::TextColored(warning, "Game integration not connected");
    } else {
        ImGui::PopItemWidth();
        ImGui::EndTable();
        const char* tabs[] = {"Display", "Interface", "Session"};
        for (int i = 0; i < 3; ++i) {
            if (i) ImGui::SameLine();
            if (ImGui::Selectable(tabs[i], settings.settingsTab == i, ImGuiSelectableFlags_None,
                ImVec2(std::max(80.0f, ImGui::GetContentRegionAvail().x / (3 - i) - 7), 30))) settings.settingsTab = i;
        }
        ImGui::Spacing(); ImGui::Separator(); ImGui::Spacing();
        ImGui::PushItemWidth(175);
        if (settings.settingsTab == 0) {
            if (ImGui::BeginTable("DisplayControls", 2, ImGuiTableFlags_SizingStretchSame)) {
            ImGui::TableNextColumn();
            Section("CROSSHAIR");
            ImGui::Checkbox("Enabled", &settings.crosshair);
            ImGui::Combo("Style", &settings.crosshairStyle, "Cross\0Dot\0Circle\0");
            ImGui::SliderFloat("Size", &settings.crosshairSize, 1, 30, "%.0f px");
            ImGui::SliderFloat("Gap", &settings.crosshairGap, 0, 20, "%.0f px");
            ImGui::SliderFloat("Thickness", &settings.crosshairThickness, 1, 5, "%.1f px");
            ImGui::ColorEdit4("Color", settings.crosshairColor, ImGuiColorEditFlags_NoInputs);
            ImGui::Checkbox("Outline", &settings.crosshairOutline);
            ImGui::TableNextColumn();
            Section("OVERLAY");
            ImGui::Checkbox("Follow Roblox window", &settings.followRoblox);
            ImGui::Checkbox("Pause visuals in menu", &settings.pauseVisualsInMenu);
            ImGui::SliderInt("FPS limit", &settings.maxFps, 30, 240);
            ImGui::EndTable();
            }
        } else if (settings.settingsTab == 1) {
            Section("INTERFACE");
            ImGui::Combo("Theme", &settings.theme, "White\0Charcoal\0");
            ImGui::ColorEdit3("Menu accent", settings.uiAccent, ImGuiColorEditFlags_NoInputs);
            ImGui::Checkbox("Effect preview", &settings.previewEnabled);
            ImGui::Checkbox("Compare presets", &settings.comparePreview);
            ImGui::SliderFloat("GUI motion", &settings.guiMotion, 0, 2, "%.1f");
            ImGui::Checkbox("Reduced motion", &settings.reducedMotion);
            ImGui::Checkbox("Screenshot mode", &settings.screenshotMode);
            if (IconCommand(Icons::Reset, "Reset app settings", true)) {
                const int current = settings.page;
                settings = {}; settings.page = current; settings.settingsTab = 1;
                log.Write(LogLevel::Info, "Application settings reset; activation disabled");
            }
        } else {
            Section("PERFORMANCE");
            ImGui::Checkbox("Session overlay", &settings.sessionStats);
            ImGui::Text("Runtime: %.0f s", metrics.ElapsedSeconds());
            ImGui::Text("Average overlay FPS: %.0f", metrics.AverageFps());
            ImGui::Text("Peak frame: %.1f ms", metrics.PeakFrameMs());
            ImGui::Text("Application CPU: %.1f%%", metrics.CpuPercent());
            const auto& frames = metrics.FrameHistory();
            ImGui::PlotLines("##FrameTime", frames.data(), static_cast<int>(frames.size()), 0, "Frame time (ms)",
                0, std::max(35.0f, metrics.PeakFrameMs()), ImVec2(-1, 85));
            Section("COMPATIBILITY");
            size_t unknownTeams = 0;
            for (const auto& box : reader.Boxes()) if (!box.isLocal && RelationFor(box, settings.teamOverrides) == TeamRelation::Unknown) ++unknownTeams;
            const auto& d = reader.Diagnostics();
            const bool partial = unknownTeams || d.missingGeometry || d.unreadableHealth;
            ImGui::TextColored(!reader.Connected() || partial ? warning : accent,
                "%s", !reader.Connected() ? "Unavailable" : partial ? "Partial data" : "Standard data available");
            ImGui::TextWrapped("%s", reader.Status().c_str());
            ImGui::Text("Alive %zu   Dead %zu   Loading %zu", d.alive, d.dead, d.incomplete);
            ImGui::Text("Missing geometry %zu   Unknown teams %zu", d.missingGeometry, unknownTeams);
            ImGui::TextDisabled("R6 / R15 | Visibility unavailable");
            ImGui::TextDisabled("Unloaded characters unavailable");
        }
        ImGui::PopItemWidth();
        return;
    }
    ImGui::PopItemWidth();
    ImGui::EndTable();
}
}

std::string DiagnosticSummary(const PlayerReader& reader, bool targetFound) {
    const auto& d = reader.Diagnostics();
    return "Roblox External v11\nMode: local overlay; no injected module or movement edits\nWindow: " + std::string(targetFound ? "found" : "not found") +
        "\nStatus: " + reader.Status() + "\nPlayers: " + std::to_string(reader.PlayerCount()) +
        "\nProjected boxes: " + std::to_string(reader.Boxes().size()) +
        "\nCharacter stats readable: " + std::to_string(reader.LocalStats().valid) +
        "\nAlive: " + std::to_string(d.alive) + "\nDead: " + std::to_string(d.dead) +
        "\nLoading: " + std::to_string(d.incomplete) + "\nUnknown health: " + std::to_string(d.unreadableHealth) +
        "\nMissing geometry: " + std::to_string(d.missingGeometry) + "\nOff-screen: " + std::to_string(d.offscreen) + "\n";
}

namespace {
void ApplyTheme(const OverlaySettings& settings) {
    auto& style = ImGui::GetStyle();
    accent = ImVec4(settings.uiAccent[0], settings.uiAccent[1], settings.uiAccent[2], 1);
    const bool dark = settings.theme == 1;
    warning = dark ? ImVec4(0.95f, 0.74f, 0.39f, 1) : ImVec4(0.59f, 0.35f, 0.06f, 1);
    if (dark) {
        float hue, saturation, value;
        ImGui::ColorConvertRGBtoHSV(accent.x, accent.y, accent.z, hue, saturation, value);
        ImGui::ColorConvertHSVtoRGB(hue, saturation, std::max(value, 0.75f), accent.x, accent.y, accent.z);
    }
    const ImVec4 base = dark ? ImVec4(0.10f, 0.115f, 0.12f, 1) : ImVec4(1, 1, 1, 1);
    const ImVec4 frame = dark ? ImVec4(0.16f, 0.18f, 0.19f, 1) : ImVec4(0.94f, 0.96f, 0.96f, 1);
    const ImVec4 hovered = dark ? ImVec4(0.21f, 0.25f, 0.24f, 1) : ImVec4(0.86f, 0.92f, 0.9f, 1);
    style.Colors[ImGuiCol_WindowBg] = style.Colors[ImGuiCol_PopupBg] = base;
    style.Colors[ImGuiCol_ChildBg] = ImVec4(0, 0, 0, 0);
    style.Colors[ImGuiCol_Text] = dark ? ImVec4(0.92f, 0.95f, 0.95f, 1) : ImVec4(0.11f, 0.15f, 0.18f, 1);
    style.Colors[ImGuiCol_TextDisabled] = dark ? ImVec4(0.60f, 0.66f, 0.66f, 1) : ImVec4(0.42f, 0.47f, 0.5f, 1);
    style.Colors[ImGuiCol_Border] = style.Colors[ImGuiCol_Separator] = dark ? ImVec4(0.28f, 0.32f, 0.32f, 1) : ImVec4(0.86f, 0.89f, 0.90f, 1);
    style.Colors[ImGuiCol_FrameBg] = style.Colors[ImGuiCol_Button] = frame;
    style.Colors[ImGuiCol_FrameBgHovered] = style.Colors[ImGuiCol_ButtonHovered] = hovered;
    style.Colors[ImGuiCol_FrameBgActive] = style.Colors[ImGuiCol_ButtonActive] = hovered;
    style.Colors[ImGuiCol_Header] = style.Colors[ImGuiCol_HeaderHovered] = style.Colors[ImGuiCol_HeaderActive] = hovered;
    style.Colors[ImGuiCol_CheckMark] = style.Colors[ImGuiCol_SliderGrab] = style.Colors[ImGuiCol_SliderGrabActive] = accent;
}

void SearchSettings(OverlaySettings& settings) {
    static char query[80]{};
    if (ImGui::Shortcut(ImGuiMod_Ctrl | ImGuiKey_F)) ImGui::SetKeyboardFocusHere();
    ImGui::SetNextItemWidth(std::min(300.0f, ImGui::GetContentRegionAvail().x * 0.5f));
    ImGui::InputTextWithHint("##SettingsSearch", "Search settings", query, sizeof(query));
    if (!query[0]) return;
    struct Entry { const char* title; const char* keywords; int page, tab; };
    static const Entry entries[] = {
        {"Aim / Targeting", "radius head torso root teammate target", 0, 0},
        {"Aim / Response", "smoothing speed gain step response", 0, 1},
        {"Aim / Activation", "hold key enable activation", 0, 2},
        {"Aim / Trigger", "trigger delay cooldown burst shooting", 0, 3},
        {"ESP", "boxes names distance health skeleton tracer teams", 1, 0},
        {"Effects", "lava electric rainbow glow animation dashed travelling pulse", 2, 0},
        {"Misc", "movement speed jump", 3, 0},
        {"Avatar", "avatar body own", 4, 0},
        {"Settings / Display", "crosshair size color outline fps display", 5, 0},
        {"Settings / Interface", "theme accent preview compare reduced motion screenshot reset", 5, 1},
        {"Settings / Session", "performance cpu stats compatibility loading diagnostics", 5, 2},
        {"Console", "log error warning console", 6, 0},
        {"Profiles", "save import export profile share", 7, 0}
    };
    std::string needle(query);
    std::transform(needle.begin(), needle.end(), needle.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    const ImVec2 top = ImGui::GetItemRectMin(), bottom = ImGui::GetItemRectMax();
    ImGui::SetNextWindowPos(ImVec2(top.x, bottom.y + 3));
    ImGui::SetNextWindowSize(ImVec2(bottom.x - top.x, 210));
    ImGui::PushStyleVar(ImGuiStyleVar_Alpha, 1.0f);
    if (ImGui::Begin("Search results", nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoMove |
        ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoFocusOnAppearing)) {
        int matches = 0;
        for (const auto& entry : entries) {
            std::string haystack = std::string(entry.title) + " " + entry.keywords;
            std::transform(haystack.begin(), haystack.end(), haystack.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
            std::istringstream words(needle);
            std::string word;
            bool match = true;
            while (words >> word) if (haystack.find(word) == std::string::npos) { match = false; break; }
            if (!match) continue;
            ++matches;
            if (ImGui::Selectable(entry.title)) {
                settings.page = entry.page;
                if (entry.page == 0) settings.aimTab = entry.tab;
                if (entry.page == 5) settings.settingsTab = entry.tab;
                query[0] = 0;
            }
        }
        if (!matches) ImGui::TextDisabled("No matches");
    }
    ImGui::End();
    ImGui::PopStyleVar();
}
}

void DrawSessionStats(const OverlaySettings& settings, const RuntimeMetrics& metrics) {
    if (!settings.sessionStats || settings.screenshotMode) return;
    auto* draw = ImGui::GetForegroundDrawList();
    const ImVec2 size = ImGui::GetIO().DisplaySize;
    char text[160]{};
    snprintf(text, sizeof(text), "Overlay  %.0f FPS  |  %.1f ms  |  CPU %.1f%%", metrics.RollingFps(),
        metrics.PeakFrameMs(), metrics.CpuPercent());
    const ImVec2 bounds = ImGui::CalcTextSize(text);
    const ImVec2 top(std::max(8.0f, size.x - bounds.x - 28), 12);
    draw->AddRectFilled(ImVec2(top.x - 10, top.y - 6), ImVec2(top.x + bounds.x + 10, top.y + bounds.y + 6), IM_COL32(24, 28, 29, 220), 4);
    draw->AddText(top, IM_COL32(236, 245, 241, 255), text);
}

void DrawMenu(OverlaySettings& settings, bool targetFound, PlayerReader& reader, const AimAssist& aim,
    const TriggerAssist& trigger, const RuntimeMetrics& metrics, SettingsHistory& history, AppLog& log, bool& running) {
    const ImVec2 viewport = ImGui::GetIO().DisplaySize;
    ApplyTheme(settings);
    static double lastDrawTime = -1;
    static float entrance = 0;
    const double now = ImGui::GetTime();
    if (lastDrawTime < 0 || now - lastDrawTime > 0.15) entrance = 0;
    lastDrawTime = now;
    const bool still = settings.reducedMotion || settings.guiMotion <= 0;
    entrance = still ? 1 : std::min(1.0f, entrance + ImGui::GetIO().DeltaTime * 4.5f * settings.guiMotion);
    const float easedEntrance = 1 - std::pow(1 - entrance, 3.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_Alpha, 0.75f + 0.25f * easedEntrance);
    ImGui::SetNextWindowPos(ImVec2(24, 24), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(std::min(1040.0f, viewport.x - 48), std::min(700.0f, viewport.y - 48)), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSizeConstraints(ImVec2(std::min(760.0f, viewport.x - 48), std::min(560.0f, viewport.y - 48)),
        ImVec2(std::max(200.0f, viewport.x - 24), std::max(200.0f, viewport.y - 24)));
    if (ImGui::Begin("Roblox External", nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoCollapse)) {
        if (headingFont) ImGui::PushFont(headingFont, 22);
        ImGui::TextUnformatted("Roblox External");
        if (headingFont) ImGui::PopFont();
        ImGui::SameLine(ImGui::GetWindowWidth() - 172);
        ImGui::BeginDisabled(!history.CanUndo());
        if (IconCommand(Icons::Undo, "Undo settings")) history.Undo(settings);
        ImGui::EndDisabled(); ImGui::SameLine();
        ImGui::BeginDisabled(!history.CanRedo());
        if (IconCommand(Icons::Redo, "Redo settings")) history.Redo(settings);
        ImGui::EndDisabled(); ImGui::SameLine();
        if (IconCommand(Icons::Profiles, "Profiles")) settings.page = 7;
        ImGui::SameLine();
        if (IconCommand(Icons::Close, "Quit")) running = false;
        SearchSettings(settings);
        ImGui::SameLine();
        ImGui::TextDisabled("%zu players   |   %.0f overlay FPS", reader.PlayerCount(), ImGui::GetIO().Framerate);
        if (trigger.Armed()) { ImGui::SameLine(); ImGui::TextColored(ImVec4(0.85f, 0.24f, 0.13f, 1), "TRIGGER ARMED"); }
        ImGui::TextColored(reader.Connected() ? accent : warning, "%s", reader.Status().c_str());
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();
        const char* pages[] = {"Aim", "ESP", "Effects", "Misc", "Avatar", "Settings", "Console", "Profiles"};
        const char* icons[] = {Icons::Aim, Icons::ESP, Icons::Effects, Icons::Misc, Icons::Avatar, Icons::Settings, Icons::Console, Icons::Profiles};
        static float hover[8]{};
        static int previousPage = -1;
        static float reveal = 0;
        if (previousPage != settings.page) { previousPage = settings.page; reveal = 0; }
        reveal = still ? 1 : std::min(1.0f, reveal + ImGui::GetIO().DeltaTime * 5.5f * settings.guiMotion);
        const float pageEase = 1 - std::pow(1 - reveal, 3.0f);
        const bool preview = settings.previewEnabled && ImGui::GetWindowWidth() >= 960;
        if (ImGui::BeginTable("Workspace", preview ? 3 : 2, ImGuiTableFlags_SizingFixedFit)) {
            ImGui::TableSetupColumn("Rail", ImGuiTableColumnFlags_WidthFixed, 52);
            ImGui::TableSetupColumn("Content", ImGuiTableColumnFlags_WidthStretch);
            if (preview) ImGui::TableSetupColumn("Preview", ImGuiTableColumnFlags_WidthFixed, 220);
            ImGui::TableNextRow();
            ImGui::TableNextColumn();
            const float railSize = ImGui::GetWindowHeight() < 640 ? 40.0f : 44.0f;
            ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(14, railSize < 44 ? 6.0f : 9.0f));
            for (int i = 0; i < 8; ++i) {
                ImGui::PushID(i);
                const ImVec2 top = ImGui::GetCursorScreenPos();
                if (ImGui::InvisibleButton("Page", ImVec2(railSize, railSize))) settings.page = i;
                const bool hovered = ImGui::IsItemHovered();
                hover[i] = still ? (hovered ? 1.0f : 0.0f) : hover[i] + ((hovered ? 1.0f : 0.0f) - hover[i]) *
                    std::min(1.0f, ImGui::GetIO().DeltaTime * 18 * settings.guiMotion);
                auto* draw = ImGui::GetWindowDrawList();
                if (settings.page == i || hover[i] > 0.02f) draw->AddRectFilled(top, ImVec2(top.x + railSize, top.y + railSize),
                    ImGui::GetColorU32(settings.page == i ? ImGuiCol_HeaderActive : ImGuiCol_FrameBgHovered), 5);
                if (settings.page == i) draw->AddRectFilled(ImVec2(top.x - 5, top.y + 8), ImVec2(top.x - 2, top.y + 36), Color(accent), 1);
                ImFont* font = iconFont ? iconFont : ImGui::GetFont();
                const char* glyph = iconFont ? icons[i] : pages[i];
                const ImVec2 size = font->CalcTextSizeA(22, 100, 0, glyph);
                draw->AddText(font, 22, ImVec2(top.x + (railSize - size.x) / 2, top.y + (railSize - size.y) / 2),
                    Color(settings.page == i ? accent : ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled)), glyph);
                if (hover[i] > 0.04f) {
                    const ImVec2 textSize = ImGui::CalcTextSize(pages[i]);
                    const ImVec2 labelTop(top.x + 52 + (1 - hover[i]) * 6, top.y + 7);
                    const ImVec2 labelBottom(labelTop.x + textSize.x + 24, labelTop.y + 30);
                    auto* foreground = ImGui::GetForegroundDrawList();
                    for (int layer = 4; layer > 0; --layer) foreground->AddRectFilled(
                        ImVec2(labelTop.x - layer, labelTop.y - layer), ImVec2(labelBottom.x + layer, labelBottom.y + layer),
                        IM_COL32(35, 60, 52, static_cast<int>(6 * hover[i])), 5.0f + static_cast<float>(layer));
                    foreground->AddRectFilled(labelTop, labelBottom, ImGui::GetColorU32(ImGuiCol_PopupBg, hover[i]), 5);
                    foreground->AddRect(labelTop, labelBottom, ImGui::GetColorU32(ImGuiCol_Border, hover[i]), 5);
                    foreground->AddText(ImVec2(labelTop.x + 12, labelTop.y + (30 - textSize.y) / 2),
                        Color(accent, hover[i]), pages[i]);
                }
                ImGui::PopID();
            }
            ImGui::PopStyleVar();
            ImGui::TableNextColumn();
            ImGui::BeginChild("Page", ImVec2(0, 0), ImGuiChildFlags_None);
            ImGui::SetCursorPosY(ImGui::GetCursorPosY() + (1 - pageEase) * 9);
            ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ImGui::GetStyle().Alpha * (0.7f + 0.3f * pageEase));
            Page(settings, reader, aim, trigger, metrics, history, targetFound, log, std::clamp(settings.page, 0, 7));
            ImGui::PopStyleVar();
            ImGui::EndChild();
            if (preview) {
                ImGui::TableNextColumn();
                ImGui::BeginChild("Preview", ImVec2(0, 0));
                Section("PREVIEW");
                ImGui::Checkbox("Compare", &settings.comparePreview);
                const bool crosshairPreview = settings.page == 5 && settings.settingsTab == 0;
                const ImVec2 previewSize(ImGui::GetContentRegionAvail().x, crosshairPreview ? 160.0f : 310.0f);
                DrawEffectPreview(settings, ImGui::GetCursorScreenPos(), previewSize, settings.comparePreview);
                ImGui::Dummy(previewSize);
                ImGui::Spacing();
                DrawLoading(settings, reader, targetFound);
                ImGui::TextDisabled("Local dummy");
                if (crosshairPreview) {
                    Section("CROSSHAIR");
                    const ImVec2 position = ImGui::GetCursorScreenPos();
                    const float width = ImGui::GetContentRegionAvail().x;
                    ImGui::GetWindowDrawList()->AddRectFilled(position, ImVec2(position.x + width, position.y + 112), IM_COL32(38, 44, 44, 255), 4);
                    DrawCrosshairPreview(settings, ImVec2(position.x + width / 2, position.y + 56));
                    ImGui::Dummy(ImVec2(width, 112));
                }
                ImGui::EndChild();
            }
            ImGui::EndTable();
        }
        if (!ImGui::IsAnyItemActive()) history.Capture(settings);
    }
    ImGui::End();
    ImGui::PopStyleVar();
}

std::vector<PlayerBox> MakeRenderFixture() {
    PlayerBox player;
    player.id = 1;
    player.relation = TeamRelation::Enemy;
    player.name = "Preview";
    player.topLeft = {722, 184}; player.bottomRight = {910, 500}; player.distance = 28;
    player.health = 75; player.maxHealth = 100;
    player.aimValid = {true, true, true};
    player.aimPoints = {ScreenPoint{814,216}, {814,310}, {814,360}};
    const float parts[][4] = {{782,184,846,248}, {765,251,862,368}, {722,255,760,375},
        {867,255,905,375}, {764,375,808,500}, {814,375,858,500}};
    for (int i = 0; i < 6; ++i) {
        const auto* p = parts[i];
        BodyFace face{{ScreenPoint{p[0],p[1]}, {p[0],p[3]}, {p[2],p[3]}, {p[2],p[1]}}, {1,1,1,1}, static_cast<uint32_t>(i*97)};
        player.faces.push_back(face);
        player.silhouettes.push_back({{p[0],p[1]}, {p[2],p[1]}, {p[2],p[3]}, {p[0],p[3]}});
    }
    player.bones = {{{814,216},{814,310}}, {{814,310},{742,315}}, {{814,310},{887,315}},
        {{814,310},{786,435}}, {{814,310},{836,435}}};
    return {player};
}
