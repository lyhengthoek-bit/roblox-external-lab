#include "player_reader.hpp"
#include "offsets.hpp"
#include <tlhelp32.h>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <limits>
#include <unordered_map>
#include <string_view>

static_assert(sizeof(uintptr_t) == 8, "The supplied Roblox offsets require an x64 build.");

namespace {
bool ValidPointer(uintptr_t address) {
    return address >= 0x10000 && address < 0x00007fffffffffff;
}
bool Finite(const Vec3& value) {
    return std::isfinite(value.x) && std::isfinite(value.y) && std::isfinite(value.z);
}
bool BodyPartName(const std::string& name) {
    constexpr std::string_view names[] = {"Head", "Torso", "UpperTorso", "LowerTorso",
        "Left Arm", "Right Arm", "Left Leg", "Right Leg", "LeftUpperArm", "LeftLowerArm", "LeftHand",
        "RightUpperArm", "RightLowerArm", "RightHand", "LeftUpperLeg", "LeftLowerLeg", "LeftFoot",
        "RightUpperLeg", "RightLowerLeg", "RightFoot"};
    return std::find(std::begin(names), std::end(names), name) != std::end(names);
}
Vec3 Subtract(const Vec3& a, const Vec3& b) { return {a.x - b.x, a.y - b.y, a.z - b.z}; }
float Distance(const Vec3& a, const Vec3& b) {
    const auto difference = Subtract(a, b);
    return std::sqrt(difference.x * difference.x + difference.y * difference.y + difference.z * difference.z);
}
float ClipDepth(const Vec3& p, const Matrix4& matrix) {
    const auto* m = matrix.values;
    return m[12] * p.x + m[13] * p.y + m[14] * p.z + m[15];
}
std::vector<ScreenPoint> Hull(std::vector<ScreenPoint> points) {
    std::sort(points.begin(), points.end(), [](auto a, auto b) { return a.x == b.x ? a.y < b.y : a.x < b.x; });
    points.erase(std::unique(points.begin(), points.end(), [](auto a, auto b) { return a.x == b.x && a.y == b.y; }), points.end());
    if (points.size() < 3) return {};
    auto cross = [](auto a, auto b, auto c) { return (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x); };
    std::vector<ScreenPoint> result(points.size() * 2);
    size_t count = 0;
    for (auto p : points) {
        while (count >= 2 && cross(result[count - 2], result[count - 1], p) <= 0) --count;
        result[count++] = p;
    }
    const size_t lower = count + 1;
    for (size_t i = points.size() - 1; i > 0; --i) {
        auto p = points[i - 1];
        while (count >= lower && cross(result[count - 2], result[count - 1], p) <= 0) --count;
        result[count++] = p;
    }
    result.resize(count - 1);
    return result;
}
void ProjectBody(const std::array<Vec3, 8>& corners, const Matrix4& matrix,
    float width, float height, uint32_t seed, PlayerBox& box) {
    std::array<ScreenPoint, 8> projected{};
    std::array<float, 8> depths{};
    std::vector<ScreenPoint> points;
    for (int i = 0; i < 8; ++i) {
        depths[i] = ClipDepth(corners[i], matrix);
        if (Project(corners[i], matrix, width, height, projected[i])) points.push_back(projected[i]);
    }
    // Intersect edges with the near plane so partial bodies do not disappear.
    for (int i = 0; i < 8; ++i) for (int axis = 0; axis < 3; ++axis) {
        const int j = i ^ (1 << axis);
        if (j <= i || (depths[i] >= 0.02f) == (depths[j] >= 0.02f)) continue;
        const float t = (0.02f - depths[i]) / (depths[j] - depths[i]);
        Vec3 point{corners[i].x + t * (corners[j].x - corners[i].x),
            corners[i].y + t * (corners[j].y - corners[i].y),
            corners[i].z + t * (corners[j].z - corners[i].z)};
        ScreenPoint screen;
        if (Project(point, matrix, width, height, screen)) points.push_back(screen);
    }
    auto hull = Hull(std::move(points));
    if (!hull.empty()) box.silhouettes.push_back(std::move(hull));
    constexpr int faces[6][4] = {{0, 2, 3, 1}, {4, 5, 7, 6}, {0, 4, 6, 2},
        {1, 3, 7, 5}, {0, 1, 5, 4}, {2, 6, 7, 3}};
    for (int face = 0; face < 6; ++face) {
        BodyFace surface{};
        bool visible = true;
        float area = 0;
        for (int i = 0; i < 4; ++i) {
            const int index = faces[face][i];
            if (depths[index] <= 0.02f) visible = false;
            surface.points[i] = projected[index];
            surface.depth[i] = depths[index];
        }
        if (!visible) continue;
        for (int i = 0; i < 4; ++i) {
            const auto a = surface.points[i], b = surface.points[(i + 1) % 4];
            area += a.x * b.y - a.y * b.x;
        }
        if (area >= -2.0f) continue;
        surface.seed = seed + face * 31;
        box.faces.push_back(surface);
    }
}
}

bool Project(const Vec3& position, const Matrix4& matrix, float width, float height, ScreenPoint& result) {
    if (!Finite(position) || !std::isfinite(width) || !std::isfinite(height) || width <= 0 || height <= 0) return false;
    const float* m = matrix.values;
    const float w = m[12] * position.x + m[13] * position.y + m[14] * position.z + m[15];
    if (!std::isfinite(w) || w <= 0.01f) return false;
    const float x = (m[0] * position.x + m[1] * position.y + m[2] * position.z + m[3]) / w;
    const float y = (m[4] * position.x + m[5] * position.y + m[6] * position.z + m[7]) / w;
    result = {width * (1.0f + x) * 0.5f, height * (1.0f - y) * 0.5f};
    return std::isfinite(result.x) && std::isfinite(result.y);
}

TeamRelation RelationFor(const PlayerBox& player, const TeamOverrides& overrides) {
    const auto found = overrides.find(player.userId);
    return player.userId && found != overrides.end() ? found->second : player.relation;
}

bool TestProjection() {
    Matrix4 identity{};
    identity.values[0] = identity.values[5] = identity.values[10] = identity.values[15] = 1;
    ScreenPoint result{};
    if (!Project({0, 0, 0}, identity, 1000, 700, result) || result.x != 500 || result.y != 350) return false;
    if (!Project({-1, 1, 0}, identity, 1000, 700, result) || result.x != 0 || result.y != 0) return false;
    identity.values[15] = -1;
    if (Project({0, 0, 0}, identity, 1000, 700, result)) return false;
    identity.values[15] = 1;
    if (Project({std::numeric_limits<float>::quiet_NaN(), 0, 0}, identity, 1000, 700, result)) return false;
    // A camera translation must reproject a fixed world point immediately.
    identity.values[3] = -0.5f;
    if (!Project({0, 0, 0}, identity, 1000, 700, result) || result.x != 250) return false;
    auto hull = Hull({{0, 0}, {10, 0}, {10, 10}, {0, 10}, {5, 5}});
    if (hull.size() != 4) return false;
    Matrix4 perspective{};
    perspective.values[0] = perspective.values[5] = perspective.values[14] = 1;
    std::array<Vec3, 8> nearBody;
    for (int i = 0; i < 8; ++i) nearBody[i] = {(i & 1) ? 0.1f : -0.1f,
        (i & 2) ? 0.1f : -0.1f, (i & 4) ? 1.0f : -1.0f};
    PlayerBox clipped;
    ProjectBody(nearBody, perspective, 1000, 700, 0, clipped);
    return !clipped.silhouettes.empty();
}

PlayerReader::~PlayerReader() { Reset(); }

void PlayerReader::Reset() {
    if (process_) CloseHandle(process_);
    process_ = nullptr;
    processId_ = 0;
    moduleBase_ = lastDataModel_ = localRoot_ = playersService_ = 0;
    nextRefresh_ = 0;
    connected_ = false;
    players_.clear();
    boxes_.clear();
    identities_.clear();
    localPlayer_ = {};
    localStats_ = {};
}

bool PlayerReader::Read(uintptr_t address, void* destination, size_t size) {
    if (!process_ || !ValidPointer(address) || size > 1024 * 1024 ||
        address + size < address || !ValidPointer(address + size)) return false;
    SIZE_T received = 0;
    if (!ReadProcessMemory(process_, reinterpret_cast<LPCVOID>(address), destination, size, &received) || received != size) {
        readError_ = GetLastError();
        return false;
    }
    return true;
}

uintptr_t PlayerReader::Pointer(uintptr_t address) {
    uintptr_t result = 0;
    return Read(address, result) && ValidPointer(result) ? result : 0;
}

std::string PlayerReader::String(uintptr_t address) {
    // MSVC x64 std::string stores up to 15 bytes inline, otherwise a heap pointer.
    struct StringLayout { char data[16]; uint64_t size; uint64_t capacity; } layout{};
    if (!Read(address, layout) || layout.size == 0 || layout.size > 128 ||
        layout.capacity < layout.size || layout.capacity > 1024 * 1024) return {};
    std::string result(static_cast<size_t>(layout.size), '\0');
    if (layout.capacity <= 15) {
        if (layout.size > 15) return {};
        memcpy(result.data(), layout.data, result.size());
    } else {
        uintptr_t buffer = 0;
        memcpy(&buffer, layout.data, sizeof(buffer));
        if (!Read(buffer, result.data(), result.size())) return {};
    }
    for (const unsigned char character : result) if (character < 32 || character == 127) return {};
    return result;
}

std::string PlayerReader::Name(uintptr_t instance) {
    const uintptr_t container = Pointer(instance + Offsets::Instance::NameContainer);
    return container ? String(container + Offsets::Instance::Name) : std::string{};
}

std::string PlayerReader::ClassName(uintptr_t instance) {
    const uintptr_t descriptor = Pointer(instance + Offsets::Instance::ClassDescriptor);
    const uintptr_t name = descriptor ? Pointer(descriptor + Offsets::Instance::ClassName) : 0;
    return name ? String(name) : std::string{};
}

std::vector<uintptr_t> PlayerReader::Children(uintptr_t instance) {
    const uintptr_t container = Pointer(instance + Offsets::Instance::ChildrenStart);
    if (!container) return {};
    uintptr_t bounds[2]{};
    if (!Read(container, bounds) || !ValidPointer(bounds[0]) || bounds[1] < bounds[0] ||
        (bounds[1] - bounds[0]) % 16 != 0 || bounds[1] - bounds[0] > 4096 * 16) return {};
    const size_t count = static_cast<size_t>((bounds[1] - bounds[0]) / 16);
    if (!count) return {};
    struct Entry { uintptr_t instance, reference; };
    std::vector<Entry> entries(count);
    if (!Read(bounds[0], entries.data(), entries.size() * sizeof(Entry))) return {};
    std::vector<uintptr_t> result;
    result.reserve(count);
    for (const auto& entry : entries) if (ValidPointer(entry.instance)) result.push_back(entry.instance);
    return result;
}

bool PlayerReader::Attach(HWND target) {
    DWORD id = 0;
    if (!IsWindow(target) || !GetWindowThreadProcessId(target, &id)) {
        Reset();
        status_ = "Waiting for Roblox";
        return false;
    }
    if (process_ && processId_ == id) {
        DWORD exitCode = 0;
        if (GetExitCodeProcess(process_, &exitCode) && exitCode == STILL_ACTIVE) return true;
    }
    Reset();
    process_ = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION | PROCESS_VM_READ, FALSE, id);
    if (!process_) {
        status_ = "Memory access failed: " + std::to_string(GetLastError());
        return false;
    }
    wchar_t path[32768];
    DWORD length = static_cast<DWORD>(std::size(path));
    if (!QueryFullProcessImageNameW(process_, 0, path, &length) || !wcsstr(path, Offsets::ClientVersion)) {
        Reset();
        status_ = "Client version does not match offsets";
        return false;
    }
    HANDLE snapshot = INVALID_HANDLE_VALUE;
    for (int attempt = 0; attempt < 3; ++attempt) {
        snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, id);
        if (snapshot != INVALID_HANDLE_VALUE || GetLastError() != ERROR_BAD_LENGTH) break;
    }
    MODULEENTRY32W entry{};
    entry.dwSize = sizeof(entry);
    if (snapshot != INVALID_HANDLE_VALUE && Module32FirstW(snapshot, &entry)) {
        do {
            if (_wcsicmp(entry.szModule, L"RobloxPlayerBeta.exe") == 0) {
                moduleBase_ = reinterpret_cast<uintptr_t>(entry.modBaseAddr);
                break;
            }
        } while (Module32NextW(snapshot, &entry));
    }
    const DWORD error = GetLastError();
    if (snapshot != INVALID_HANDLE_VALUE) CloseHandle(snapshot);
    if (!moduleBase_) {
        Reset();
        status_ = "Module enumeration failed: " + std::to_string(error);
        return false;
    }
    processId_ = id;
    status_ = "Attached; waiting for game data";
    return true;
}

void PlayerReader::RefreshPlayers(uintptr_t dataModel) {
    if (!playersService_) {
        for (const uintptr_t child : Children(dataModel)) {
            if (ClassName(child) == "Players" || Name(child) == "Players") {
                playersService_ = child;
                break;
            }
        }
    }
    if (!playersService_) {
        status_ = "Players service not found";
        return;
    }
    const auto members = Children(playersService_);
    const uintptr_t localPlayer = Pointer(playersService_ + Offsets::Player::LocalPlayer);
    if (members.empty() || !localPlayer) {
        playersService_ = 0; players_.clear(); identities_.clear(); localPlayer_ = {}; localRoot_ = 0;
        status_ = "Waiting for player list";
        return;
    }
    std::unordered_map<uintptr_t, CachedPlayer> previous;
    for (auto& player : players_) previous.emplace(player.instance, std::move(player));
    if (localPlayer_.instance) previous.emplace(localPlayer_.instance, std::move(localPlayer_));
    players_.clear(); identities_.clear(); localPlayer_ = {}; localRoot_ = 0;
    const uintptr_t localTeam = localPlayer ? Pointer(localPlayer + Offsets::Player::Team) : 0;
    std::unordered_map<uintptr_t, bool> recognizedTeams;
    auto validTeam = [&](uintptr_t team) {
        if (!team) return false;
        const auto existing = recognizedTeams.find(team);
        if (existing != recognizedTeams.end()) return existing->second;
        const bool valid = ClassName(team) == "Team";
        recognizedTeams.emplace(team, valid);
        return valid;
    };
    const bool localTeamKnown = validTeam(localTeam);
    for (const uintptr_t player : members) {
        auto existing = previous.find(player);
        if (existing == previous.end() && ClassName(player) != "Player") continue;
        CachedPlayer cached;
        if (existing != previous.end()) cached = std::move(existing->second);
        else { cached.instance = player; cached.name = Name(player); }
        PlayerIdentity identity{player, cached.name, 0, player == localPlayer};
        Read(player + Offsets::Player::UserId, identity.userId);
        cached.userId = identity.userId;
        identities_.push_back(identity);
        const uintptr_t character = Pointer(player + Offsets::Player::ModelInstance);
        if (cached.name.empty()) cached.name = "Player";
        const uintptr_t team = Pointer(player + Offsets::Player::Team);
        cached.relation = localTeamKnown && validTeam(team) ?
            (team == localTeam ? TeamRelation::Ally : TeamRelation::Enemy) : TeamRelation::Unknown;
        const auto children = character ? Children(character) : std::vector<uintptr_t>{};
        if (character != cached.character || children != cached.children || !cached.root || !cached.humanoid) {
            cached.character = character;
            cached.children = children;
            cached.root = cached.humanoid = 0;
            cached.parts.clear();
            for (const uintptr_t part : children) {
                const std::string name = Name(part);
                if (name == "HumanoidRootPart") cached.root = part;
                if (name == "Humanoid" || ClassName(part) == "Humanoid") cached.humanoid = part;
                if (BodyPartName(name)) cached.parts.push_back({part, name});
            }
        }
        if (player == localPlayer) { localRoot_ = cached.root; localPlayer_ = std::move(cached); }
        else players_.push_back(std::move(cached));
    }
    std::sort(identities_.begin(), identities_.end(), [](const auto& a, const auto& b) { return a.name < b.name; });
}

bool PlayerReader::Alive(const CachedPlayer& player) {
    if (Pointer(player.instance + Offsets::Player::ModelInstance) != player.character) { nextRefresh_ = 0; return false; }
    if (!player.humanoid) return false;
    float health = 0;
    return Read(player.humanoid + Offsets::Humanoid::Health, health) && std::isfinite(health) && health > 0;
}

std::string PlayerReader::DescribeCharacters() {
    std::string report;
    for (auto service : Children(lastDataModel_)) if (ClassName(service) == "Teams") {
        for (auto team : Children(service)) {
            uint32_t color = 0;
            Read(team + Offsets::Team::BrickColor, color);
            report += "Team definition: " + Name(team) + " color=" + std::to_string(color) + "\r\n";
        }
    }
    std::vector<const CachedPlayer*> candidates{&localPlayer_};
    for (size_t i = 0; i < std::min<size_t>(3, players_.size()); ++i) candidates.push_back(&players_[i]);
    for (const auto* player : candidates) {
        float health = 0;
        const bool readable = player->humanoid && Read(player->humanoid + Offsets::Humanoid::Health, health);
        report += "Character: humanoid=" + std::to_string(player->humanoid != 0) +
            " health-read=" + std::to_string(readable) + " health=" + std::to_string(health) + "\r\n";
        Vec3 position{}, size{};
        std::array<float, 9> rotation{};
        const bool rootReadable = player->root && Part(player->root, position, size, rotation);
        Matrix4 matrix{};
        const uintptr_t visual = Pointer(moduleBase_ + Offsets::VisualEngine::Pointer);
        const bool cameraReadable = visual && Read(visual + Offsets::VisualEngine::ViewMatrix, matrix);
        report += "  Root-readable=" + std::to_string(rootReadable) + " body-parts=" + std::to_string(player->parts.size()) +
            " clip-depth=" + std::to_string(cameraReadable && rootReadable ? ClipDepth(position, matrix) : 0) +
            " team-relation=" + std::to_string(static_cast<int>(player->relation)) + "\r\n";
        const uintptr_t team = Pointer(player->instance + Offsets::Player::Team);
        report += "  Standard-team=" + Name(team) + " : " + ClassName(team) + "\r\n";
        uint32_t teamColor = 0;
        Read(player->instance + Offsets::Player::TeamColor, teamColor);
        report += "  Team-color=" + std::to_string(teamColor) + "\r\n";
        for (const auto child : Children(player->instance)) {
            report += "  Player child " + Name(child) + " : " + ClassName(child) + "\r\n";
            if (ClassName(child) == "Folder") for (const auto value : Children(child))
                report += "    " + Name(value) + " : " + ClassName(value) + "\r\n";
        }
        for (const auto child : Children(player->character))
            report += "  " + Name(child) + " : " + ClassName(child) + "\r\n";
    }
    return report;
}

bool PlayerReader::Part(uintptr_t instance, Vec3& position, Vec3& size, std::array<float, 9>& rotation) {
    const uintptr_t primitive = Pointer(instance + Offsets::BasePart::Primitive);
    if (!primitive) return false;
    constexpr size_t blockSize = Offsets::Primitive::Size + sizeof(Vec3) - Offsets::Primitive::Rotation;
    std::array<unsigned char, blockSize> block{};
    if (!Read(primitive + Offsets::Primitive::Rotation, block.data(), block.size())) return false;
    memcpy(rotation.data(), block.data(), sizeof(float) * rotation.size());
    memcpy(&position, block.data() + Offsets::Primitive::Position - Offsets::Primitive::Rotation, sizeof(position));
    memcpy(&size, block.data() + Offsets::Primitive::Size - Offsets::Primitive::Rotation, sizeof(size));
    if (!Finite(position) || !Finite(size) || size.x <= 0 || size.y <= 0 || size.z <= 0 ||
        size.x > 1000 || size.y > 1000 || size.z > 1000) return false;
    for (float value : rotation) if (!std::isfinite(value) || std::abs(value) > 1.01f) return false;
    return true;
}

void PlayerReader::Update(HWND target, float width, float height, bool includeLocal) {
    const ULONGLONG now = GetTickCount64();
    DWORD id = 0;
    if (IsWindow(target)) GetWindowThreadProcessId(target, &id);
    if (!id) { Reset(); status_ = "Waiting for Roblox"; return; }
    if (!process_ || id != processId_) {
        if (now < nextAttach_) return;
        nextAttach_ = now + 1000;
        if (!Attach(target)) return;
    }
    boxes_.clear();
    diagnostics_ = {};
    connected_ = false;
    readError_ = 0;
    const uintptr_t fake = Pointer(moduleBase_ + Offsets::FakeDataModel::Pointer);
    const uintptr_t dataModel = fake ? Pointer(fake + Offsets::FakeDataModel::RealDataModel) : 0;
    const uintptr_t visual = Pointer(moduleBase_ + Offsets::VisualEngine::Pointer);
    if (!dataModel || !visual) {
        players_.clear();
        identities_.clear();
        localPlayer_ = {};
        localStats_ = {};
        localRoot_ = 0;
        lastDataModel_ = 0;
        status_ = "Game data unreadable: " + std::to_string(readError_);
        return;
    }
    if (lastDataModel_ != dataModel || now >= nextRefresh_) {
        if (lastDataModel_ != dataModel) {
            playersService_ = 0; players_.clear(); localPlayer_ = {};
        }
        lastDataModel_ = dataModel;
        nextRefresh_ = now + 100;
        RefreshPlayers(dataModel);
    }
    Vec3 localPosition{}, ignoredSize{};
    std::array<float, 9> ignoredRotation{};
    const bool haveLocal = localRoot_ && Part(localRoot_, localPosition, ignoredSize, ignoredRotation);
    localStats_ = {};
    if (localPlayer_.humanoid) {
        localStats_.valid = Read(localPlayer_.humanoid + Offsets::Humanoid::Walkspeed, localStats_.speed) &&
            Read(localPlayer_.humanoid + Offsets::Humanoid::JumpPower, localStats_.jumpPower) &&
            std::isfinite(localStats_.speed) && std::isfinite(localStats_.jumpPower);
        uint8_t mode = 0;
        const bool modeReadable = Read(localPlayer_.humanoid + Offsets::Humanoid::UseJumpPower, mode) && mode <= 1;
        localStats_.valid = localStats_.valid && modeReadable;
        localStats_.useJumpPower = modeReadable && mode == 1;
    }
    struct WorldPlayer {
        const CachedPlayer* player;
        Vec3 root;
        float health;
        std::vector<std::array<Vec3, 8>> parts;
        std::unordered_map<std::string, Vec3> centers;
    };
    std::vector<WorldPlayer> snapshot;
    std::vector<const CachedPlayer*> candidates;
    for (const auto& player : players_) candidates.push_back(&player);
    if (includeLocal && localPlayer_.root) candidates.push_back(&localPlayer_);
    for (const auto* candidate : candidates) {
        const auto& player = *candidate;
        if (!player.character || !player.root || !player.humanoid) { ++diagnostics_.incomplete; continue; }
        // Check every frame so a corpse is hidden before the character is replaced.
        float health = 0;
        if (!Read(player.humanoid + Offsets::Humanoid::Health, health) || !std::isfinite(health)) {
            ++diagnostics_.unreadableHealth; continue;
        }
        if (health <= 0) { ++diagnostics_.dead; continue; }
        if (Pointer(player.instance + Offsets::Player::ModelInstance) != player.character) { nextRefresh_ = 0; continue; }
        ++diagnostics_.alive;
        Vec3 rootPosition{};
        if (!Part(player.root, rootPosition, ignoredSize, ignoredRotation)) { ++diagnostics_.missingGeometry; continue; }
        WorldPlayer worldPlayer{&player, rootPosition, health, {}, {}};
        for (const auto& part : player.parts) {
            Vec3 position{}, size{};
            std::array<float, 9> r{};
            if (!Part(part.instance, position, size, r)) continue;
            worldPlayer.centers.emplace(part.name, position);
            std::array<Vec3, 8> corners;
            for (int corner = 0; corner < 8; ++corner) {
                const float x = size.x * ((corner & 1) ? 0.5f : -0.5f);
                const float y = size.y * ((corner & 2) ? 0.5f : -0.5f);
                const float z = size.z * ((corner & 4) ? 0.5f : -0.5f);
                corners[corner] = {position.x + r[0] * x + r[1] * y + r[2] * z,
                    position.y + r[3] * x + r[4] * y + r[5] * z,
                    position.z + r[6] * x + r[7] * y + r[8] * z};
            }
            worldPlayer.parts.push_back(corners);
        }
        if (worldPlayer.parts.empty()) { ++diagnostics_.missingGeometry; continue; }
        snapshot.push_back(std::move(worldPlayer));
    }
    // Sample the camera last; never retain screen coordinates across render frames.
    Matrix4 matrix{};
    if (!Read(visual + Offsets::VisualEngine::ViewMatrix, matrix)) {
        status_ = "Camera matrix unreadable: " + std::to_string(readError_);
        return;
    }
    for (float value : matrix.values) {
        if (!std::isfinite(value)) { status_ = "Invalid camera matrix"; return; }
    }
    for (const auto& player : snapshot) {
        if (!Alive(*player.player)) continue;
        PlayerBox box;
        box.id = player.player->instance;
        box.userId = player.player->userId;
        box.isLocal = player.player == &localPlayer_;
        box.relation = player.player->relation;
        box.name = player.player->name;
        box.distance = haveLocal ? Distance(localPosition, player.root) : -1;
        box.health = player.health;
        float maxHealth = 0;
        if (Read(player.player->humanoid + Offsets::Humanoid::MaxHealth, maxHealth) && std::isfinite(maxHealth) && maxHealth > 0)
            box.maxHealth = maxHealth;
        for (size_t i = 0; i < player.parts.size(); ++i)
            ProjectBody(player.parts[i], matrix, width, height, static_cast<uint32_t>(i * 97 + 19), box);
        float left = std::numeric_limits<float>::max(), top = left;
        float right = std::numeric_limits<float>::lowest(), bottom = right;
        for (const auto& polygon : box.silhouettes) for (const auto point : polygon) {
            left = std::min(left, point.x); top = std::min(top, point.y);
            right = std::max(right, point.x); bottom = std::max(bottom, point.y);
        }
        if (box.silhouettes.empty()) { ++diagnostics_.offscreen; continue; }
        if (right < 0 || left > width || bottom < 0 || top > height) { ++diagnostics_.offscreen; continue; }
        if (right - left < 2) { const float center = (left + right) * 0.5f; left = center - 1; right = center + 1; }
        if (bottom - top < 3) { const float center = (top + bottom) * 0.5f; top = center - 1.5f; bottom = center + 1.5f; }
        box.topLeft = {std::clamp(left, 0.0f, width), std::clamp(top, 0.0f, height)};
        box.bottomRight = {std::clamp(right, 0.0f, width), std::clamp(bottom, 0.0f, height)};
        const auto head = player.centers.find("Head");
        auto torso = player.centers.find("UpperTorso");
        if (torso == player.centers.end()) torso = player.centers.find("Torso");
        if (head != player.centers.end()) box.aimValid[0] = Project(head->second, matrix, width, height, box.aimPoints[0]);
        if (torso != player.centers.end()) box.aimValid[1] = Project(torso->second, matrix, width, height, box.aimPoints[1]);
        box.aimValid[2] = Project(player.root, matrix, width, height, box.aimPoints[2]);
        constexpr const char* joints[][2] = {
            {"Head", "UpperTorso"}, {"UpperTorso", "LowerTorso"},
            {"UpperTorso", "LeftUpperArm"}, {"LeftUpperArm", "LeftLowerArm"}, {"LeftLowerArm", "LeftHand"},
            {"UpperTorso", "RightUpperArm"}, {"RightUpperArm", "RightLowerArm"}, {"RightLowerArm", "RightHand"},
            {"LowerTorso", "LeftUpperLeg"}, {"LeftUpperLeg", "LeftLowerLeg"}, {"LeftLowerLeg", "LeftFoot"},
            {"LowerTorso", "RightUpperLeg"}, {"RightUpperLeg", "RightLowerLeg"}, {"RightLowerLeg", "RightFoot"},
            {"Head", "Torso"}, {"Torso", "Left Arm"}, {"Torso", "Right Arm"},
            {"Torso", "Left Leg"}, {"Torso", "Right Leg"}};
        for (const auto& joint : joints) {
            auto start = player.centers.find(joint[0]), end = player.centers.find(joint[1]);
            ScreenSegment bone;
            if (start != player.centers.end() && end != player.centers.end() &&
                Project(start->second, matrix, width, height, bone.start) &&
                Project(end->second, matrix, width, height, bone.end)) box.bones.push_back(bone);
        }
        boxes_.push_back(std::move(box));
    }
    connected_ = haveLocal;
    if (haveLocal) status_ = "Live player data";
    else status_ = "Waiting for local character / player data";
}
