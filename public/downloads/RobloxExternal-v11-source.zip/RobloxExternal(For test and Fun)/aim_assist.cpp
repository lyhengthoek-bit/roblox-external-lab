#include "aim_assist.hpp"
#include <algorithm>
#include <cmath>

const PlayerBox* SelectAimTarget(const std::vector<PlayerBox>& players, const AimSettings& settings,
    float width, float height, float maxDistance, uintptr_t selectedId, uintptr_t lockedId, const TeamOverrides& overrides) {
    const PlayerBox* closest = nullptr;
    float best = settings.radius * settings.radius;
    const int bone = std::clamp(settings.bone, 0, 2);
    for (const auto& player : players) {
        if (player.isLocal || (settings.ignoreTeammates && RelationFor(player, overrides) == TeamRelation::Ally) ||
            player.distance < 0 || (maxDistance > 0 && player.distance > maxDistance) || !player.aimValid[bone] ||
            (settings.selectedOnly && player.id != selectedId)) continue;
        const auto p = player.aimPoints[bone];
        if (!std::isfinite(p.x) || !std::isfinite(p.y) || p.x < 0 || p.y < 0 || p.x > width || p.y > height) continue;
        const float x = p.x - width / 2, y = p.y - height / 2;
        const float distance = x * x + y * y;
        if (distance > settings.radius * settings.radius) continue;
        if (settings.keepTarget && lockedId && player.id == lockedId) return &player;
        if (distance <= best) { closest = &player; best = distance; }
    }
    return closest;
}

ScreenPoint AimStep(ScreenPoint error, float dt, const AimSettings& settings) {
    if (!std::isfinite(error.x) || !std::isfinite(error.y) || !std::isfinite(dt) || dt <= 0) return {};
    const float gain = std::clamp(settings.gain, 0.02f, 2.0f);
    if (settings.smoothTime <= 0) return {error.x * gain, error.y * gain};
    const float response = 1 - std::exp(-std::min(dt, 0.05f) / std::max(0.001f, settings.smoothTime));
    const float cap = std::max(1.0f, settings.maxStep);
    return {std::clamp(error.x * response * gain, -cap, cap), std::clamp(error.y * response * gain, -cap, cap)};
}

void AimAssist::Update(const AimSettings& settings, const std::vector<PlayerBox>& players,
    HWND target, bool menuOpen, float width, float height, float dt, float maxDistance, uintptr_t selectedId,
    const TeamOverrides& overrides) {
    auto idle = [&](const char* status) { lockedId_ = 0; residual_ = {}; status_ = status; };
    if (!settings.enabled) { idle("Disabled"); return; }
    if (menuOpen) { idle("Paused while menu is open"); return; }
    if (!IsWindow(target) || IsIconic(target) || GetForegroundWindow() != target) { idle("Waiting for Roblox focus"); return; }
    const int keys[] = {VK_RBUTTON, VK_XBUTTON1, VK_LMENU};
    if (!(GetAsyncKeyState(keys[std::clamp(settings.activation, 0, 2)]) & 0x8000)) { idle("Ready"); return; }
    const auto* player = SelectAimTarget(players, settings, width, height, maxDistance, selectedId, lockedId_, overrides);
    if (!player) { idle("No target in radius"); return; }
    if (lockedId_ != player->id) residual_ = {};
    lockedId_ = player->id;
    targetPoint_ = player->aimPoints[std::clamp(settings.bone, 0, 2)];
    const auto step = AimStep({targetPoint_.x - width / 2, targetPoint_.y - height / 2}, dt, settings);
    residual_.x += step.x; residual_.y += step.y;
    INPUT input{};
    input.type = INPUT_MOUSE;
    input.mi.dwFlags = MOUSEEVENTF_MOVE;
    input.mi.dx = static_cast<LONG>(residual_.x);
    input.mi.dy = static_cast<LONG>(residual_.y);
    if (input.mi.dx || input.mi.dy) {
        // Check focus again immediately before emitting relative mouse movement.
        if (GetForegroundWindow() != target) { idle("Waiting for Roblox focus"); return; }
        if (SendInput(1, &input, sizeof(input)) != 1) { idle("Mouse input was not accepted"); return; }
        residual_.x -= input.mi.dx; residual_.y -= input.mi.dy;
    }
    status_ = "Tracking " + player->name;
}

bool TestAimAssist() {
    PlayerBox a, b, local;
    a.id = 1; a.distance = 10; a.aimValid[0] = true; a.aimPoints[0] = {510, 350};
    b.id = 2; b.distance = 20; b.aimValid[0] = true; b.aimPoints[0] = {530, 350};
    local = a; local.id = 3; local.isLocal = true; local.aimPoints[0] = {500, 350};
    std::vector<PlayerBox> players{a, b, local};
    AimSettings settings;
    auto selected = SelectAimTarget(players, settings, 1000, 700, 100, 0, 0);
    if (!selected || selected->id != 1) return false;
    selected = SelectAimTarget(players, settings, 1000, 700, 100, 0, 2);
    if (!selected || selected->id != 2) return false;
    settings.selectedOnly = true;
    selected = SelectAimTarget(players, settings, 1000, 700, 100, 2, 0);
    if (!selected || selected->id != 2) return false;
    if (SelectAimTarget(players, settings, 1000, 700, 5, 2, 0)) return false;
    settings.radius = 5;
    if (SelectAimTarget(players, settings, 1000, 700, 100, 2, 0)) return false;
    settings.radius = 180;
    players[1].relation = TeamRelation::Ally;
    if (SelectAimTarget(players, settings, 1000, 700, 0, 2, 0)) return false;
    settings.ignoreTeammates = false;
    selected = SelectAimTarget(players, settings, 1000, 700, 0, 2, 0);
    if (!selected || selected->id != 2) return false;
    players[1].relation = TeamRelation::Unknown;
    settings.ignoreTeammates = true;
    if (!SelectAimTarget(players, settings, 1000, 700, 0, 2, 0)) return false;
    players[1].userId = 20;
    TeamOverrides overrides{{20, TeamRelation::Ally}};
    if (SelectAimTarget(players, settings, 1000, 700, 0, 2, 0, overrides)) return false;
    overrides[20] = TeamRelation::Enemy;
    if (!SelectAimTarget(players, settings, 1000, 700, 0, 2, 0, overrides)) return false;
    const auto step = AimStep({100, -100}, 1.0f / 60, settings);
    if (!(step.x > 0 && step.x <= settings.maxStep && step.y < 0)) return false;
    settings.smoothTime *= 2;
    if (AimStep({100, -100}, 1.0f / 60, settings).x >= step.x) return false;
    settings.smoothTime = 0;
    settings.maxStep = 1;
    const auto immediate = AimStep({300, -300}, 1.0f / 60, settings);
    if (std::abs(immediate.x - 300 * settings.gain) > 0.001f ||
        std::abs(immediate.y + 300 * settings.gain) > 0.001f) return false;
    const auto highFps = AimStep({300, -300}, 1.0f / 144, settings);
    if (std::abs(highFps.x - immediate.x) > 0.001f) return false;
    settings.smoothTime = 0.03f;
    const auto limited = AimStep({300, -300}, 1.0f / 60, settings);
    if (limited.x != 1 || limited.y != -1) return false;
    return AimStep({0, 0}, 0.016f, settings).x == 0 && AimStep({100, 100}, 0, settings).x == 0;
}
