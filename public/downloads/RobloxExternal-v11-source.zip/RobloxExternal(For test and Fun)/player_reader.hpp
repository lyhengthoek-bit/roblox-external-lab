#pragma once
#include <windows.h>
#include <array>
#include <cstdint>
#include <string>
#include <vector>
#include <unordered_map>

struct Vec3 { float x = 0, y = 0, z = 0; };
struct Matrix4 { float values[16]{}; };
struct ScreenPoint { float x = 0, y = 0; };
struct BodyFace {
    std::array<ScreenPoint, 4> points;
    std::array<float, 4> depth;
    uint32_t seed = 0;
};
struct ScreenSegment { ScreenPoint start, end; };
enum class TeamRelation { Unknown, Ally, Enemy };
struct ReaderDiagnostics {
    size_t alive = 0, dead = 0, incomplete = 0, unreadableHealth = 0, missingGeometry = 0, offscreen = 0;
};
struct PlayerBox {
    uintptr_t id = 0;
    uint64_t userId = 0;
    bool isLocal = false;
    TeamRelation relation = TeamRelation::Unknown;
    std::string name;
    ScreenPoint topLeft, bottomRight;
    float distance = 0;
    float health = 0, maxHealth = 0;
    std::vector<std::vector<ScreenPoint>> silhouettes;
    std::vector<BodyFace> faces;
    std::vector<ScreenSegment> bones;
    std::array<ScreenPoint, 3> aimPoints{};
    std::array<bool, 3> aimValid{};
};
using TeamOverrides = std::unordered_map<uint64_t, TeamRelation>;
TeamRelation RelationFor(const PlayerBox& player, const TeamOverrides& overrides);
struct PlayerIdentity { uintptr_t id = 0; std::string name; uint64_t userId = 0; bool isLocal = false; };
struct CharacterStats { float speed = 0, jumpPower = 0; bool valid = false; bool useJumpPower = false; };

bool Project(const Vec3& position, const Matrix4& matrix, float width, float height, ScreenPoint& result);
bool TestProjection();

class PlayerReader {
public:
    ~PlayerReader();
    void Update(HWND target, float width, float height, bool includeLocal = false);
    const std::vector<PlayerIdentity>& Players() const { return identities_; }
    const CharacterStats& LocalStats() const { return localStats_; }
    const ReaderDiagnostics& Diagnostics() const { return diagnostics_; }
    const std::vector<PlayerBox>& Boxes() const { return boxes_; }
    const std::string& Status() const { return status_; }
    size_t PlayerCount() const { return players_.size(); }
    bool Connected() const { return connected_; }
    std::string DescribeCharacters();

private:
    struct CachedPlayer {
        uintptr_t instance = 0;
        uint64_t userId = 0;
        uintptr_t character = 0;
        uintptr_t root = 0;
        uintptr_t humanoid = 0;
        TeamRelation relation = TeamRelation::Unknown;
        std::vector<uintptr_t> children;
        std::string name;
        struct PartRef { uintptr_t instance; std::string name; };
        std::vector<PartRef> parts;
    };
    bool Read(uintptr_t address, void* destination, size_t size);
    template <typename T> bool Read(uintptr_t address, T& destination) {
        return Read(address, &destination, sizeof(destination));
    }
    uintptr_t Pointer(uintptr_t address);
    std::string String(uintptr_t address);
    std::string Name(uintptr_t instance);
    std::string ClassName(uintptr_t instance);
    std::vector<uintptr_t> Children(uintptr_t instance);
    bool Attach(HWND target);
    void Reset();
    void RefreshPlayers(uintptr_t dataModel);
    bool Alive(const CachedPlayer& player);
    bool Part(uintptr_t instance, Vec3& position, Vec3& size, std::array<float, 9>& rotation);

    HANDLE process_ = nullptr;
    DWORD processId_ = 0;
    DWORD readError_ = 0;
    uintptr_t moduleBase_ = 0;
    uintptr_t lastDataModel_ = 0;
    uintptr_t playersService_ = 0;
    uintptr_t localRoot_ = 0;
    ULONGLONG nextAttach_ = 0;
    ULONGLONG nextRefresh_ = 0;
    bool connected_ = false;
    std::string status_ = "Waiting for Roblox";
    std::vector<CachedPlayer> players_;
    CachedPlayer localPlayer_;
    CharacterStats localStats_;
    ReaderDiagnostics diagnostics_;
    std::vector<PlayerIdentity> identities_;
    std::vector<PlayerBox> boxes_;
};
