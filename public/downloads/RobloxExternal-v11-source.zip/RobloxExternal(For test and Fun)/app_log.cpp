#include "app_log.hpp"

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <Windows.h>

#include <array>
#include <ctime>
#include <iterator>
#include <utility>

namespace {
constexpr size_t MaximumEntries = 256;

const char* LevelName(LogLevel level) {
    switch (level) {
    case LogLevel::Warning: return "WARNING";
    case LogLevel::Error: return "ERROR";
    default: return "INFO";
    }
}

std::string LocalTimestamp() {
    const std::time_t now = std::time(nullptr);
    std::tm local{};
    if (localtime_s(&local, &now) != 0) return "0000-00-00 00:00:00";
    std::array<char, 20> result{};
    std::strftime(result.data(), result.size(), "%Y-%m-%d %H:%M:%S", &local);
    return result.data();
}

std::string FormatEntry(const LogEntry& entry) {
    return "[" + entry.timestamp + "] [" + LevelName(entry.level) + "] "
        + entry.message + '\n';
}

bool ValidHandle(HANDLE handle) {
    return handle != nullptr && handle != INVALID_HANDLE_VALUE;
}

std::string ReadFile(const std::filesystem::path& path) {
    std::ifstream file(path, std::ios::binary);
    return { std::istreambuf_iterator<char>(file), std::istreambuf_iterator<char>() };
}

bool ValidTimestamp(std::string_view value) {
    if (value.size() != 19 || value == "0000-00-00 00:00:00") return false;
    for (size_t i = 0; i < value.size(); ++i) {
        const char expected = i == 4 || i == 7 ? '-' : i == 10 ? ' '
            : i == 13 || i == 16 ? ':' : '\0';
        if (expected != '\0') {
            if (value[i] != expected) return false;
        } else if (value[i] < '0' || value[i] > '9') {
            return false;
        }
    }
    return true;
}
}

AppLog::~AppLog() {
    CloseConsoleOutput();
    if (ownsConsole_) {
        if (const HWND window = GetConsoleWindow()) ShowWindow(window, SW_HIDE);
        FreeConsole();
    }
}

bool AppLog::Initialize(const std::filesystem::path& path, bool showConsole) {
    file_.close();
    file_.clear();
    path_ = path;
    entries_.clear();
    fileReady_ = false;

    std::error_code error;
    if (!path.parent_path().empty()) {
        std::filesystem::create_directories(path.parent_path(), error);
    }
    if (!error) {
        file_.open(path, std::ios::binary | std::ios::out | std::ios::trunc);
        fileReady_ = file_.is_open() && file_.good();
    }
    if (!fileReady_) Write(LogLevel::Error, "Could not open the application log file.");

    const bool consoleReady = SetConsoleVisible(showConsole);
    return fileReady_ && consoleReady;
}

void AppLog::AppendEntry(LogEntry entry) {
    if (entries_.size() == MaximumEntries) entries_.erase(entries_.begin());
    entries_.push_back(std::move(entry));
}

void AppLog::Write(LogLevel level, std::string_view message) {
    LogEntry entry{ LocalTimestamp(), std::string(message), level };
    const std::string line = FormatEntry(entry);
    AppendEntry(std::move(entry));
    bool fileFailed = false;
    if (fileReady_) {
        file_.write(line.data(), static_cast<std::streamsize>(line.size()));
        file_.flush();
        if (!file_.good()) {
            fileReady_ = false;
            fileFailed = true;
        }
    }
    if (consoleVisible_ && !WriteConsoleLine(line)) {
        CloseConsoleOutput();
        consoleVisible_ = false;
        Write(LogLevel::Warning, "Console output failed; console logging is disabled.");
    }
    if (fileFailed) {
        Write(LogLevel::Error, "Log file write failed; subsequent entries are kept in memory.");
    }
}

bool AppLog::SetConsoleVisible(bool visible) {
    if (!visible) {
        if (ownsConsole_) {
            if (const HWND window = GetConsoleWindow()) ShowWindow(window, SW_HIDE);
        }
        CloseConsoleOutput();
        consoleVisible_ = false;
        return true;
    }

    const bool wasVisible = consoleVisible_;
    HWND window = GetConsoleWindow();
    if (!window) {
        CloseConsoleOutput();
        consoleVisible_ = false;
        ownsConsole_ = false;
        // AllocConsole initializes standard handles; retain any redirected CLI streams.
        const std::array<DWORD, 3> ids{ STD_INPUT_HANDLE, STD_OUTPUT_HANDLE, STD_ERROR_HANDLE };
        std::array<HANDLE, 3> inherited{};
        for (size_t i = 0; i < ids.size(); ++i) inherited[i] = GetStdHandle(ids[i]);
        if (!AllocConsole()) {
            Write(LogLevel::Error, "Could not allocate the application console (Windows error "
                + std::to_string(GetLastError()) + ").");
            return false;
        }
        ownsConsole_ = true;
        for (size_t i = 0; i < ids.size(); ++i) {
            if (ValidHandle(inherited[i])) SetStdHandle(ids[i], inherited[i]);
        }
        window = GetConsoleWindow();
        if (!window) {
            FreeConsole();
            ownsConsole_ = false;
            Write(LogLevel::Error, "The application console has no available window.");
            return false;
        }
        SetConsoleTitleW(L"External Overlay - Application Log");
    }

    if (!consoleOutput_) {
        const HANDLE output = CreateFileW(L"CONOUT$", GENERIC_WRITE,
            FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_EXISTING, 0, nullptr);
        if (!ValidHandle(output)) {
            const DWORD error = GetLastError();
            if (ownsConsole_) ShowWindow(window, SW_HIDE);
            consoleVisible_ = false;
            Write(LogLevel::Error, "Could not open console output (Windows error "
                + std::to_string(error) + ").");
            return false;
        }
        consoleOutput_ = output;
    }
    if (ownsConsole_) ShowWindow(window, SW_SHOW);
    if (!IsWindowVisible(window)) {
        CloseConsoleOutput();
        consoleVisible_ = false;
        Write(LogLevel::Warning, "The attached console is not visible; its window was left unchanged.");
        return false;
    }
    consoleVisible_ = true;
    if (!wasVisible) {
        const std::string retained = Text();
        if (!retained.empty() && !WriteConsoleLine(retained)) {
            CloseConsoleOutput();
            consoleVisible_ = false;
            Write(LogLevel::Warning, "Could not replay application logs; console logging is disabled.");
            return false;
        }
    }
    return true;
}

bool AppLog::WriteConsoleLine(std::string_view line) {
    if (!consoleOutput_) return false;
    const int length = MultiByteToWideChar(CP_UTF8, 0, line.data(),
        static_cast<int>(line.size()), nullptr, 0);
    if (length <= 0) return false;
    std::wstring wide(static_cast<size_t>(length), L'\0');
    if (MultiByteToWideChar(CP_UTF8, 0, line.data(), static_cast<int>(line.size()),
        wide.data(), length) != length) return false;
    size_t position = 0;
    while (position < wide.size()) {
        const auto remaining = wide.size() - position;
        const DWORD request = static_cast<DWORD>(remaining < 4096 ? remaining : 4096);
        DWORD written = 0;
        if (!WriteConsoleW(consoleOutput_, wide.data() + position, request,
            &written, nullptr) || written == 0 || written > request) return false;
        position += written;
    }
    return true;
}

void AppLog::CloseConsoleOutput() {
    if (consoleOutput_) {
        CloseHandle(consoleOutput_);
        consoleOutput_ = nullptr;
    }
}

std::string AppLog::Text() const {
    std::string text;
    for (const auto& entry : entries_) text += FormatEntry(entry);
    return text;
}

void AppLog::ClearView() {
    entries_.clear();
}

bool TestAppLog(const std::filesystem::path& scratchDirectory) {
    const auto directory = scratchDirectory / "app-log-test";
    std::error_code error;
    std::filesystem::create_directories(directory, error);
    if (error) return false;

    const auto path = directory / "latest.log";
    AppLog log;
    if (!log.Initialize(path, false) || !log.FileReady() || log.ConsoleVisible()
        || log.Path() != path) return false;
    log.Write(LogLevel::Info, "info entry");
    log.Write(LogLevel::Warning, "warning entry");
    log.Write(LogLevel::Error, "error entry");
    if (log.Entries().size() != 3 || !ValidTimestamp(log.Entries()[0].timestamp)
        || log.Entries()[0].level != LogLevel::Info
        || log.Entries()[1].level != LogLevel::Warning
        || log.Entries()[2].level != LogLevel::Error) return false;
    const auto serialized = log.Text();
    if (serialized.find("[INFO] info entry\n") == std::string::npos
        || serialized.find("[WARNING] warning entry\n") == std::string::npos
        || serialized.find("[ERROR] error entry\n") == std::string::npos
        || ReadFile(path) != serialized) return false;
    log.ClearView();
    if (!log.Entries().empty() || !log.Text().empty() || ReadFile(path) != serialized) return false;
    for (int i = 0; i < 260; ++i) log.Write(LogLevel::Info, "entry " + std::to_string(i));
    if (log.Entries().size() != MaximumEntries
        || log.Entries().front().message != "entry 4"
        || log.Entries().back().message != "entry 259"
        || ReadFile(path).find(serialized) != 0) return false;
    if (!log.Initialize(path, false) || !log.Entries().empty()
        || !ReadFile(path).empty()) return false;

    const auto blocked = directory / "cannot-open-directory-as-file";
    std::filesystem::create_directories(blocked, error);
    if (error) return false;
    AppLog failed;
    return !failed.Initialize(blocked, false) && !failed.FileReady()
        && !failed.ConsoleVisible() && !failed.Entries().empty()
        && failed.Entries().back().level == LogLevel::Error;
}
