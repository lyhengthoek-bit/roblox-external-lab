#include "runtime_metrics.hpp"
#include <windows.h>
#include <algorithm>
#include <cmath>
#include <limits>
#include <numeric>

namespace {
uint64_t FileTicks(const FILETIME& time) {
    return (static_cast<uint64_t>(time.dwHighDateTime) << 32) | time.dwLowDateTime;
}

float NormalizedCpu(uint64_t elapsedTicks, uint64_t elapsedMs, DWORD processors) {
    if (!elapsedMs || !processors) return 0;
    const double percent = static_cast<double>(elapsedTicks) / (static_cast<double>(elapsedMs) * 10000) *
        100 / processors;
    return static_cast<float>(std::clamp(percent, 0.0, 100.0));
}
}

bool RuntimeMetrics::RecordFrame(float dt) {
    if (!std::isfinite(dt) || dt <= 0) return false;
    const float frameMs = dt * 1000;
    if (!std::isfinite(frameMs)) return false;
    ++frames_;
    elapsedSeconds_ += dt;
    peakFrameMs_ = std::max(peakFrameMs_, frameMs);
    std::move(history_.begin() + 1, history_.end(), history_.begin());
    history_.back() = frameMs;
    return true;
}

void RuntimeMetrics::Update(float dt) {
    if (RecordFrame(dt)) SampleCpu();
}

float RuntimeMetrics::AverageFps() const {
    return elapsedSeconds_ > 0 ? static_cast<float>(frames_ / elapsedSeconds_) : 0;
}

float RuntimeMetrics::RollingFps() const {
    const auto count = static_cast<size_t>(std::min<uint64_t>(frames_, history_.size()));
    if (!count) return 0;
    const double frameMs = std::accumulate(history_.end() - count, history_.end(), 0.0);
    return frameMs > 0 ? static_cast<float>(count * 1000 / frameMs) : 0;
}

void RuntimeMetrics::SampleCpu() {
    const uint64_t now = GetTickCount64();
    if (cpuInitialized_ && now - cpuLastWallMs_ < 1000) return;
    FILETIME created{}, exited{}, kernel{}, user{};
    if (!GetProcessTimes(GetCurrentProcess(), &created, &exited, &kernel, &user)) return;
    const uint64_t ticks = FileTicks(kernel) + FileTicks(user);
    if (cpuInitialized_ && ticks >= cpuLastTicks_) {
        cpuPercent_ = NormalizedCpu(ticks - cpuLastTicks_, now - cpuLastWallMs_,
            GetActiveProcessorCount(ALL_PROCESSOR_GROUPS));
    }
    cpuLastTicks_ = ticks;
    cpuLastWallMs_ = now;
    cpuInitialized_ = true;
}

bool TestRuntimeMetrics() {
    RuntimeMetrics metrics;
    if (metrics.AverageFps() != 0 || metrics.RollingFps() != 0 || metrics.Frames() || metrics.ElapsedSeconds())
        return false;
    for (int i = 0; i < 120; ++i) if (!metrics.RecordFrame(1.0f / 60)) return false;
    if (metrics.Frames() != 120 || std::abs(metrics.ElapsedSeconds() - 2) > 0.00001 ||
        std::abs(metrics.AverageFps() - 60) > 0.001f || std::abs(metrics.RollingFps() - 60) > 0.001f ||
        std::abs(metrics.PeakFrameMs() - 1000.0f / 60) > 0.001f) return false;
    metrics.RecordFrame(0.1f);
    if (metrics.Frames() != 121 || std::abs(metrics.FrameHistory().back() - 100) > 0.001f ||
        std::abs(metrics.PeakFrameMs() - 100) > 0.001f || metrics.RollingFps() >= 60) return false;
    const uint64_t frames = metrics.Frames();
    const double elapsed = metrics.ElapsedSeconds();
    if (metrics.RecordFrame(0) || metrics.RecordFrame(-1) ||
        metrics.RecordFrame(std::numeric_limits<float>::quiet_NaN()) ||
        metrics.RecordFrame(std::numeric_limits<float>::infinity()) ||
        metrics.RecordFrame(std::numeric_limits<float>::max()) || metrics.Frames() != frames ||
        metrics.ElapsedSeconds() != elapsed) return false;
    RuntimeMetrics ordered;
    for (int i = 1; i <= 125; ++i) ordered.RecordFrame(i / 1000.0f);
    if (std::abs(ordered.FrameHistory().front() - 6) > 0.001f ||
        std::abs(ordered.FrameHistory().back() - 125) > 0.001f || ordered.PeakFrameMs() != 125) return false;
    return NormalizedCpu(10000000, 1000, 4) == 25 && NormalizedCpu(40000000, 1000, 4) == 100 &&
        NormalizedCpu(10000000, 0, 4) == 0 && NormalizedCpu(10000000, 1000, 0) == 0;
}
