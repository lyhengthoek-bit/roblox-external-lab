#pragma once

#include <filesystem>
#include <fstream>
#include <string>
#include <string_view>
#include <vector>

enum class LogLevel { Info, Warning, Error };

struct LogEntry {
    std::string timestamp;
    std::string message;
    LogLevel level = LogLevel::Info;
};

class AppLog {
public:
    ~AppLog();

    bool Initialize(const std::filesystem::path& path, bool showConsole);
    void Write(LogLevel level, std::string_view message);
    bool SetConsoleVisible(bool visible);
    bool ConsoleVisible() const { return consoleVisible_; }
    const std::vector<LogEntry>& Entries() const { return entries_; }
    std::string Text() const;
    void ClearView();
    bool FileReady() const { return fileReady_; }
    const std::filesystem::path& Path() const { return path_; }

private:
    void AppendEntry(LogEntry entry);
    bool WriteConsoleLine(std::string_view line);
    void CloseConsoleOutput();

    std::filesystem::path path_;
    std::ofstream file_;
    std::vector<LogEntry> entries_;
    void* consoleOutput_ = nullptr;
    bool ownsConsole_ = false;
    bool consoleVisible_ = false;
    bool fileReady_ = false;
};

bool TestAppLog(const std::filesystem::path& scratchDirectory);
