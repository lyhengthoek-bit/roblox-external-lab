#pragma once
#include "player_reader.hpp"
#include <cstdint>
#include <string>
#include <vector>

struct TriggerSettings {
    bool enabled = false;
    bool selectedOnly = false;
    int activation = 0;
    int bone = 0;
    int burstLimit = 1;
    float tolerance = 6;
    float delay = 0.15f;
    float cooldown = 0.25f;
};

class TriggerAssist {
public:
    void Update(const TriggerSettings& settings, const std::vector<PlayerBox>& players,
        HWND target, bool menuOpen, float width, float height, float dt, float maxDistance,
        uintptr_t selectedId, const TeamOverrides& overrides = {});
    const std::string& Status() const { return status_; }
    bool Armed() const { return armed_; }
    uint64_t ShotCount() const { return shotCount_; }
    void Reset();
    bool ReleasePendingInput();

private:
    struct Gate {
        bool activationHeld = false;
        bool physicalLeftHeld = false;
        bool focused = false;
        bool menuOpen = false;
    };
    bool Evaluate(const TriggerSettings& settings, const std::vector<PlayerBox>& players,
        const Gate& gate, float width, float height, float dt, float maxDistance,
        uintptr_t selectedId, const TeamOverrides& overrides = {});
    void Emitted(const TriggerSettings& settings);
    void InputFailed(const char* message);
    void ClearTarget();
    using InputEmitter = UINT (*)(UINT count, INPUT* inputs, int inputSize, void* context);
    bool EmitPair(const TriggerSettings& settings, InputEmitter emit, void* context);
    bool ReleasePendingInputWith(InputEmitter emit, void* context);

    bool armed_ = false;
    bool waitForRelease_ = false;
    bool releasePending_ = false;
    int shotsThisHold_ = 0;
    uintptr_t stableId_ = 0;
    float stableFor_ = 0;
    float cooldownLeft_ = 0;
    uint64_t shotCount_ = 0;
    std::string status_ = "Disabled";
    friend bool TestTriggerAssist();
};

bool TestTriggerAssist();
