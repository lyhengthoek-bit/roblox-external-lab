#pragma once
#include <array>
#include <cstdint>

class RuntimeMetrics {
public:
    void Update(float dt);
    double ElapsedSeconds() const { return elapsedSeconds_; }
    float AverageFps() const;
    float RollingFps() const;
    float PeakFrameMs() const { return peakFrameMs_; }
    float CpuPercent() const { return cpuPercent_; }
    uint64_t Frames() const { return frames_; }
    // Chronological frame times in milliseconds; unfilled samples stay zero.
    const std::array<float, 120>& FrameHistory() const { return history_; }

private:
    bool RecordFrame(float dt);
    void SampleCpu();

    std::array<float, 120> history_{};
    uint64_t frames_ = 0;
    double elapsedSeconds_ = 0;
    float peakFrameMs_ = 0;
    float cpuPercent_ = 0;
    uint64_t cpuLastWallMs_ = 0;
    uint64_t cpuLastTicks_ = 0;
    bool cpuInitialized_ = false;
    friend bool TestRuntimeMetrics();
};

bool TestRuntimeMetrics();
