#pragma once
#include <cstdint>

// Subset of the offsets supplied by the user (RbxDumperV2 2.2.4, 2026-10-06).
namespace Offsets {
inline constexpr wchar_t ClientVersion[] = L"version-cec3ad5889b447cf";
namespace FakeDataModel {
inline constexpr uintptr_t Pointer = 0x8bcfd50;
inline constexpr uintptr_t RealDataModel = 0x1f8;
}
namespace VisualEngine {
inline constexpr uintptr_t Pointer = 0x8656e40;
inline constexpr uintptr_t Dimensions = 0xb10;
inline constexpr uintptr_t ViewMatrix = 0x1b0;
}
namespace Instance {
inline constexpr uintptr_t Parent = 0x68;
inline constexpr uintptr_t ChildrenStart = 0x78;
inline constexpr uintptr_t ChildrenEnd = 0x8;
inline constexpr uintptr_t ClassDescriptor = 0x18;
inline constexpr uintptr_t ClassName = 0x8;
inline constexpr uintptr_t NameContainer = 0x70;
inline constexpr uintptr_t Name = 0x8;
}
namespace Player {
inline constexpr uintptr_t Team = 0x2c8;
inline constexpr uintptr_t TeamColor = 0x3a0;
inline constexpr uintptr_t UserId = 0xc0;
inline constexpr uintptr_t LocalPlayer = 0x120;
inline constexpr uintptr_t ModelInstance = 0x288;
}
namespace Team {
inline constexpr uintptr_t BrickColor = 0xa8;
}
namespace Humanoid {
inline constexpr uintptr_t MaxHealth = 0x198;
inline constexpr uintptr_t UseJumpPower = 0x1d0;
inline constexpr uintptr_t Health = 0x180;
inline constexpr uintptr_t Walkspeed = 0x1c0;
inline constexpr uintptr_t JumpPower = 0x194;
}
namespace BasePart {
inline constexpr uintptr_t Primitive = 0x178;
}
namespace Primitive {
inline constexpr uintptr_t Rotation = 0xb0;
inline constexpr uintptr_t Position = 0xd4;
inline constexpr uintptr_t Size = 0x1bc;
}
}
