#pragma once
#include "overlay_ui.hpp"
#include <filesystem>
#include <string>
#include <vector>

bool SaveProfile(const std::filesystem::path& path, const OverlaySettings& settings, std::string& error);
bool LoadProfile(const std::filesystem::path& path, OverlaySettings& settings, std::string& error);
std::filesystem::path ChooseProfilePath(HWND owner, bool save);
bool TestSettingsStore(const std::filesystem::path& scratch);
const std::string& SettingsStoreTestError();

class SettingsHistory {
public:
    void Capture(const OverlaySettings& settings);
    bool Undo(OverlaySettings& settings);
    bool Redo(OverlaySettings& settings);
    bool CanUndo() const;
    bool CanRedo() const;
    void Reset(const OverlaySettings& settings);
private:
    std::vector<OverlaySettings> snapshots_;
    size_t position_ = 0;
};
